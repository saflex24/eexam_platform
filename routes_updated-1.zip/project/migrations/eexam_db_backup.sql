--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: class_teacher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.class_teacher (
    class_id integer NOT NULL,
    teacher_id integer NOT NULL,
    is_primary boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.class_teacher OWNER TO postgres;

--
-- Name: classes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.classes (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    code character varying(50) NOT NULL,
    section character varying(10),
    academic_year character varying(20) DEFAULT '2024-2025'::character varying NOT NULL,
    total_strength integer DEFAULT 0,
    is_active boolean DEFAULT true
);


ALTER TABLE public.classes OWNER TO postgres;

--
-- Name: classes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.classes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.classes_id_seq OWNER TO postgres;

--
-- Name: classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.classes_id_seq OWNED BY public.classes.id;


--
-- Name: exam_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_results (
    id integer NOT NULL,
    exam_id integer NOT NULL,
    student_id integer NOT NULL,
    exam_session_id integer,
    total_marks double precision NOT NULL,
    marks_obtained double precision NOT NULL,
    percentage double precision NOT NULL,
    pass_marks double precision NOT NULL,
    is_passed boolean,
    grade character varying(5),
    submitted_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.exam_results OWNER TO postgres;

--
-- Name: exam_results_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exam_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exam_results_id_seq OWNER TO postgres;

--
-- Name: exam_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.exam_results_id_seq OWNED BY public.exam_results.id;


--
-- Name: exam_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_sessions (
    id integer NOT NULL,
    exam_id integer NOT NULL,
    student_id integer NOT NULL,
    session_token character varying(100) NOT NULL,
    status character varying(20),
    start_time timestamp without time zone,
    last_activity timestamp without time zone,
    end_time timestamp without time zone,
    auto_submitted boolean,
    tab_switches integer,
    copy_attempts integer,
    paste_attempts integer,
    webcam_captures integer,
    user_agent character varying(500),
    ip_address character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    session_code character varying(50) NOT NULL,
    face_violations integer DEFAULT 0 NOT NULL,
    fullscreen_exits integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.exam_sessions OWNER TO postgres;

--
-- Name: exam_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exam_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exam_sessions_id_seq OWNER TO postgres;

--
-- Name: exam_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.exam_sessions_id_seq OWNED BY public.exam_sessions.id;


--
-- Name: exams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exams (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    code character varying(50) NOT NULL,
    description text,
    subject character varying(100) NOT NULL,
    class_id integer,
    created_by integer NOT NULL,
    total_questions integer,
    total_marks double precision,
    pass_marks double precision,
    duration_minutes integer,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    published boolean,
    published_at timestamp without time zone,
    shuffle_questions boolean,
    shuffle_options boolean,
    show_results_immediately boolean,
    allow_review boolean,
    show_correct_answers boolean,
    randomize_per_student boolean,
    enable_proctoring boolean,
    enable_webcam boolean,
    enable_tab_detection boolean,
    enable_copy_paste_prevention boolean,
    is_active boolean,
    is_deleted boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    passcode character varying(50),
    allow_student_view_result boolean DEFAULT false
);


ALTER TABLE public.exams OWNER TO postgres;

--
-- Name: exams_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exams_id_seq OWNER TO postgres;

--
-- Name: exams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.exams_id_seq OWNED BY public.exams.id;


--
-- Name: proctoring_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proctoring_logs (
    id integer NOT NULL,
    exam_session_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    event_data json,
    "timestamp" timestamp without time zone,
    exam_id integer,
    student_id integer,
    violation_type character varying(100),
    severity character varying(20),
    screenshot_path character varying(255),
    details text
);


ALTER TABLE public.proctoring_logs OWNER TO postgres;

--
-- Name: proctoring_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.proctoring_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.proctoring_logs_id_seq OWNER TO postgres;

--
-- Name: proctoring_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.proctoring_logs_id_seq OWNED BY public.proctoring_logs.id;


--
-- Name: question_options; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.question_options (
    id integer NOT NULL,
    question_id integer NOT NULL,
    option_text text NOT NULL,
    option_label character varying(10) NOT NULL,
    is_correct boolean,
    latex_formula text,
    created_at timestamp without time zone
);


ALTER TABLE public.question_options OWNER TO postgres;

--
-- Name: question_options_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.question_options_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.question_options_id_seq OWNER TO postgres;

--
-- Name: question_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.question_options_id_seq OWNED BY public.question_options.id;


--
-- Name: questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.questions (
    id integer NOT NULL,
    exam_id integer NOT NULL,
    question_text text NOT NULL,
    question_type character varying(20) NOT NULL,
    marks double precision,
    "order" integer NOT NULL,
    instructions text,
    image character varying(255),
    latex_support boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.questions OWNER TO postgres;

--
-- Name: questions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.questions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.questions_id_seq OWNER TO postgres;

--
-- Name: questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.questions_id_seq OWNED BY public.questions.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(255),
    created_at timestamp without time zone
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: student_answers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_answers (
    id integer NOT NULL,
    exam_session_id integer NOT NULL,
    question_id integer NOT NULL,
    student_id integer NOT NULL,
    selected_option_id integer,
    theory_answer text,
    is_correct boolean,
    marks_obtained double precision,
    time_spent_seconds integer,
    marked_for_review boolean,
    visited_count integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.student_answers OWNER TO postgres;

--
-- Name: student_answers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_answers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.student_answers_id_seq OWNER TO postgres;

--
-- Name: student_answers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_answers_id_seq OWNED BY public.student_answers.id;


--
-- Name: student_classes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_classes (
    id integer NOT NULL,
    student_id integer NOT NULL,
    class_id integer NOT NULL,
    enrollment_date timestamp without time zone,
    is_active boolean
);


ALTER TABLE public.student_classes OWNER TO postgres;

--
-- Name: student_classes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_classes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.student_classes_id_seq OWNER TO postgres;

--
-- Name: student_classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_classes_id_seq OWNED BY public.student_classes.id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    id integer NOT NULL,
    user_id integer NOT NULL,
    admission_number character varying(50) NOT NULL,
    roll_number character varying(50),
    class_id integer,
    contact_number character varying(20),
    address text,
    date_of_birth date,
    guardian_name character varying(150),
    guardian_contact character varying(20),
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.students_id_seq OWNER TO postgres;

--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: teachers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teachers (
    id integer NOT NULL,
    user_id integer NOT NULL,
    teacher_id character varying(50) NOT NULL,
    subject character varying(100) NOT NULL,
    qualification character varying(255),
    specialization character varying(255),
    contact_number character varying(20),
    address text,
    joining_date date,
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.teachers OWNER TO postgres;

--
-- Name: teachers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.teachers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teachers_id_seq OWNER TO postgres;

--
-- Name: teachers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.teachers_id_seq OWNED BY public.teachers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(80) NOT NULL,
    email character varying(120),
    password_hash character varying(255) NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    gender character varying(10),
    profile_picture character varying(255),
    is_active boolean,
    is_deleted boolean,
    role_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: classes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.classes ALTER COLUMN id SET DEFAULT nextval('public.classes_id_seq'::regclass);


--
-- Name: exam_results id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_results ALTER COLUMN id SET DEFAULT nextval('public.exam_results_id_seq'::regclass);


--
-- Name: exam_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_sessions ALTER COLUMN id SET DEFAULT nextval('public.exam_sessions_id_seq'::regclass);


--
-- Name: exams id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exams ALTER COLUMN id SET DEFAULT nextval('public.exams_id_seq'::regclass);


--
-- Name: proctoring_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proctoring_logs ALTER COLUMN id SET DEFAULT nextval('public.proctoring_logs_id_seq'::regclass);


--
-- Name: question_options id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_options ALTER COLUMN id SET DEFAULT nextval('public.question_options_id_seq'::regclass);


--
-- Name: questions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions ALTER COLUMN id SET DEFAULT nextval('public.questions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: student_answers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_answers ALTER COLUMN id SET DEFAULT nextval('public.student_answers_id_seq'::regclass);


--
-- Name: student_classes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_classes ALTER COLUMN id SET DEFAULT nextval('public.student_classes_id_seq'::regclass);


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Name: teachers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachers ALTER COLUMN id SET DEFAULT nextval('public.teachers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
3cc56a015acb
\.


--
-- Data for Name: class_teacher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.class_teacher (class_id, teacher_id, is_primary, created_at) FROM stdin;
\.


--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.classes (id, name, description, created_at, updated_at, code, section, academic_year, total_strength, is_active) FROM stdin;
12	Class 12-B	Grade 12 Section B	2026-01-20 08:19:23.664149	2026-01-25 19:37:25.271962	CLS12	\N	2024-2025	0	f
11	Class 12-A	Grade 12 Section A	2026-01-20 08:19:23.664149	2026-01-25 19:37:25.271962	CLS11	\N	2024-2025	0	f
10	Class 11-B	Grade 11 Section B	2026-01-20 08:19:23.664149	2026-01-25 19:37:25.271962	CLS10	\N	2024-2025	0	f
8	Class 10-B	Grade 10 Section B	2026-01-20 08:19:23.664149	2026-01-28 07:33:02.046018	CLS8	\N	2024-2025	0	f
2	Class 10-B	Grade 10 Section B	2026-01-20 08:19:22.858712	2026-01-28 07:33:05.852404	CLS2	\N	2024-2025	0	f
3	Class 11-A	Grade 11 Section A	2026-01-20 08:19:22.858712	2026-01-28 07:33:08.676985	CLS3	\N	2024-2025	0	f
4	Class 11-B	Grade 11 Section B	2026-01-20 08:19:22.858712	2026-01-28 07:33:11.455688	CLS4	\N	2024-2025	0	f
5	Class 12-A	Grade 12 Section A	2026-01-20 08:19:22.858712	2026-01-28 07:33:14.029404	CLS5	\N	2024-2025	0	f
6	Class 12-B	Grade 12 Section B	2026-01-20 08:19:22.858712	2026-01-28 07:33:17.135743	CLS6	\N	2024-2025	0	f
7	Class 10-A	Grade 10 Section A	2026-01-20 08:19:23.664149	2026-01-28 07:33:21.09098	CLS7	\N	2024-2025	0	f
1	Class 10-A	Grade 10 Section A	2026-01-20 08:19:22.858712	2026-01-28 07:33:24.743998	CLS1	\N	2024-2025	0	f
9	Grade 12	Grade 11 Section A	2026-01-20 08:19:23.664149	2026-01-28 07:33:27.665985	ss2	secondary	2024-2025	0	f
13	GRADE 12		2026-01-28 07:34:02.81702	2026-01-28 07:34:02.81702	SS3	A	2024/2025	0	t
\.


--
-- Data for Name: exam_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_results (id, exam_id, student_id, exam_session_id, total_marks, marks_obtained, percentage, pass_marks, is_passed, grade, submitted_at, created_at, updated_at) FROM stdin;
1	4	7	2	2	2	100	40	f	\N	2026-01-15 08:20:54.298521	2026-01-15 08:20:54.301527	2026-01-15 08:20:54.301527
2	4	8	3	4	3	75	40	f	\N	2026-01-15 10:13:52.95061	2026-01-15 10:13:52.951807	2026-01-15 10:13:52.951807
3	5	8	4	1	1	100	40	f	\N	2026-01-15 13:03:54.877523	2026-01-15 13:03:54.880535	2026-01-15 13:03:54.880535
4	11	8	10	98	30	30.61	50	f	\N	2026-01-21 11:52:51.073822	2026-01-21 11:52:51.076822	2026-01-21 11:52:51.076822
5	11	7	13	98	40	40.82	50	f	\N	2026-01-21 17:06:39.434862	2026-01-21 17:06:39.434862	2026-01-21 17:06:39.434862
6	11	29	25	98	27	27.55	50	f	\N	2026-01-24 06:49:33.176783	2026-01-24 06:49:33.21545	2026-01-24 06:49:33.21545
7	11	30	26	98	59	60.2	50	t	\N	2026-01-24 07:09:47.26231	2026-01-24 07:09:47.26231	2026-01-24 07:09:47.26231
8	9	29	29	100	75	75	50	t	\N	2026-01-24 16:41:03.31042	2026-01-24 16:41:03.31042	2026-01-24 16:41:03.31042
9	9	31	55	100	0	0	50	f	\N	2026-01-26 10:44:23.674062	2026-01-26 10:44:23.674062	2026-01-26 10:44:23.674062
10	14	31	57	3	0	0	40	f	\N	2026-01-27 09:57:03.409425	2026-01-27 09:57:03.421447	2026-01-27 09:57:03.421447
11	12	31	59	100	0	0	50	f	\N	2026-01-27 13:43:18.355523	2026-01-27 13:43:18.355523	2026-01-27 13:43:18.355523
12	11	31	61	98	0	0	50	f	F	2026-01-27 14:04:14.002276	2026-01-27 14:04:14.004278	2026-01-27 14:04:14.004278
13	12	32	62	100	0	0	50	f	F	2026-01-27 14:13:56.296648	2026-01-27 14:13:56.297647	2026-01-27 14:13:56.297647
14	9	32	63	100	0	0	50	f	F	2026-01-28 05:39:45.539607	2026-01-28 05:39:45.541606	2026-01-28 05:39:45.541606
15	11	34	65	98	54	55.10204081632652	50	t	D	2026-01-28 07:43:23.352828	2026-01-28 07:43:23.352828	2026-01-28 07:43:23.352828
16	10	34	68	3	2	66.66666666666666	50	f	C	2026-01-28 08:30:21.625029	2026-01-28 08:30:21.625029	2026-01-28 08:30:21.625029
17	12	34	69	100	40	40	50	f	F	2026-01-28 11:11:23.471786	2026-01-28 11:11:23.473813	2026-01-28 11:11:23.473813
18	15	33	70	100	60	60	40	t	C	2026-01-28 16:16:34.350626	2026-01-28 16:16:34.353636	2026-01-28 16:16:34.353636
19	17	34	71	48	31	64.58333333333334	50	f	C	2026-01-28 22:14:05.443651	2026-01-28 22:14:05.451064	2026-01-28 22:14:05.451064
20	15	34	72	100	75	75	40	t	B	2026-01-30 13:23:48.153571	2026-01-30 13:23:48.153571	2026-01-30 13:23:48.153571
21	16	34	75	100	20	20	40	f	F	2026-01-30 14:38:16.247689	2026-01-30 14:38:16.25569	2026-01-30 14:38:16.25569
22	10	36	76	3	2	66.66666666666666	50	f	C	2026-02-02 11:04:01.160948	2026-02-02 11:04:01.164951	2026-02-02 11:04:01.164951
23	16	36	77	100	85	85	40	t	A	2026-02-02 11:22:14.337195	2026-02-02 11:22:14.338186	2026-02-02 11:22:14.338186
24	17	36	78	48	16	33.33333333333333	50	f	F	2026-02-02 12:41:46.741615	2026-02-02 12:41:46.756284	2026-02-02 12:41:46.756284
25	15	36	79	100	50	50	40	t	D	2026-02-02 21:44:10.736898	2026-02-02 21:44:10.736898	2026-02-02 21:44:10.736898
26	10	33	80	3	1	33.33333333333333	50	f	F	2026-02-03 11:46:37.302619	2026-02-03 11:46:37.318288	2026-02-03 11:46:37.318288
27	18	36	83	54	0	0	50	f	F	2026-02-04 20:14:46.495539	2026-02-04 20:14:46.497534	2026-02-04 20:14:46.497534
28	18	43	84	54	0	0	50	f	F	2026-02-04 20:33:17.269163	2026-02-04 20:33:17.269163	2026-02-04 20:33:17.269163
29	18	33	88	54	26	48.148148148148145	50	f	F	2026-02-05 11:50:29.425837	2026-02-05 11:50:29.508846	2026-02-05 11:50:29.508846
30	18	34	92	54	30	55.55555555555556	50	f	D	2026-02-06 10:54:04.183096	2026-02-06 10:54:04.183096	2026-02-06 10:54:04.183096
31	18	39	93	54	0	0	50	f	F	2026-02-06 11:11:15.419337	2026-02-06 11:11:15.42034	2026-02-06 11:11:15.42034
32	16	39	94	100	15	15	40	f	F	2026-02-06 11:13:43.710524	2026-02-06 11:13:43.710524	2026-02-06 11:13:43.710524
33	18	41	95	54	36	66.66666666666666	50	f	C	2026-02-06 15:57:40.366005	2026-02-06 15:57:40.369385	2026-02-06 15:57:40.369385
34	18	38	96	54	0	0	50	f	F	2026-02-06 16:19:24.809298	2026-02-06 16:19:24.809298	2026-02-06 16:19:24.809298
35	18	42	97	54	41	75.92592592592592	50	f	B	2026-02-06 21:35:04.36533	2026-02-06 21:35:04.375367	2026-02-06 21:35:04.375367
36	16	42	98	100	45	45	40	t	F	2026-02-06 21:40:38.155341	2026-02-06 21:40:38.155341	2026-02-06 21:40:38.155341
37	18	40	99	54	45	83.33333333333334	50	f	A	2026-02-09 11:55:30.053955	2026-02-09 11:55:30.12057	2026-02-09 11:55:30.12057
38	19	36	100	50	5	10	40	f	F	2026-02-11 16:15:18.81237	2026-02-11 16:15:18.826938	2026-02-11 16:15:18.826938
\.


--
-- Data for Name: exam_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_sessions (id, exam_id, student_id, session_token, status, start_time, last_activity, end_time, auto_submitted, tab_switches, copy_attempts, paste_attempts, webcam_captures, user_agent, ip_address, created_at, updated_at, session_code, face_violations, fullscreen_exits) FROM stdin;
23	11	29	iehn112UKOD0cbrBOF8mgUSL4wNXZZKd	started	2026-01-24 06:32:41.33137	2026-01-24 06:32:41.475691	\N	f	0	0	0	0	\N	\N	2026-01-24 06:32:41.33137	2026-01-24 06:32:41.475691	SESSION-11-29-1769232761	0	0
24	11	29	9KR0xi26EEL1H3cFzCcN4l8u5zKE59DR	started	2026-01-24 06:41:29.195845	2026-01-24 06:41:29.480781	\N	f	0	0	0	0	\N	\N	2026-01-24 06:41:29.195845	2026-01-24 06:41:29.488864	SESSION-11-29-1769233289	0	0
1	5	7	2qD3VinW8wf5mH1SmZtL9nJ6P78X93rT	started	2026-01-15 05:21:31.823425	2026-01-15 05:21:31.823425	\N	f	0	0	0	0	\N	\N	2026-01-15 05:21:31.823425	2026-01-15 05:21:31.823425	SES-1	0	0
2	4	7	SChrthaMDUqThksiatGU3pTIH9LcV9HP	submitted	2026-01-15 07:36:38.615273	2026-01-15 07:36:38.615273	2026-01-15 08:20:54.298521	f	1	0	0	0	\N	\N	2026-01-15 07:36:38.615273	2026-01-15 08:20:54.397383	SES-2	0	0
3	4	8	INxkX2EgfQolYeOyJgUPlqoiPnoiVoCc	submitted	2026-01-15 10:13:05.287773	2026-01-15 10:13:05.287773	2026-01-15 10:13:52.95061	f	1	0	0	0	\N	\N	2026-01-15 10:13:05.287773	2026-01-15 10:13:53.015081	SES-3	0	0
4	5	8	Qw4Iaf0KnHDFYgN75jrzwa8TBEJwJKHy	submitted	2026-01-15 13:03:38.879271	2026-01-15 13:03:38.887265	2026-01-15 13:03:54.878537	f	1	0	0	0	\N	\N	2026-01-15 13:03:38.887265	2026-01-15 13:03:54.936325	SES-4	0	0
5	11	8	upitH2QjVte69bGmJih4avQ60LKs0U3f	started	2026-01-21 10:32:38.230789	2026-01-21 10:32:38.230789	\N	f	0	0	0	0	\N	\N	2026-01-21 10:32:38.230789	2026-01-21 10:32:38.230789	SES-5	0	0
9	11	8	NMNtp0VwYdI8SttLO9ytEedPt9i8bBwS	started	2026-01-21 11:40:27.869681	2026-01-21 11:40:27.869681	\N	f	0	0	0	0	\N	\N	2026-01-21 11:40:27.873675	2026-01-21 11:40:27.873675	SESSION-11-8-1768992027	0	0
10	11	8	QqcYSF47FUY8paFLReoDeWFeM1NtGIyw	submitted	2026-01-21 11:48:44.155162	2026-01-21 11:48:44.155162	2026-01-21 11:52:51.074822	f	0	0	0	0	\N	\N	2026-01-21 11:48:44.158163	2026-01-21 11:52:51.142488	SESSION-11-8-1768992524	0	0
11	11	7	lFnIbhtrvMnMXOM9TmI90t2XRIas34eN	started	2026-01-21 16:44:46.478389	2026-01-21 16:44:46.478389	\N	f	0	0	0	0	\N	\N	2026-01-21 16:44:46.486396	2026-01-21 16:44:46.486396	SESSION-11-7-1769010286	0	0
12	11	7	INFC6JSy3mUklYIb2smvBz4NKeiVDTCf	started	2026-01-21 16:49:34.48441	2026-01-21 16:49:34.550451	\N	f	0	0	0	0	\N	\N	2026-01-21 16:49:34.491432	2026-01-21 16:49:34.550451	SESSION-11-7-1769010574	0	0
25	11	29	zdimyyjEMFtEhFWpmHEJJfm5j7i5P1s5	submitted	2026-01-24 06:47:23.531407	2026-01-24 06:47:24.070295	2026-01-24 06:49:33.176783	f	0	0	0	0	\N	\N	2026-01-24 06:47:23.531407	2026-01-24 06:49:33.243549	SESSION-11-29-1769233643	0	0
13	11	7	dmbGeAliNo45XXbfMaWYndfkD0kvxKx6	submitted	2026-01-21 17:04:35.447176	2026-01-21 17:04:35.520877	2026-01-21 17:06:39.434862	f	0	0	0	0	\N	\N	2026-01-21 17:04:35.455177	2026-01-21 17:06:39.485624	SESSION-11-7-1769011475	0	0
14	11	29	R198LpEHptTp0T8gUHMqPRmJGsEOszGG	started	2026-01-23 18:30:26.669005	2026-01-23 18:30:26.756189	\N	f	0	0	0	0	\N	\N	2026-01-23 18:30:26.669005	2026-01-23 18:30:26.756189	SESSION-11-29-1769189426	0	0
15	11	29	0546tT8fq47gsDv9FdsHYG11Mq6Ap5YR	started	2026-01-23 18:33:28.889841	2026-01-23 18:33:28.932646	\N	f	0	0	0	0	\N	\N	2026-01-23 18:33:28.889841	2026-01-23 18:33:28.932646	SESSION-11-29-1769189608	0	0
16	11	29	Ugc1R6gduFjyAJ6YL2AJ6E7wMKLORKLo	started	2026-01-23 18:35:24.731743	2026-01-23 18:35:24.783906	\N	f	0	0	0	0	\N	\N	2026-01-23 18:35:24.731743	2026-01-23 18:35:24.783906	SESSION-11-29-1769189724	0	0
17	11	29	MVaG133CupXhxLXHYwi2BP26MWFvDxdl	started	2026-01-23 18:42:16.567079	2026-01-23 18:42:16.615619	\N	f	0	0	0	0	\N	\N	2026-01-23 18:42:16.567079	2026-01-23 18:42:16.615619	SESSION-11-29-1769190136	0	0
18	11	29	8X6OzIttUELQ6IO46KsMTCwWPZvjdh8q	started	2026-01-24 05:40:31.091417	2026-01-24 05:40:32.4714	\N	f	0	0	0	0	\N	\N	2026-01-24 05:40:31.099405	2026-01-24 05:40:32.474408	SESSION-11-29-1769229631	0	0
19	11	29	iAKx7DzgooSS1Q0eN1Jve30wzJE8umfY	started	2026-01-24 05:56:24.104771	2026-01-24 05:56:24.270561	\N	f	0	0	0	0	\N	\N	2026-01-24 05:56:24.105768	2026-01-24 05:56:24.270561	SESSION-11-29-1769230584	0	0
20	11	29	lNGSpXbBKWDDqV8dR6wWpTLSkl2tuvbv	started	2026-01-24 06:02:16.37985	2026-01-24 06:02:16.705856	\N	f	0	0	0	0	\N	\N	2026-01-24 06:02:16.37985	2026-01-24 06:02:16.705856	SESSION-11-29-1769230936	0	0
21	11	29	0t5RI7GSv7TrFPOQvxtLlfhkGGxUQhRw	started	2026-01-24 06:13:30.540877	2026-01-24 06:13:30.745908	\N	f	0	0	0	0	\N	\N	2026-01-24 06:13:30.540877	2026-01-24 06:13:30.753908	SESSION-11-29-1769231610	0	0
22	11	29	4reuESdKCekiFtf22xbBkfO7i0qsExW0	started	2026-01-24 06:21:23.70285	2026-01-24 06:21:23.802878	\N	f	0	0	0	0	\N	\N	2026-01-24 06:21:23.70285	2026-01-24 06:21:23.802878	SESSION-11-29-1769232083	0	0
33	9	30	55OOITbFeFthawLoPXZB7ibnBe6xCAZM	started	2026-01-24 16:55:43.175194	2026-01-24 16:55:43.211919	\N	f	0	0	0	0	\N	\N	2026-01-24 16:55:43.176192	2026-01-24 16:55:43.211919	SESSION-9-30-1769270143	0	0
26	11	30	Bi7Eys3pM94sRAMrhw8xMA4KtFi1ZkYc	submitted	2026-01-24 07:06:26.623975	2026-01-24 07:06:26.736948	2026-01-24 07:09:47.26231	f	0	0	0	0	\N	\N	2026-01-24 07:06:26.631975	2026-01-24 07:09:47.26231	SESSION-11-30-1769234786	0	0
27	9	29	8yQUV20gvewt4V7oIZCilxjeAobNSfbX	started	2026-01-24 16:12:29.386523	2026-01-24 16:12:29.541781	\N	f	0	0	0	0	\N	\N	2026-01-24 16:12:29.389523	2026-01-24 16:12:29.541781	SESSION-9-29-1769267549	0	0
28	9	29	MjMPlHTtuuzcApiBGXqx0SLwTnFDLgN1	started	2026-01-24 16:31:47.515172	2026-01-24 16:31:47.584025	\N	f	0	0	0	0	\N	\N	2026-01-24 16:31:47.519171	2026-01-24 16:31:47.584025	SESSION-9-29-1769268707	0	0
29	9	29	Yj7WC0EI4RmZBcUtdM42U8JTxL7mEqdG	submitted	2026-01-24 16:35:14.634852	2026-01-24 16:35:14.662683	2026-01-24 16:41:03.31042	f	0	0	0	0	\N	\N	2026-01-24 16:35:14.634852	2026-01-24 16:41:03.31042	SESSION-9-29-1769268914	0	0
30	9	30	FUL4vwq2Q2IeHnBS30R66hn1gRB9AsjP	started	2026-01-24 16:48:17.034551	2026-01-24 16:48:17.072396	\N	f	0	0	0	0	\N	\N	2026-01-24 16:48:17.038559	2026-01-24 16:48:17.072396	SESSION-9-30-1769269697	0	0
31	9	30	8nTY6Nm2nEw5THXAfzjfG70A7YRx5rH4	started	2026-01-24 16:53:05.161498	2026-01-24 16:53:05.196499	\N	f	0	0	0	0	\N	\N	2026-01-24 16:53:05.162499	2026-01-24 16:53:05.197499	SESSION-9-30-1769269985	0	0
32	9	30	ucyAh2j0JBx207JSPZ1RjPZ2QGrA7OMb	started	2026-01-24 16:53:39.697363	2026-01-24 16:53:39.719012	\N	f	0	0	0	0	\N	\N	2026-01-24 16:53:39.698361	2026-01-24 16:53:39.72004	SESSION-9-30-1769270019	0	0
34	9	30	VCBostPcylPhuEy43lC6k6g2wJWxA2MU	started	2026-01-24 16:56:21.49497	2026-01-24 16:56:21.573225	\N	f	0	0	0	0	\N	\N	2026-01-24 16:56:21.495962	2026-01-24 16:56:21.574226	SESSION-9-30-1769270181	0	0
35	9	30	lSyFv7H5nh0Zhp43XPQQ4SqXFqR1hHRa	started	2026-01-24 16:56:59.447988	2026-01-24 16:56:59.469989	\N	f	0	0	0	0	\N	\N	2026-01-24 16:56:59.447988	2026-01-24 16:56:59.469989	SESSION-9-30-1769270219	0	0
36	9	30	R3NhmlfgAYMXPQAZ9HnW9sKfgy8qqCCv	started	2026-01-24 17:00:37.81682	2026-01-24 17:00:37.931098	\N	f	0	0	0	0	\N	\N	2026-01-24 17:00:37.81682	2026-01-24 17:00:37.932097	SESSION-9-30-1769270437	0	0
37	9	30	0k6XwhOBVCanEHiSOynmBqq8iH1CQmWu	started	2026-01-24 17:02:33.422272	2026-01-24 17:02:33.463394	\N	f	0	0	0	0	\N	\N	2026-01-24 17:02:33.423271	2026-01-24 17:02:33.4644	SESSION-9-30-1769270553	0	0
38	9	30	4uDtOtbbXPnzSLhQrfXLghh6idCxQs4d	started	2026-01-24 17:08:36.902653	2026-01-24 17:08:37.003126	\N	f	0	0	0	0	\N	\N	2026-01-24 17:08:36.902653	2026-01-24 17:08:37.003126	SESSION-9-30-1769270916	0	0
39	9	30	vwz3AUvSCuGuF8Ebgl7rKy29i5Ee7dBI	started	2026-01-24 17:09:22.104035	2026-01-24 17:09:22.155384	\N	f	0	0	0	0	\N	\N	2026-01-24 17:09:22.105034	2026-01-24 17:09:22.156384	SESSION-9-30-1769270962	0	0
40	12	31	FYWke6ljZKC6J8BSvnNrhloVAisHaifG	started	2026-01-25 20:00:28.654921	2026-01-25 20:00:28.654921	\N	f	0	0	0	0	\N	\N	2026-01-25 20:00:28.654921	2026-01-25 20:00:28.654921	SESSION-12-31-1769367628	0	0
41	12	31	UAeoX61DmqrJem3eZVte9CrDcdjR7DLn	started	2026-01-25 20:08:01.020572	2026-01-25 20:08:01.020572	\N	f	0	0	0	0	\N	\N	2026-01-25 20:08:01.028562	2026-01-25 20:08:01.028562	SESSION-12-31-1769368081	0	0
42	12	31	9rQ7dYTVRf3YpbONkwmPsxWscQy7eAVR	in_progress	2026-01-25 20:11:47.737365	2026-01-25 20:11:47.817288	\N	f	0	0	0	0	\N	\N	2026-01-25 20:11:47.745389	2026-01-25 20:11:47.817288	SESSION-12-31-1769368307	0	0
43	12	31	Cd9KvgDQszzMg9dCRYTcaxlO3pHNls4I	in_progress	2026-01-25 20:13:38.866291	2026-01-25 20:13:38.935116	\N	f	0	0	0	0	\N	\N	2026-01-25 20:13:38.866291	2026-01-25 20:13:38.935116	SESSION-12-31-1769368418	0	0
44	12	31	XnVwYx4O9gvCDozFU3FTfwMU7iIiqi0Q	in_progress	2026-01-25 20:26:40.271895	2026-01-25 20:26:40.778957	\N	f	0	0	0	0	\N	\N	2026-01-25 20:26:40.279893	2026-01-25 20:26:40.778957	SESSION-12-31-1769369200	0	0
45	9	31	rsV2yD0TzkotmAau81LiujSrN1Xyj3QG	in_progress	2026-01-25 20:27:08.860183	2026-01-25 20:27:08.892205	\N	f	0	0	0	0	\N	\N	2026-01-25 20:27:08.860183	2026-01-25 20:27:08.892205	SESSION-9-31-1769369228	0	0
46	12	31	xrTLCA6Wqj3CBpeX2HondtBSOVCB4dMm	in_progress	2026-01-25 20:34:29.844458	2026-01-25 20:35:44.251541	\N	f	0	0	0	0	\N	\N	2026-01-25 20:34:29.844458	2026-01-25 20:35:44.251541	SESSION-12-31-1769369669	0	0
47	12	31	PBl8UtQJqhL4HRUNxcTOSDGObeDoIMQC	in_progress	2026-01-25 20:35:49.514099	2026-01-25 20:36:13.509921	\N	f	0	0	0	0	\N	\N	2026-01-25 20:35:49.514099	2026-01-25 20:36:13.517951	SESSION-12-31-1769369749	0	0
48	9	31	0cZ2CK3qEV4NakOh8iYQHnFwf9CVP3mL	in_progress	2026-01-25 20:36:28.669022	2026-01-25 20:36:28.744413	\N	f	0	0	0	0	\N	\N	2026-01-25 20:36:28.669022	2026-01-25 20:36:28.744413	SESSION-9-31-1769369788	0	0
49	9	31	fKWpFpXvnVJOfbUVeiSRQS71wKCq1sqy	in_progress	2026-01-25 20:36:37.300016	2026-01-25 20:36:37.338348	\N	f	0	0	0	0	\N	\N	2026-01-25 20:36:37.308018	2026-01-25 20:36:37.338348	SESSION-9-31-1769369797	0	0
50	12	31	KmuqgN1FGbmZGQNzCVeUcUtRkKmlK5IY	started	2026-01-25 20:36:49.59683	2026-01-25 20:36:49.59683	\N	f	0	0	0	0	\N	\N	2026-01-25 20:36:49.59683	2026-01-25 20:36:49.59683	SESSION-12-31-1769369809	0	0
51	9	31	gKqOn8swavTrPq42qGQpGPztUMqO3RJO	in_progress	2026-01-25 20:38:29.772339	2026-01-25 20:38:29.843125	\N	f	0	0	0	0	\N	\N	2026-01-25 20:38:29.772339	2026-01-25 20:38:29.843125	SESSION-9-31-1769369909	0	0
62	12	32	AMwYQV2MJrRbrP1Y07v9LjtgUt2MiXGp	submitted	2026-01-27 14:13:32.410628	2026-01-27 14:13:39.800326	2026-01-27 14:13:56.296648	f	0	0	0	0	\N	\N	2026-01-27 14:13:32.412624	2026-01-27 14:13:56.299654	SESSION-12-32-1769519612	0	0
52	9	31	gAe5BXJSpmCNe2YfnvSlbzNGjgUd8dVt	in_progress	2026-01-25 21:04:26.293087	2026-01-25 21:04:32.850604	\N	f	0	0	0	0	\N	\N	2026-01-25 21:04:26.293087	2026-01-25 21:04:32.850604	SESSION-9-31-1769371466	0	0
53	11	31	Tm1wcr6OltFd0Pf1Y5focvZaOyzx2gpv	in_progress	2026-01-25 21:20:11.877906	2026-01-25 21:20:11.963518	\N	f	0	0	0	0	\N	\N	2026-01-25 21:20:11.877906	2026-01-25 21:20:11.963518	SESSION-11-31-1769372411	0	0
73	16	33	BMomLKFT3IrdOmM257aJNH6ZzkNeORcw	in_progress	2026-01-30 14:02:06.221585	2026-01-30 14:04:08.540309	\N	f	0	0	0	0	\N	\N	2026-01-30 14:02:06.23744	2026-01-30 14:04:08.540309	SESSION-16-33-1769778126	0	0
54	9	31	BZG5iEMxicKXt7DzhDhd8bHUqSU89w4p	in_progress	2026-01-26 10:42:14.788374	2026-01-26 10:42:39.437734	\N	f	0	0	0	0	\N	\N	2026-01-26 10:42:14.791104	2026-01-26 10:42:39.437734	SESSION-9-31-1769420534	0	0
80	10	33	0fTD9uHj0JCdIFW16mfFeAPmnVuJG01x	submitted	2026-02-03 11:46:08.352138	2026-02-03 11:46:13.8698	2026-02-03 11:46:36.82138	f	0	0	0	0	\N	\N	2026-02-03 11:46:08.364139	2026-02-03 11:46:37.360086	SESSION-10-33-1770115568	0	0
63	9	32	xiPKHdcm8MHQfJVNof4FMQiAkHfGCnIe	submitted	2026-01-28 05:39:18.967901	2026-01-28 05:39:24.198838	2026-01-28 05:39:45.62633	f	0	0	0	0	\N	\N	2026-01-28 05:39:18.967901	2026-01-28 05:39:45.627331	SESSION-9-32-1769575158	0	0
55	9	31	3frQVdhFzqrUhBetmpFQqWTln04FnesJ	submitted	2026-01-26 10:42:44.829292	2026-01-26 10:43:02.354328	2026-01-26 10:44:23.674062	f	0	0	0	0	\N	\N	2026-01-26 10:42:44.829292	2026-01-26 10:44:23.725318	SESSION-9-31-1769420564	0	0
64	14	32	g5wE6AYEZBLH1Oe1zm8wFCaIxyEY3GYA	started	2026-01-28 05:59:22.843129	2026-01-28 05:59:22.843129	\N	f	0	0	0	0	\N	\N	2026-01-28 05:59:22.844129	2026-01-28 05:59:22.844129	SESSION-14-32-1769576362	0	0
56	14	31	xnhUpkKcKOdcp6GI2dWU9j2GN8kup58c	in_progress	2026-01-26 21:31:04.876149	2026-01-26 21:31:46.410812	\N	f	0	0	0	0	\N	\N	2026-01-26 21:31:04.87915	2026-01-26 21:31:46.410812	SESSION-14-31-1769459464	0	0
70	15	33	QjHto8vEVcMJzdhQxjaCCGb5sT9gAOW8	submitted	2026-01-28 16:14:57.699908	2026-01-28 16:15:08.230599	2026-01-28 16:16:34.178252	f	0	0	0	0	\N	\N	2026-01-28 16:14:57.702902	2026-01-28 16:16:34.356627	SESSION-15-33-1769613297	0	0
57	14	31	G1JKzlgMEGBYV2d7Quvis7Apro6pKfFN	submitted	2026-01-27 09:56:01.953019	2026-01-27 09:56:11.400364	2026-01-27 09:57:03.409425	f	0	0	0	0	\N	\N	2026-01-27 09:56:02.426164	2026-01-27 09:57:03.510852	SESSION-14-31-1769504161	0	0
58	11	31	B5X8jE6S3HRw920a3QxDuFBzx9YaQBGM	started	2026-01-27 10:55:30.478016	2026-01-27 10:55:30.478016	\N	f	0	0	0	0	\N	\N	2026-01-27 10:55:30.478016	2026-01-27 10:55:30.478016	SESSION-11-31-1769507730	0	0
74	16	33	kVTzesPzqDGcEs9Y33ijtL04ZEj0CEK1	in_progress	2026-01-30 14:10:45.104702	2026-01-30 14:10:52.545342	\N	f	0	0	0	0	\N	\N	2026-01-30 14:10:45.112736	2026-01-30 14:10:52.545342	SESSION-16-33-1769778645	0	0
65	11	34	1geMtVd0kRZrbOLjpjDWnB3o3SNc2QhD	submitted	2026-01-28 07:41:14.155731	2026-01-28 07:41:18.701419	2026-01-28 07:43:23.417736	f	0	0	0	0	\N	\N	2026-01-28 07:41:14.155731	2026-01-28 07:43:23.418738	SESSION-11-34-1769582474	0	0
59	12	31	XqusE2Z8ADAE30gWc5AIAIrFbhQaOM28	submitted	2026-01-27 13:42:16.635094	2026-01-27 13:42:37.251162	2026-01-27 13:43:18.355523	f	0	0	0	0	\N	\N	2026-01-27 13:42:16.638101	2026-01-27 13:43:18.404031	SESSION-12-31-1769517736	0	0
60	11	31	WnHDf8JtXFaHOlyvDI26iIXitFn6B5VK	started	2026-01-27 14:01:39.278963	2026-01-27 14:01:39.278963	\N	f	0	0	0	0	\N	\N	2026-01-27 14:01:39.281963	2026-01-27 14:01:39.281963	SESSION-11-31-1769518899	0	0
66	12	34	a02evmkEnkWGzObHbQllgKSXKphErJhD	started	2026-01-28 08:12:27.856583	2026-01-28 08:12:27.856583	\N	f	0	0	0	0	\N	\N	2026-01-28 08:12:27.860577	2026-01-28 08:12:27.860577	SESSION-12-34-1769584347	0	0
67	12	34	2HJVvMDatqRVceOyOIV4Vgjwtc3hDWmt	started	2026-01-28 08:21:25.859632	2026-01-28 08:21:25.859632	\N	f	0	0	0	0	\N	\N	2026-01-28 08:21:25.863629	2026-01-28 08:21:25.863629	SESSION-12-34-1769584885	0	0
61	11	31	D5HKxcW3hRwYqo2Mki8xrzEkqN95aN3G	submitted	2026-01-27 14:03:49.268617	2026-01-27 14:03:53.843453	2026-01-27 14:04:14.002276	f	0	0	0	0	\N	\N	2026-01-27 14:03:49.268617	2026-01-27 14:04:14.006279	SESSION-11-31-1769519029	0	0
71	17	34	5EB4IuQEfJNnOr9p3rgLGTzJ2mVadpF6	submitted	2026-01-28 22:13:00.214836	2026-01-28 22:13:08.904971	2026-01-28 22:14:05.362923	f	0	0	0	0	\N	\N	2026-01-28 22:13:00.214836	2026-01-28 22:14:05.459577	SESSION-17-34-1769634780	0	0
68	10	34	uuua51j78eq61IBLSu3AVeRxHTRUwUGQ	submitted	2026-01-28 08:30:00.457908	2026-01-28 08:30:05.845008	2026-01-28 08:30:21.625029	f	0	0	0	0	\N	\N	2026-01-28 08:30:00.457908	2026-01-28 08:30:21.625029	SESSION-10-34-1769585400	0	0
77	16	36	HA6QZ0cu57DGHozSbCI5MXgjecjB2mIF	submitted	2026-02-02 11:18:32.163035	2026-02-02 11:18:44.977212	2026-02-02 11:22:14.204003	f	0	0	0	0	\N	\N	2026-02-02 11:18:32.163035	2026-02-02 11:22:14.340187	SESSION-16-36-1770027512	0	0
69	12	34	FLp9xcx1OSoVdo8QU4XZNykqRk7AqRwE	submitted	2026-01-28 11:09:26.232598	2026-01-28 11:09:50.172826	2026-01-28 11:11:23.357969	f	0	0	0	0	\N	\N	2026-01-28 11:09:26.235626	2026-01-28 11:11:23.475813	SESSION-12-34-1769594966	0	0
75	16	34	mnKFk666ilhA5bSPcB250SB6KEedA1MN	submitted	2026-01-30 14:37:23.900606	2026-01-30 14:37:28.310618	2026-01-30 14:38:16.147114	f	0	0	0	0	\N	\N	2026-01-30 14:37:23.900606	2026-01-30 14:38:16.25569	SESSION-16-34-1769780243	0	0
72	15	34	lWHSHC5Ko7KuD7XokavB6mM3r8o9c3yp	submitted	2026-01-30 13:17:15.293382	2026-01-30 13:17:20.895038	2026-01-30 13:23:47.787149	f	0	0	0	0	\N	\N	2026-01-30 13:17:15.296384	2026-01-30 13:23:48.200361	SESSION-15-34-1769775435	0	0
79	15	36	SD2g9GcJCbcNeP9hYwQdM95S0qcJDKWG	submitted	2026-02-02 21:42:28.883592	2026-02-02 21:42:36.999807	2026-02-02 21:44:10.266069	f	0	0	0	0	\N	\N	2026-02-02 21:42:28.883592	2026-02-02 21:44:10.747925	SESSION-15-36-1770064948	0	0
76	10	36	OItWsRtEMKZAp6ERpRIuYeV3zhiUA267	submitted	2026-02-02 11:03:35.51754	2026-02-02 11:03:43.033871	2026-02-02 11:04:00.024438	f	0	0	0	0	\N	\N	2026-02-02 11:03:35.521532	2026-02-02 11:04:01.237629	SESSION-10-36-1770026615	0	0
78	17	36	WhMXWDEcvZfm1T0npeUWwpv8qjmn1O25	submitted	2026-02-02 12:40:48.217578	2026-02-02 12:40:52.448062	2026-02-02 12:41:46.301098	f	0	0	0	0	\N	\N	2026-02-02 12:40:48.222579	2026-02-02 12:41:46.775724	SESSION-17-36-1770032448	0	0
83	18	36	w21oMoYhDMi7MVX4EgiqIvTI87mWYgN5	submitted	2026-02-04 20:09:27.509645	2026-02-04 20:09:41.428152	2026-02-04 20:14:46.495539	f	0	0	0	0	\N	\N	2026-02-04 20:09:27.511643	2026-02-04 20:14:46.500535	SESSION-18-36-1770232167	0	0
81	18	33	cExlRatAhT7fk1fz8alefsXYnehlQN4s	in_progress	2026-02-04 12:55:50.018774	2026-02-04 12:56:41.766901	\N	f	0	0	0	0	\N	\N	2026-02-04 12:55:50.018774	2026-02-04 12:56:41.766901	SESSION-18-33-1770206150	0	0
82	18	33	d9gcU7lOYrJ0YzhAE4XnUkqES4zkdeHq	started	2026-02-04 12:57:16.350548	2026-02-04 12:57:16.350548	\N	f	0	0	0	0	\N	\N	2026-02-04 12:57:16.350548	2026-02-04 12:57:16.350548	SESSION-18-33-1770206236	0	0
84	18	43	S73drIMV11VYNnUyUUrgrVE7XgvApdM7	submitted	2026-02-04 20:29:26.118927	2026-02-04 20:29:36.454476	2026-02-04 20:33:17.269163	f	0	0	0	0	\N	\N	2026-02-04 20:29:26.118927	2026-02-04 20:33:17.269163	SESSION-18-43-1770233366	0	0
85	10	43	OSKZn8wZmh2X9532fH7ST9DDslp1kAFD	in_progress	2026-02-04 21:14:08.818756	2026-02-04 21:14:14.705462	\N	f	0	0	0	0	\N	\N	2026-02-04 21:14:08.818756	2026-02-04 21:14:14.705462	SESSION-10-43-1770236048	0	0
86	18	33	vy4O4O5Ho3Flos8qkNuCpB5hqaQId7U2	in_progress	2026-02-05 11:31:22.023409	2026-02-05 11:31:32.152295	\N	f	0	0	0	0	\N	\N	2026-02-05 11:31:23.359461	2026-02-05 11:31:32.152295	SESSION-18-33-1770287481	0	0
87	18	33	bqenMDYDTyAVjEh8tUmYuSX02z587jrR	in_progress	2026-02-05 11:35:38.607221	2026-02-05 11:35:44.458809	\N	f	0	0	0	0	\N	\N	2026-02-05 11:35:38.612275	2026-02-05 11:35:44.458809	SESSION-18-33-1770287738	0	0
88	18	33	MByUGa0e48kgjvJrSLLOnnDSkUWCWPSE	submitted	2026-02-05 11:44:30.150366	2026-02-05 11:44:42.499054	2026-02-05 11:50:29.541307	f	1	0	0	0	\N	\N	2026-02-05 11:44:30.151369	2026-02-05 11:50:32.123819	SESSION-18-33-1770288270	0	0
89	16	33	T7GX2w9tmgYzQ1r9ocp9fmBVIM9YHgBA	in_progress	2026-02-05 11:53:12.872262	2026-02-05 11:53:18.44254	\N	f	1	0	0	0	\N	\N	2026-02-05 11:53:12.873265	2026-02-05 11:53:31.84624	SESSION-16-33-1770288792	0	0
90	16	33	0TWkg14reQMaSL39ahf2oEJyJANaHfHC	in_progress	2026-02-05 11:53:39.811488	2026-02-05 11:53:44.307569	\N	f	2	0	0	0	\N	\N	2026-02-05 11:53:39.812488	2026-02-05 11:54:00.095921	SESSION-16-33-1770288819	0	0
91	16	33	VOSycdvRYzQJRFhHK6qXeJgk3CNncIjG	started	2026-02-05 11:54:10.119196	2026-02-05 11:54:10.119196	\N	f	0	0	0	0	\N	\N	2026-02-05 11:54:10.119196	2026-02-05 11:54:10.119196	SESSION-16-33-1770288850	0	0
99	18	40	vMOUesJ6LcRl9Vq5oX53Y6JjoMMUeo68	submitted	2026-02-09 11:52:17.065189	2026-02-09 11:55:31.765641	2026-02-09 11:55:30.320448	f	1	0	0	0	\N	\N	2026-02-09 11:52:17.638351	2026-02-09 11:55:31.769639	SESSION-18-40-1770634336	0	0
92	18	34	WpIAHOYfQCNzG2XlpnMWPXNY1rQmntfR	submitted	2026-02-06 10:49:51.328601	2026-02-06 10:50:35.645878	2026-02-06 10:54:04.198158	f	0	0	0	0	\N	\N	2026-02-06 10:49:51.328601	2026-02-06 10:54:04.198158	SESSION-18-34-1770371391	0	0
96	18	38	ZYVQSbMqwjEh8A3oTHX4M8YtzL9Oukyn	submitted	2026-02-06 16:14:52.388519	2026-02-06 16:19:56.355759	2026-02-06 16:19:24.809298	f	59	0	0	0	\N	\N	2026-02-06 16:14:52.388519	2026-02-06 16:19:56.355759	SESSION-18-38-1770390892	3	0
93	18	39	0j5OmNqyOeAzthGkYkg7BbrLCPTGb7JF	submitted	2026-02-06 11:07:05.943734	2026-02-06 11:07:11.368319	2026-02-06 11:11:15.419337	f	0	0	0	0	\N	\N	2026-02-06 11:07:05.943734	2026-02-06 11:11:15.42234	SESSION-18-39-1770372425	0	0
94	16	39	sZVdlQfLCQV1PyQJYfzubnIicOny7LCy	submitted	2026-02-06 11:13:15.956162	2026-02-06 11:13:19.319824	2026-02-06 11:13:43.710524	f	0	0	0	0	\N	\N	2026-02-06 11:13:15.957189	2026-02-06 11:13:43.710524	SESSION-16-39-1770372795	0	0
95	18	41	Stensruqw75TrlldyFk0U4dIXEOmzlV8	submitted	2026-02-06 15:54:25.626818	2026-02-06 15:54:30.90183	2026-02-06 15:57:40.383954	f	0	0	0	0	\N	\N	2026-02-06 15:54:25.626818	2026-02-06 15:57:40.383954	SESSION-18-41-1770389665	0	0
97	18	42	vN5xHP5aM3sHtyogZMGQPxXNr47FSnjO	submitted	2026-02-06 21:31:40.829047	2026-02-06 21:35:04.894351	2026-02-06 21:35:04.397241	f	1	0	0	0	\N	\N	2026-02-06 21:31:40.837056	2026-02-06 21:35:04.894351	SESSION-18-42-1770409900	5	0
100	19	36	Se2KFODibbeBwhJCnHkLOYf13RG3vbd4	submitted	2026-02-11 16:13:15.371159	2026-02-11 16:15:19.492554	2026-02-11 16:15:19.343383	f	7	0	0	0	\N	\N	2026-02-11 16:13:15.371159	2026-02-11 16:15:19.493717	SESSION-19-36-1770822795	0	0
98	16	42	iFqGEBSYhzzKHTaVePkZy0p7dXrohZ8o	submitted	2026-02-06 21:36:03.545792	2026-02-06 21:40:38.291145	2026-02-06 21:40:38.162285	f	8	5	0	0	\N	\N	2026-02-06 21:36:03.545792	2026-02-06 21:40:38.291145	SESSION-16-42-1770410163	6	0
\.


--
-- Data for Name: exams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exams (id, title, code, description, subject, class_id, created_by, total_questions, total_marks, pass_marks, duration_minutes, start_date, end_date, published, published_at, shuffle_questions, shuffle_options, show_results_immediately, allow_review, show_correct_answers, randomize_per_student, enable_proctoring, enable_webcam, enable_tab_detection, enable_copy_paste_prevention, is_active, is_deleted, created_at, updated_at, passcode, allow_student_view_result) FROM stdin;
1	mock	RTIPTIFS1P	testing	computer	\N	5	0	100	50	60	2026-01-15 05:13:00	2026-01-16 18:14:00	f	\N	t	t	t	t	f	f	t	f	t	t	t	t	2026-01-15 04:14:11.902105	2026-01-15 04:37:05.81046	\N	f
3	first term	IECWGYT53Z		english	\N	5	0	100	40	60	2026-01-15 05:29:00	2026-01-15 18:30:00	f	\N	t	t	f	t	f	f	t	f	t	t	t	t	2026-01-15 04:29:41.018217	2026-01-15 04:40:57.193071	\N	f
2	biology	S0X99RXKGJ	testing	math	\N	5	2	2	40	60	2026-01-15 05:16:00	2026-01-15 18:17:00	f	2026-01-18 06:00:00.420181	t	t	f	t	f	f	t	f	t	t	t	t	2026-01-15 04:17:01.001539	2026-01-28 16:04:54.506758	12345	f
4	second	SDO7EJXHMW	bhghg	cpt	4	5	4	4	40	60	2026-01-15 05:33:00	2026-01-17 05:33:00	t	2026-01-15 10:09:28.723442	t	t	f	t	f	f	t	f	t	t	t	t	2026-01-15 04:33:59.464252	2026-01-28 16:05:09.019358	\N	f
18	EXAM002	ZZYNFUE36E		BIOLOGY	\N	35	14	54	50	3	2026-02-03 13:42:00	2026-02-26 13:42:00	t	2026-02-04 20:08:21.564035	t	t	t	t	f	f	t	f	t	t	t	f	2026-02-04 12:42:45.962176	2026-02-04 20:08:21.557943	12345	t
5	term	F31NMRHI6D		english	\N	5	1	1	40	60	2026-01-14 06:19:00	2026-01-16 19:21:00	t	2026-01-15 05:21:09.155373	t	t	t	t	f	f	t	f	t	t	t	t	2026-01-15 05:20:30.230358	2026-01-28 16:05:15.873372	\N	f
6	THIRD TERM	U4VEVVAC2D		AGRI	3	5	2	2	50	30	2026-01-14 13:59:00	2026-01-20 01:59:00	t	2026-01-27 14:11:05.914503	t	t	t	t	f	f	t	f	t	t	t	t	2026-01-15 13:00:05.647474	2026-01-28 16:05:22.040458	12345	f
7	mock	KDIALS70TP	welcome	chemistry	\N	5	1	1	50	60	2026-01-20 12:13:00	2026-01-23 12:14:00	f	\N	t	t	f	f	f	f	t	f	t	t	t	t	2026-01-20 11:14:36.660446	2026-01-28 16:05:29.168513	12345	f
9	MOCk	8BYNB4SNJL		english	\N	5	20	100	50	60	2026-01-24 10:35:00	2026-01-29 21:34:00	t	2026-01-24 16:11:59.955908	t	t	f	t	f	f	t	f	t	t	t	t	2026-01-20 20:34:26.97527	2026-01-28 16:05:38.405562	12345	f
8	civic	CQFWCT0W7O		civic edu	\N	5	0	100	50	60	2026-01-20 12:27:00	2026-01-22 12:28:00	f	\N	t	t	f	t	f	f	t	f	t	t	t	t	2026-01-20 11:28:16.370359	2026-01-21 09:21:10.392361	\N	f
10	Third Term	ZBMURIG2CQ		social Studies	13	5	3	3	50	60	2026-01-21 09:57:00	2026-02-05 09:57:00	t	2026-01-28 08:28:25.79728	t	t	f	t	f	f	t	f	t	t	t	t	2026-01-21 08:57:55.072361	2026-01-28 16:05:46.280993	12345	f
11	first term	IF2R9SPRTS		AGRI-cpt	\N	5	22	98	50	30	2026-01-23 00:10:00	2026-02-02 11:10:00	t	2026-01-21 09:31:21.620681	t	t	f	t	f	f	t	f	t	t	t	t	2026-01-21 09:10:06.243765	2026-01-28 16:05:51.144544	12345	f
12	first term	JN4U91AOVU		chemistry	\N	5	20	100	50	30	2026-01-24 20:48:00	2026-01-28 20:49:00	t	2026-01-25 19:52:35.327762	t	t	f	t	f	f	t	f	t	t	t	t	2026-01-25 19:50:09.878968	2026-01-28 16:05:57.328559	1234	f
13	Brain Test	HVZ9VQMXO9		math	13	5	11	49	40	60	2026-01-24 22:39:00	2026-01-25 10:41:00	t	2026-01-28 07:40:33.67006	t	t	f	t	f	f	t	f	t	t	t	t	2026-01-25 20:40:31.349384	2026-01-28 16:06:02.695112	12345	f
14	MOCK	HFN78XRE9S		CIVIC EDUCATION	9	5	3	3	40	60	2026-01-25 21:41:00	2026-01-31 21:41:00	t	2026-01-26 21:30:18.402872	t	t	f	t	f	f	t	f	t	t	t	t	2026-01-26 20:42:20.020953	2026-01-28 16:06:07.206616	ZLVCA5ET	f
19	exam003	JLANUVS3FB		english	\N	5	10	50	40	60	2026-02-10 17:08:00	2026-02-20 17:12:00	t	2026-02-11 16:12:08.877173	t	t	f	t	f	f	t	f	t	t	t	f	2026-02-11 16:09:04.854231	2026-02-11 16:12:08.872596	12345	f
16	Welcome Test	QPIUTPQB07		computer	13	35	20	100	40	60	2026-01-27 17:12:00	2026-02-08 17:12:00	t	2026-01-28 16:13:50.740349	t	t	f	t	f	f	t	f	t	t	t	f	2026-01-28 16:12:42.064423	2026-01-28 22:09:46.658719	12345	t
17	test02	H3JZNZ9VOO		physic	13	35	10	48	50	60	2026-01-27 23:11:00	2026-02-06 23:11:00	t	2026-01-28 22:12:40.666318	t	t	f	t	f	f	t	f	t	t	t	f	2026-01-28 22:11:56.589459	2026-01-28 22:14:57.78945	12345	t
15	test	JE0WNL1MFX		computer	13	5	20	100	40	60	2026-01-27 11:30:00	2026-02-06 11:30:00	t	2026-01-28 10:51:03.643377	t	t	f	t	f	f	t	f	t	t	t	f	2026-01-28 10:49:20.312829	2026-01-30 13:29:01.110703	12345	t
\.


--
-- Data for Name: proctoring_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proctoring_logs (id, exam_session_id, event_type, event_data, "timestamp", exam_id, student_id, violation_type, severity, screenshot_path, details) FROM stdin;
1	2	focus_lost	{}	2026-01-15 08:20:49.44878	\N	\N	\N	\N	\N	\N
2	2	focus_lost	{}	2026-01-15 08:20:54.282481	\N	\N	\N	\N	\N	\N
3	2	focus_lost	{}	2026-01-15 08:20:54.393392	\N	\N	\N	\N	\N	\N
4	2	tab_switch	{}	2026-01-15 08:20:54.399385	\N	\N	\N	\N	\N	\N
5	3	focus_lost	{}	2026-01-15 10:13:47.178481	\N	\N	\N	\N	\N	\N
6	3	focus_lost	{}	2026-01-15 10:13:52.948608	\N	\N	\N	\N	\N	\N
7	3	tab_switch	{}	2026-01-15 10:13:53.015081	\N	\N	\N	\N	\N	\N
8	4	focus_lost	{}	2026-01-15 13:03:53.309786	\N	\N	\N	\N	\N	\N
9	4	focus_lost	{}	2026-01-15 13:03:54.870781	\N	\N	\N	\N	\N	\N
10	4	focus_lost	{}	2026-01-15 13:03:54.932324	\N	\N	\N	\N	\N	\N
11	4	tab_switch	{}	2026-01-15 13:03:54.937328	\N	\N	\N	\N	\N	\N
13	88	tab_switch	{}	2026-02-05 11:50:31.566165	\N	\N	\N	Low	\N	\N
14	89	tab_switch	{}	2026-02-05 11:53:31.844971	\N	\N	\N	Low	\N	\N
15	90	tab_switch	{}	2026-02-05 11:53:48.456241	\N	\N	\N	Low	\N	\N
16	90	tab_switch	{}	2026-02-05 11:54:00.094923	\N	\N	\N	Low	\N	\N
17	96	face_not_visible	\N	2026-02-06 16:15:26.664905	18	38	face_not_visible	medium	\N	{"duration": 6038, "warningCount": 1, "timestamp": "2026-02-06T16:15:26.645Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
18	96	face_not_visible	\N	2026-02-06 16:15:35.60124	18	38	face_not_visible	medium	\N	{"duration": 5919, "warningCount": 2, "timestamp": "2026-02-06T16:15:35.569Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
19	96	tab_switch	\N	2026-02-06 16:16:12.50333	18	38	tab_switch	medium	\N	{"count": 1, "timestamp": "2026-02-06T16:16:12.410Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
20	96	tab_switch	\N	2026-02-06 16:16:12.584679	18	38	tab_switch	medium	\N	{"count": 2, "timestamp": "2026-02-06T16:16:12.432Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
21	96	tab_switch	\N	2026-02-06 16:16:16.9616	18	38	tab_switch	medium	\N	{"count": 3, "timestamp": "2026-02-06T16:16:16.864Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
22	96	tab_switch	\N	2026-02-06 16:16:16.97463	18	38	tab_switch	medium	\N	{"count": 4, "timestamp": "2026-02-06T16:16:16.884Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
23	96	tab_switch	\N	2026-02-06 16:16:22.516112	18	38	tab_switch	medium	\N	{"count": 5, "timestamp": "2026-02-06T16:16:22.397Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
24	96	excessive_violations	\N	2026-02-06 16:16:22.516112	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 5, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 2, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:16:22.402Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
25	96	tab_switch	\N	2026-02-06 16:16:22.643534	18	38	tab_switch	medium	\N	{"count": 6, "timestamp": "2026-02-06T16:16:22.484Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
26	96	warning_dismissed	\N	2026-02-06 16:16:22.651683	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:16:22.469Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
27	96	warning_dismissed	\N	2026-02-06 16:16:22.684171	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:16:22.503Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
28	96	excessive_violations	\N	2026-02-06 16:16:22.684171	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 6, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 2, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:16:22.487Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
29	96	tab_switch	\N	2026-02-06 16:16:26.233212	18	38	tab_switch	medium	\N	{"count": 7, "timestamp": "2026-02-06T16:16:26.153Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
30	96	excessive_violations	\N	2026-02-06 16:16:26.233212	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 7, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 2, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:16:26.155Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
31	96	tab_switch	\N	2026-02-06 16:16:26.254378	18	38	tab_switch	medium	\N	{"count": 8, "timestamp": "2026-02-06T16:16:26.203Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
32	96	warning_dismissed	\N	2026-02-06 16:16:26.262378	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:16:26.198Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
33	96	excessive_violations	\N	2026-02-06 16:16:26.270377	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 8, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 2, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:16:26.207Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
34	96	warning_dismissed	\N	2026-02-06 16:16:26.270377	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:16:26.222Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
35	96	face_not_visible	\N	2026-02-06 16:16:44.673009	18	38	face_not_visible	medium	\N	{"duration": 6052, "warningCount": 3, "timestamp": "2026-02-06T16:16:44.640Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
36	96	excessive_violations	\N	2026-02-06 16:16:44.679041	18	38	excessive_violations	high	\N	{"violationType": "face_not_visible", "allViolations": {"tabSwitches": 8, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:16:44.643Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
39	96	tab_switch	\N	2026-02-06 16:16:58.449063	18	38	tab_switch	medium	\N	{"count": 10, "timestamp": "2026-02-06T16:16:58.439Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
48	96	excessive_violations	\N	2026-02-06 16:17:01.461788	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 14, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:17:01.441Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
54	96	excessive_violations	\N	2026-02-06 16:17:40.12182	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 17, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:17:40.108Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
57	96	tab_switch	\N	2026-02-06 16:17:41.618693	18	38	tab_switch	medium	\N	{"count": 19, "timestamp": "2026-02-06T16:17:41.607Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
61	96	excessive_violations	\N	2026-02-06 16:17:59.616622	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 20, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:17:59.589Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
67	96	excessive_violations	\N	2026-02-06 16:18:01.686954	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 23, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:18:01.677Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
70	96	tab_switch	\N	2026-02-06 16:18:03.820059	18	38	tab_switch	medium	\N	{"count": 25, "timestamp": "2026-02-06T16:18:03.813Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
76	96	tab_switch	\N	2026-02-06 16:18:04.609621	18	38	tab_switch	medium	\N	{"count": 28, "timestamp": "2026-02-06T16:18:04.601Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
82	96	tab_switch	\N	2026-02-06 16:18:05.26869	18	38	tab_switch	medium	\N	{"count": 31, "timestamp": "2026-02-06T16:18:05.260Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
37	96	tab_switch	\N	2026-02-06 16:16:52.771911	18	38	tab_switch	medium	\N	{"count": 9, "timestamp": "2026-02-06T16:16:52.758Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
46	96	excessive_violations	\N	2026-02-06 16:17:00.612245	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 13, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:17:00.598Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
49	96	tab_switch	\N	2026-02-06 16:17:03.634846	18	38	tab_switch	medium	\N	{"count": 15, "timestamp": "2026-02-06T16:17:03.622Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
58	96	excessive_violations	\N	2026-02-06 16:17:41.618693	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 19, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:17:41.608Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
69	96	excessive_violations	\N	2026-02-06 16:18:03.351338	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 24, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:18:03.342Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
75	96	excessive_violations	\N	2026-02-06 16:18:04.261274	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 27, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:18:04.245Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
81	96	excessive_violations	\N	2026-02-06 16:18:05.052021	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 30, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:18:05.033Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
84	96	tab_switch	\N	2026-02-06 16:18:05.493909	18	38	tab_switch	medium	\N	{"count": 32, "timestamp": "2026-02-06T16:18:05.481Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
38	96	excessive_violations	\N	2026-02-06 16:16:52.778476	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 9, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:16:52.759Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
41	96	tab_switch	\N	2026-02-06 16:16:59.40991	18	38	tab_switch	medium	\N	{"count": 11, "timestamp": "2026-02-06T16:16:59.401Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
47	96	tab_switch	\N	2026-02-06 16:17:01.452723	18	38	tab_switch	medium	\N	{"count": 14, "timestamp": "2026-02-06T16:17:01.439Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
56	96	excessive_violations	\N	2026-02-06 16:17:41.036452	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 18, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:17:41.010Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
59	96	warning_dismissed	\N	2026-02-06 16:17:59.60034	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:17:59.585Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
62	96	tab_switch	\N	2026-02-06 16:18:00.508809	18	38	tab_switch	medium	\N	{"count": 21, "timestamp": "2026-02-06T16:18:00.501Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
71	96	excessive_violations	\N	2026-02-06 16:18:03.828877	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 25, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:18:03.814Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
77	96	excessive_violations	\N	2026-02-06 16:18:04.617621	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 28, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:18:04.602Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
80	96	tab_switch	\N	2026-02-06 16:18:05.043974	18	38	tab_switch	medium	\N	{"count": 30, "timestamp": "2026-02-06T16:18:05.032Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
40	96	excessive_violations	\N	2026-02-06 16:16:58.457952	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 10, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:16:58.440Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
43	96	tab_switch	\N	2026-02-06 16:17:00.037211	18	38	tab_switch	medium	\N	{"count": 12, "timestamp": "2026-02-06T16:17:00.023Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
52	96	excessive_violations	\N	2026-02-06 16:17:04.320236	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 16, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:17:04.307Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
55	96	tab_switch	\N	2026-02-06 16:17:41.027631	18	38	tab_switch	medium	\N	{"count": 18, "timestamp": "2026-02-06T16:17:41.009Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
64	96	tab_switch	\N	2026-02-06 16:18:01.124348	18	38	tab_switch	medium	\N	{"count": 22, "timestamp": "2026-02-06T16:18:01.111Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
73	96	excessive_violations	\N	2026-02-06 16:18:04.059436	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 26, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:18:04.042Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
79	96	excessive_violations	\N	2026-02-06 16:18:04.836138	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 29, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:18:04.824Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
85	96	excessive_violations	\N	2026-02-06 16:18:05.501921	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 32, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:18:05.482Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
42	96	excessive_violations	\N	2026-02-06 16:16:59.417937	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 11, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:16:59.401Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
45	96	tab_switch	\N	2026-02-06 16:17:00.60723	18	38	tab_switch	medium	\N	{"count": 13, "timestamp": "2026-02-06T16:17:00.597Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
51	96	tab_switch	\N	2026-02-06 16:17:04.312238	18	38	tab_switch	medium	\N	{"count": 16, "timestamp": "2026-02-06T16:17:04.307Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
60	96	tab_switch	\N	2026-02-06 16:17:59.60034	18	38	tab_switch	medium	\N	{"count": 20, "timestamp": "2026-02-06T16:17:59.588Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
63	96	excessive_violations	\N	2026-02-06 16:18:00.524805	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 21, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:18:00.502Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
66	96	tab_switch	\N	2026-02-06 16:18:01.686954	18	38	tab_switch	medium	\N	{"count": 23, "timestamp": "2026-02-06T16:18:01.676Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
72	96	tab_switch	\N	2026-02-06 16:18:04.05142	18	38	tab_switch	medium	\N	{"count": 26, "timestamp": "2026-02-06T16:18:04.041Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
78	96	tab_switch	\N	2026-02-06 16:18:04.836138	18	38	tab_switch	medium	\N	{"count": 29, "timestamp": "2026-02-06T16:18:04.823Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
44	96	excessive_violations	\N	2026-02-06 16:17:00.039638	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 12, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:17:00.024Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
50	96	excessive_violations	\N	2026-02-06 16:17:03.637071	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 15, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:17:03.623Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
53	96	tab_switch	\N	2026-02-06 16:17:40.12182	18	38	tab_switch	medium	\N	{"count": 17, "timestamp": "2026-02-06T16:17:40.107Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
65	96	excessive_violations	\N	2026-02-06 16:18:01.124348	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 22, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:18:01.112Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
68	96	tab_switch	\N	2026-02-06 16:18:03.351338	18	38	tab_switch	medium	\N	{"count": 24, "timestamp": "2026-02-06T16:18:03.341Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
74	96	tab_switch	\N	2026-02-06 16:18:04.251657	18	38	tab_switch	medium	\N	{"count": 27, "timestamp": "2026-02-06T16:18:04.244Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
83	96	excessive_violations	\N	2026-02-06 16:18:05.276688	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 31, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:18:05.262Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
86	96	tab_switch	\N	2026-02-06 16:18:20.533351	18	38	tab_switch	medium	\N	{"count": 33, "timestamp": "2026-02-06T16:18:20.521Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
87	96	excessive_violations	\N	2026-02-06 16:18:20.538441	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 33, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:18:20.522Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
88	96	tab_switch	\N	2026-02-06 16:19:04.237634	18	38	tab_switch	medium	\N	{"count": 34, "timestamp": "2026-02-06T16:19:04.223Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
89	96	excessive_violations	\N	2026-02-06 16:19:04.240032	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 34, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:04.225Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
90	96	warning_dismissed	\N	2026-02-06 16:19:05.227289	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:19:05.221Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
91	96	tab_switch	\N	2026-02-06 16:19:05.243277	18	38	tab_switch	medium	\N	{"count": 35, "timestamp": "2026-02-06T16:19:05.225Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
92	96	excessive_violations	\N	2026-02-06 16:19:05.251284	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 35, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:05.226Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
93	96	warning_dismissed	\N	2026-02-06 16:19:06.822172	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:19:06.807Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
94	96	tab_switch	\N	2026-02-06 16:19:06.825472	18	38	tab_switch	medium	\N	{"count": 36, "timestamp": "2026-02-06T16:19:06.812Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
95	96	excessive_violations	\N	2026-02-06 16:19:06.838871	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 36, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:06.813Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
96	96	tab_switch	\N	2026-02-06 16:19:08.489922	18	38	tab_switch	medium	\N	{"count": 37, "timestamp": "2026-02-06T16:19:08.483Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
97	96	excessive_violations	\N	2026-02-06 16:19:08.505964	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 37, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:08.484Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
98	96	tab_switch	\N	2026-02-06 16:19:08.9357	18	38	tab_switch	medium	\N	{"count": 38, "timestamp": "2026-02-06T16:19:08.927Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
99	96	excessive_violations	\N	2026-02-06 16:19:08.943699	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 38, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:08.929Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
102	96	tab_switch	\N	2026-02-06 16:19:09.267111	18	38	tab_switch	medium	\N	{"count": 40, "timestamp": "2026-02-06T16:19:09.255Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
111	96	excessive_violations	\N	2026-02-06 16:19:13.146704	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 44, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:13.141Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
120	96	excessive_violations	\N	2026-02-06 16:19:17.817641	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 48, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:17.807Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
123	96	excessive_violations	\N	2026-02-06 16:19:18.70954	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 49, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:18.685Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
131	96	warning_dismissed	\N	2026-02-06 16:19:24.711094	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:19:24.697Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
134	96	tab_switch	\N	2026-02-06 16:19:26.911623	18	38	tab_switch	medium	\N	{"count": 54, "timestamp": "2026-02-06T16:19:26.899Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
137	96	tab_switch	\N	2026-02-06 16:19:53.81787	18	38	tab_switch	medium	\N	{"count": 55, "timestamp": "2026-02-06T16:19:53.782Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
140	96	tab_switch	\N	2026-02-06 16:19:54.836812	18	38	tab_switch	medium	\N	{"count": 56, "timestamp": "2026-02-06T16:19:54.817Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
143	96	tab_switch	\N	2026-02-06 16:19:55.639754	18	38	tab_switch	medium	\N	{"count": 57, "timestamp": "2026-02-06T16:19:55.598Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
145	96	warning_dismissed	\N	2026-02-06 16:19:55.803587	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:19:55.783Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
151	96	warning_dismissed	\N	2026-02-06 16:19:56.307349	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:19:56.289Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
100	96	tab_switch	\N	2026-02-06 16:19:09.112834	18	38	tab_switch	medium	\N	{"count": 39, "timestamp": "2026-02-06T16:19:09.102Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
106	96	tab_switch	\N	2026-02-06 16:19:12.736902	18	38	tab_switch	medium	\N	{"count": 42, "timestamp": "2026-02-06T16:19:12.724Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
112	96	tab_switch	\N	2026-02-06 16:19:14.129249	18	38	tab_switch	medium	\N	{"count": 45, "timestamp": "2026-02-06T16:19:14.122Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
118	96	excessive_violations	\N	2026-02-06 16:19:17.627307	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 47, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:17.609Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
121	96	warning_dismissed	\N	2026-02-06 16:19:18.692721	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:19:18.680Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
124	96	tab_switch	\N	2026-02-06 16:19:19.372758	18	38	tab_switch	medium	\N	{"count": 50, "timestamp": "2026-02-06T16:19:19.363Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
128	96	excessive_violations	\N	2026-02-06 16:19:20.468093	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 51, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:20.385Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
136	96	warning_dismissed	\N	2026-02-06 16:19:53.793052	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:19:53.780Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
144	96	excessive_violations	\N	2026-02-06 16:19:55.643115	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 57, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:55.599Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
146	96	tab_switch	\N	2026-02-06 16:19:55.816907	18	38	tab_switch	medium	\N	{"count": 58, "timestamp": "2026-02-06T16:19:55.785Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
154	96	warning_dismissed	\N	2026-02-06 16:19:56.355759	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:19:56.319Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
101	96	excessive_violations	\N	2026-02-06 16:19:09.121108	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 39, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:09.103Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
104	96	tab_switch	\N	2026-02-06 16:19:12.485407	18	38	tab_switch	medium	\N	{"count": 41, "timestamp": "2026-02-06T16:19:12.480Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
110	96	tab_switch	\N	2026-02-06 16:19:13.146704	18	38	tab_switch	medium	\N	{"count": 44, "timestamp": "2026-02-06T16:19:13.140Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
113	96	excessive_violations	\N	2026-02-06 16:19:14.144903	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 45, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:14.123Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
122	96	tab_switch	\N	2026-02-06 16:19:18.699167	18	38	tab_switch	medium	\N	{"count": 49, "timestamp": "2026-02-06T16:19:18.683Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
147	96	excessive_violations	\N	2026-02-06 16:19:55.825171	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 58, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:55.786Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
148	96	warning_dismissed	\N	2026-02-06 16:19:56.039867	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:19:56.026Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
103	96	excessive_violations	\N	2026-02-06 16:19:09.267111	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 40, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:09.256Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
109	96	excessive_violations	\N	2026-02-06 16:19:12.935189	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 43, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:12.922Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
115	96	tab_switch	\N	2026-02-06 16:19:16.376183	18	38	tab_switch	medium	\N	{"count": 46, "timestamp": "2026-02-06T16:19:16.359Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
127	96	tab_switch	\N	2026-02-06 16:19:20.460102	18	38	tab_switch	medium	\N	{"count": 51, "timestamp": "2026-02-06T16:19:20.384Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
130	96	excessive_violations	\N	2026-02-06 16:19:21.817998	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 52, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:21.804Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
133	96	excessive_violations	\N	2026-02-06 16:19:24.744508	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 53, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:24.702Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
135	96	excessive_violations	\N	2026-02-06 16:19:26.919651	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 54, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:26.901Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
139	96	warning_dismissed	\N	2026-02-06 16:19:54.829258	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:19:54.816Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
150	96	tab_switch	\N	2026-02-06 16:19:56.056447	18	38	tab_switch	medium	\N	{"count": 59, "timestamp": "2026-02-06T16:19:56.028Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
152	96	tab_switch	\N	2026-02-06 16:19:56.339702	18	38	tab_switch	medium	\N	{"count": 60, "timestamp": "2026-02-06T16:19:56.314Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
105	96	excessive_violations	\N	2026-02-06 16:19:12.496976	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 41, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:12.481Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
108	96	tab_switch	\N	2026-02-06 16:19:12.930165	18	38	tab_switch	medium	\N	{"count": 43, "timestamp": "2026-02-06T16:19:12.921Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
114	96	warning_dismissed	\N	2026-02-06 16:19:16.368186	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:19:16.355Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
117	96	tab_switch	\N	2026-02-06 16:19:17.618899	18	38	tab_switch	medium	\N	{"count": 47, "timestamp": "2026-02-06T16:19:17.608Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
126	96	warning_dismissed	\N	2026-02-06 16:19:20.460102	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:19:20.380Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
129	96	tab_switch	\N	2026-02-06 16:19:21.809971	18	38	tab_switch	medium	\N	{"count": 52, "timestamp": "2026-02-06T16:19:21.804Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
132	96	tab_switch	\N	2026-02-06 16:19:24.722848	18	38	tab_switch	medium	\N	{"count": 53, "timestamp": "2026-02-06T16:19:24.701Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
138	96	excessive_violations	\N	2026-02-06 16:19:53.824028	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 55, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:53.783Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
141	96	excessive_violations	\N	2026-02-06 16:19:54.836812	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 56, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:54.818Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
153	96	excessive_violations	\N	2026-02-06 16:19:56.355759	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 60, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:56.317Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
107	96	excessive_violations	\N	2026-02-06 16:19:12.736902	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 42, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:12.725Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
116	96	excessive_violations	\N	2026-02-06 16:19:16.384288	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 46, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:16.361Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
119	96	tab_switch	\N	2026-02-06 16:19:17.817641	18	38	tab_switch	medium	\N	{"count": 48, "timestamp": "2026-02-06T16:19:17.806Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
125	96	excessive_violations	\N	2026-02-06 16:19:19.375507	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 50, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:19.364Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
142	96	warning_dismissed	\N	2026-02-06 16:19:55.617624	18	38	warning_dismissed	low	\N	{"violationType": "tab_switch", "timestamp": "2026-02-06T16:19:55.596Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
149	96	excessive_violations	\N	2026-02-06 16:19:56.056447	18	38	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 59, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T16:19:56.029Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
155	97	face_not_visible	\N	2026-02-06 21:32:10.955226	18	42	face_not_visible	medium	\N	{"duration": 15341, "warningCount": 1, "timestamp": "2026-02-06T21:32:10.940Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
156	97	face_not_visible	\N	2026-02-06 21:32:42.66662	18	42	face_not_visible	medium	\N	{"duration": 5990, "warningCount": 2, "timestamp": "2026-02-06T21:32:42.662Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
157	97	face_not_visible	\N	2026-02-06 21:32:57.659299	18	42	face_not_visible	medium	\N	{"duration": 5978, "warningCount": 3, "timestamp": "2026-02-06T21:32:57.641Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
158	97	face_not_visible	\N	2026-02-06 21:33:06.66548	18	42	face_not_visible	medium	\N	{"duration": 5967, "warningCount": 4, "timestamp": "2026-02-06T21:33:06.654Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
159	97	face_not_visible	\N	2026-02-06 21:33:30.642723	18	42	face_not_visible	medium	\N	{"duration": 5967, "warningCount": 5, "timestamp": "2026-02-06T21:33:30.642Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
160	97	excessive_violations	\N	2026-02-06 21:33:30.940215	18	42	excessive_violations	high	\N	{"violationType": "face_not_visible", "allViolations": {"tabSwitches": 0, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 5, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T21:33:30.643Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
161	97	tab_switch	\N	2026-02-06 21:35:04.894351	18	42	tab_switch	medium	\N	{"count": 1, "timestamp": "2026-02-06T21:35:04.886Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
162	98	face_not_visible	\N	2026-02-06 21:36:16.513724	16	42	face_not_visible	medium	\N	{"duration": 6125, "warningCount": 1, "timestamp": "2026-02-06T21:36:16.506Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
163	98	face_not_visible	\N	2026-02-06 21:37:11.806208	16	42	face_not_visible	medium	\N	{"duration": 5998, "warningCount": 2, "timestamp": "2026-02-06T21:37:11.779Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
164	98	face_not_visible	\N	2026-02-06 21:37:26.829197	16	42	face_not_visible	medium	\N	{"duration": 6019, "warningCount": 3, "timestamp": "2026-02-06T21:37:26.813Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
165	98	tab_switch	\N	2026-02-06 21:38:14.528273	16	42	tab_switch	medium	\N	{"count": 1, "timestamp": "2026-02-06T21:38:14.481Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
166	98	tab_switch	\N	2026-02-06 21:38:14.530667	16	42	tab_switch	medium	\N	{"count": 2, "timestamp": "2026-02-06T21:38:14.493Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
167	98	tab_switch	\N	2026-02-06 21:38:26.005583	16	42	tab_switch	medium	\N	{"count": 3, "timestamp": "2026-02-06T21:38:25.961Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
168	98	tab_switch	\N	2026-02-06 21:38:26.019103	16	42	tab_switch	medium	\N	{"count": 4, "timestamp": "2026-02-06T21:38:25.977Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
169	98	tab_switch	\N	2026-02-06 21:38:34.165453	16	42	tab_switch	medium	\N	{"count": 5, "timestamp": "2026-02-06T21:38:34.046Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
172	98	tab_switch	\N	2026-02-06 21:38:46.987099	16	42	tab_switch	medium	\N	{"count": 8, "timestamp": "2026-02-06T21:38:46.937Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
173	98	copy_attempt	\N	2026-02-06 21:39:01.339222	16	42	copy_attempt	low	\N	{"count": 1, "timestamp": "2026-02-06T21:39:01.319Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
174	98	copy_attempt	\N	2026-02-06 21:39:01.705713	16	42	copy_attempt	low	\N	{"count": 2, "timestamp": "2026-02-06T21:39:01.687Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
175	98	copy_attempt	\N	2026-02-06 21:39:06.787104	16	42	copy_attempt	low	\N	{"count": 3, "timestamp": "2026-02-06T21:39:06.763Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
176	98	copy_attempt	\N	2026-02-06 21:39:09.899171	16	42	copy_attempt	low	\N	{"count": 4, "timestamp": "2026-02-06T21:39:09.885Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
177	98	tab_switch	\N	2026-02-06 21:39:14.552603	16	42	tab_switch	medium	\N	{"count": 9, "timestamp": "2026-02-06T21:39:14.511Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
180	98	face_not_visible	\N	2026-02-06 21:39:15.580836	16	42	face_not_visible	medium	\N	{"duration": 5985, "warningCount": 4, "timestamp": "2026-02-06T21:39:15.573Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
182	98	excessive_violations	\N	2026-02-06 21:39:32.823399	16	42	excessive_violations	high	\N	{"violationType": "face_not_visible", "allViolations": {"tabSwitches": 10, "copyAttempts": 4, "pasteAttempts": 0, "noFaceWarnings": 5, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T21:39:32.806Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
183	98	copy_attempt	\N	2026-02-06 21:39:48.322424	16	42	copy_attempt	low	\N	{"count": 5, "timestamp": "2026-02-06T21:39:48.316Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
188	98	excessive_violations	\N	2026-02-06 21:40:37.886546	16	42	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 11, "copyAttempts": 5, "pasteAttempts": 0, "noFaceWarnings": 6, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T21:40:37.858Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
170	98	tab_switch	\N	2026-02-06 21:38:34.168978	16	42	tab_switch	medium	\N	{"count": 6, "timestamp": "2026-02-06T21:38:34.095Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
171	98	tab_switch	\N	2026-02-06 21:38:46.987099	16	42	tab_switch	medium	\N	{"count": 7, "timestamp": "2026-02-06T21:38:46.911Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
178	98	tab_switch	\N	2026-02-06 21:39:14.560607	16	42	tab_switch	medium	\N	{"count": 10, "timestamp": "2026-02-06T21:39:14.524Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
179	98	excessive_violations	\N	2026-02-06 21:39:14.625521	16	42	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 10, "copyAttempts": 4, "pasteAttempts": 0, "noFaceWarnings": 3, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T21:39:14.525Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
181	98	face_not_visible	\N	2026-02-06 21:39:32.817779	16	42	face_not_visible	medium	\N	{"duration": 6035, "warningCount": 5, "timestamp": "2026-02-06T21:39:32.805Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
184	98	excessive_violations	\N	2026-02-06 21:39:48.328771	16	42	excessive_violations	high	\N	{"violationType": "copy_attempt", "allViolations": {"tabSwitches": 10, "copyAttempts": 5, "pasteAttempts": 0, "noFaceWarnings": 5, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T21:39:48.317Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
185	98	face_not_visible	\N	2026-02-06 21:40:02.769884	16	42	face_not_visible	medium	\N	{"duration": 5945, "warningCount": 6, "timestamp": "2026-02-06T21:40:02.747Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
186	98	excessive_violations	\N	2026-02-06 21:40:02.778948	16	42	excessive_violations	high	\N	{"violationType": "face_not_visible", "allViolations": {"tabSwitches": 10, "copyAttempts": 5, "pasteAttempts": 0, "noFaceWarnings": 6, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T21:40:02.749Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
187	98	tab_switch	\N	2026-02-06 21:40:37.874397	16	42	tab_switch	medium	\N	{"count": 11, "timestamp": "2026-02-06T21:40:37.857Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
189	98	tab_switch	\N	2026-02-06 21:40:37.894136	16	42	tab_switch	medium	\N	{"count": 12, "timestamp": "2026-02-06T21:40:37.863Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
190	98	excessive_violations	\N	2026-02-06 21:40:37.978142	16	42	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 12, "copyAttempts": 5, "pasteAttempts": 0, "noFaceWarnings": 6, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T21:40:37.864Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
191	98	tab_switch	\N	2026-02-06 21:40:38.280508	16	42	tab_switch	medium	\N	{"count": 13, "timestamp": "2026-02-06T21:40:38.275Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
192	98	excessive_violations	\N	2026-02-06 21:40:38.291145	16	42	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 13, "copyAttempts": 5, "pasteAttempts": 0, "noFaceWarnings": 6, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-06T21:40:38.276Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
193	99	tab_switch	\N	2026-02-09 11:55:31.748084	18	40	tab_switch	medium	\N	{"count": 1, "timestamp": "2026-02-09T11:55:30.978Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) e-exam-platform/1.0.0 Chrome/144.0.7559.96 Electron/40.1.0 Safari/537.36", "screenResolution": "1366x768"}
194	100	tab_switch	\N	2026-02-11 16:13:47.826924	19	36	tab_switch	medium	\N	{"count": 1, "timestamp": "2026-02-11T16:13:47.782Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
195	100	tab_switch	\N	2026-02-11 16:13:48.201396	19	36	tab_switch	medium	\N	{"count": 2, "timestamp": "2026-02-11T16:13:48.108Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
196	100	tab_switch	\N	2026-02-11 16:13:58.903181	19	36	tab_switch	medium	\N	{"count": 3, "timestamp": "2026-02-11T16:13:58.768Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
197	100	tab_switch	\N	2026-02-11 16:13:58.911202	19	36	tab_switch	medium	\N	{"count": 4, "timestamp": "2026-02-11T16:13:58.824Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
198	100	tab_switch	\N	2026-02-11 16:14:05.285933	19	36	tab_switch	medium	\N	{"count": 5, "timestamp": "2026-02-11T16:14:05.234Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
199	100	tab_switch	\N	2026-02-11 16:14:05.293962	19	36	tab_switch	medium	\N	{"count": 6, "timestamp": "2026-02-11T16:14:05.251Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
200	100	tab_switch	\N	2026-02-11 16:14:17.266355	19	36	tab_switch	medium	\N	{"count": 7, "timestamp": "2026-02-11T16:14:17.203Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
201	100	tab_switch	\N	2026-02-11 16:14:17.271091	19	36	tab_switch	medium	\N	{"count": 8, "timestamp": "2026-02-11T16:14:17.224Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
202	100	tab_switch	\N	2026-02-11 16:15:17.685508	19	36	tab_switch	medium	\N	{"count": 9, "timestamp": "2026-02-11T16:15:17.671Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
205	100	tab_switch	\N	2026-02-11 16:15:19.478318	19	36	tab_switch	medium	\N	{"count": 11, "timestamp": "2026-02-11T16:15:19.478Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
203	100	tab_switch	\N	2026-02-11 16:15:17.685508	19	36	tab_switch	medium	\N	{"count": 10, "timestamp": "2026-02-11T16:15:17.673Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
204	100	excessive_violations	\N	2026-02-11 16:15:17.816297	19	36	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 10, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 0, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-11T16:15:17.675Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
206	100	excessive_violations	\N	2026-02-11 16:15:19.491833	19	36	excessive_violations	high	\N	{"violationType": "tab_switch", "allViolations": {"tabSwitches": 11, "copyAttempts": 0, "pasteAttempts": 0, "noFaceWarnings": 0, "multipleFaceWarnings": 0, "fullscreenExits": 0}, "timestamp": "2026-02-11T16:15:19.479Z", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", "screenResolution": "1366x768"}
\.


--
-- Data for Name: question_options; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.question_options (id, question_id, option_text, option_label, is_correct, latex_formula, created_at) FROM stdin;
1	1	on	A	t	\N	2026-01-15 04:35:06.611368
2	1	off	B	f	\N	2026-01-15 04:35:06.611368
3	1	go	C	f	\N	2026-01-15 04:35:06.611368
4	1	vv	D	f	\N	2026-01-15 04:35:06.611368
5	2	hjhj	A	f	\N	2026-01-15 04:35:48.674332
6	2	bh	B	t	\N	2026-01-15 04:35:48.674332
7	2	bnh	C	f	\N	2026-01-15 04:35:48.674332
8	2	hj	D	f	\N	2026-01-15 04:35:48.674332
9	3	bj	A	t	\N	2026-01-15 05:20:58.728255
10	3	hjh	B	f	\N	2026-01-15 05:20:58.728255
11	3	h	C	f	\N	2026-01-15 05:20:58.728255
12	3	jhjh	D	f	\N	2026-01-15 05:20:58.728255
13	4	ghggh	A	t	\N	2026-01-15 10:03:52.173265
14	4	kjk	B	f	\N	2026-01-15 10:03:52.173265
15	4	bjh	C	f	\N	2026-01-15 10:03:52.173265
16	4	hhjjh	D	f	\N	2026-01-15 10:03:52.173265
17	5	hjhj	A	t	\N	2026-01-15 10:08:43.109557
18	5	bh	B	f	\N	2026-01-15 10:08:43.109557
19	5	h	C	f	\N	2026-01-15 10:08:43.109557
20	5	jhjh	D	f	\N	2026-01-15 10:08:43.109557
21	6	True	A	t	\N	2026-01-15 13:00:43.745645
22	6	False	B	f	\N	2026-01-15 13:00:43.745645
23	7	NMJKDF	A	f	\N	2026-01-15 13:01:17.492562
24	7	JJFD	B	t	\N	2026-01-15 13:01:17.492562
25	7	JUIR	C	f	\N	2026-01-15 13:01:17.492562
26	7	HJHJ	D	f	\N	2026-01-15 13:01:17.492562
27	9	HJ	A	f	\N	2026-01-18 05:59:33.449155
28	9	B	B	t	\N	2026-01-18 05:59:33.449155
29	9	NBNB	C	f	\N	2026-01-18 05:59:33.449155
30	9	GG	D	f	\N	2026-01-18 05:59:33.449155
31	10	ff	A	t	\N	2026-01-20 11:16:29.456558
32	10	gff	B	f	\N	2026-01-20 11:16:29.456558
33	10	gf	C	f	\N	2026-01-20 11:16:29.456558
34	10	ghgf	D	f	\N	2026-01-20 11:16:29.456558
91	31	10.0	A	f	\N	2026-01-21 09:10:48.131101
92	31	11.0	B	f	\N	2026-01-21 09:10:48.131101
93	31	12.0	C	t	\N	2026-01-21 09:10:48.131101
94	31	13.0	D	f	\N	2026-01-21 09:10:48.131101
95	32	45.0	A	f	\N	2026-01-21 09:10:48.165288
96	32	54.0	B	t	\N	2026-01-21 09:10:48.165288
97	32	56.0	C	f	\N	2026-01-21 09:10:48.165288
98	32	64.0	D	f	\N	2026-01-21 09:10:48.165288
99	33	True	A	t	\N	2026-01-21 09:10:48.165288
100	33	False	B	f	\N	2026-01-21 09:10:48.165288
101	34	16.0	A	f	\N	2026-01-21 09:10:48.165288
102	34	32.0	B	f	\N	2026-01-21 09:10:48.165288
103	34	64.0	C	t	\N	2026-01-21 09:10:48.165288
104	34	128.0	D	f	\N	2026-01-21 09:10:48.165288
105	35	4.0	A	f	\N	2026-01-21 09:10:48.165288
106	35	5.0	B	t	\N	2026-01-21 09:10:48.165288
107	35	6.0	C	f	\N	2026-01-21 09:10:48.165288
108	35	8.0	D	f	\N	2026-01-21 09:10:48.165288
109	36	True	A	t	\N	2026-01-21 09:10:48.165288
110	36	False	B	f	\N	2026-01-21 09:10:48.165288
111	38	25.0	A	t	\N	2026-01-21 09:10:48.184613
112	38	12.0	B	f	\N	2026-01-21 09:10:48.184613
113	38	49.0	C	f	\N	2026-01-21 09:10:48.184613
114	38	7.0	D	f	\N	2026-01-21 09:10:48.184613
115	39	45.0	A	f	\N	2026-01-21 09:10:48.186612
116	39	55.0	B	t	\N	2026-01-21 09:10:48.186612
117	39	65.0	C	f	\N	2026-01-21 09:10:48.186612
118	39	75.0	D	f	\N	2026-01-21 09:10:48.186612
119	41	45	A	t	\N	2026-01-21 09:13:56.134865
120	41	3	B	f	\N	2026-01-21 09:13:56.134865
121	41	6	C	f	\N	2026-01-21 09:13:56.134865
122	41	89	D	f	\N	2026-01-21 09:13:56.134865
123	42	10.0	A	f	\N	2026-01-21 09:30:40.466234
124	42	11.0	B	f	\N	2026-01-21 09:30:40.466234
125	42	12.0	C	t	\N	2026-01-21 09:30:40.466234
126	42	13.0	D	f	\N	2026-01-21 09:30:40.466234
127	43	45.0	A	f	\N	2026-01-21 09:30:40.470381
128	43	54.0	B	t	\N	2026-01-21 09:30:40.470381
129	43	56.0	C	f	\N	2026-01-21 09:30:40.470381
130	43	64.0	D	f	\N	2026-01-21 09:30:40.470381
131	44	True	A	t	\N	2026-01-21 09:30:40.473382
132	44	False	B	f	\N	2026-01-21 09:30:40.473382
133	45	16.0	A	f	\N	2026-01-21 09:30:40.475381
134	45	32.0	B	f	\N	2026-01-21 09:30:40.475381
135	45	64.0	C	t	\N	2026-01-21 09:30:40.475381
136	45	128.0	D	f	\N	2026-01-21 09:30:40.475381
137	46	4.0	A	f	\N	2026-01-21 09:30:40.478374
138	46	5.0	B	t	\N	2026-01-21 09:30:40.478374
139	46	6.0	C	f	\N	2026-01-21 09:30:40.478374
140	46	8.0	D	f	\N	2026-01-21 09:30:40.478374
141	47	True	A	t	\N	2026-01-21 09:30:40.498513
142	47	False	B	f	\N	2026-01-21 09:30:40.498513
143	49	25.0	A	t	\N	2026-01-21 09:30:40.516805
144	49	12.0	B	f	\N	2026-01-21 09:30:40.516805
145	49	49.0	C	f	\N	2026-01-21 09:30:40.516805
146	49	7.0	D	f	\N	2026-01-21 09:30:40.516805
147	50	45.0	A	f	\N	2026-01-21 09:30:40.520786
148	50	55.0	B	t	\N	2026-01-21 09:30:40.520786
149	50	65.0	C	f	\N	2026-01-21 09:30:40.520786
150	50	75.0	D	f	\N	2026-01-21 09:30:40.520786
151	52	$\\sqrt{6}$	A	t	\N	2026-01-21 09:45:54.478722
152	52	7	B	f	\N	2026-01-21 09:45:54.478722
153	52	76	C	f	\N	2026-01-21 09:45:54.478722
154	52	60	D	f	\N	2026-01-21 09:45:54.478722
155	53	To meet friends	A	f	\N	2026-01-24 16:10:27.042344
156	53	To borrow books	B	t	\N	2026-01-24 16:10:27.042344
157	53	To write stories	C	f	\N	2026-01-24 16:10:27.042344
158	53	To work there	D	f	\N	2026-01-24 16:10:27.042344
159	54	Sports skills	A	f	\N	2026-01-24 16:10:27.125709
160	54	New words	B	t	\N	2026-01-24 16:10:27.125709
161	54	Cooking	C	f	\N	2026-01-24 16:10:27.125709
162	54	Music	D	f	\N	2026-01-24 16:10:27.125709
163	55	Made her famous	A	f	\N	2026-01-24 16:10:27.127251
164	55	Made her rich	B	f	\N	2026-01-24 16:10:27.127251
165	55	Made her an excellent writer	C	t	\N	2026-01-24 16:10:27.127251
166	55	Made her tired	D	f	\N	2026-01-24 16:10:27.127251
167	56	Old stories	A	f	\N	2026-01-24 16:10:27.127251
168	56	New stories	B	t	\N	2026-01-24 16:10:27.127251
169	56	Only poems	C	f	\N	2026-01-24 16:10:27.127251
170	56	Only textbooks	D	f	\N	2026-01-24 16:10:27.127251
171	57	School	A	f	\N	2026-01-24 16:10:27.127251
172	57	Bookstore	B	f	\N	2026-01-24 16:10:27.127251
173	57	Library	C	t	\N	2026-01-24 16:10:27.127251
174	57	Museum	D	f	\N	2026-01-24 16:10:27.127251
175	58	Weekdays	A	f	\N	2026-01-24 16:10:27.127251
176	58	Every weekend	B	t	\N	2026-01-24 16:10:27.127251
177	58	At night only	C	f	\N	2026-01-24 16:10:27.127251
178	58	Once a year	D	f	\N	2026-01-24 16:10:27.127251
179	59	Traveling	A	f	\N	2026-01-24 16:10:27.143331
180	59	Reading	B	t	\N	2026-01-24 16:10:27.143331
181	59	Watching TV	C	f	\N	2026-01-24 16:10:27.143331
182	59	Talking	D	f	\N	2026-01-24 16:10:27.143331
183	60	Writing	A	f	\N	2026-01-24 16:10:27.14633
184	60	Reading	B	t	\N	2026-01-24 16:10:27.14633
185	60	Dancing	C	f	\N	2026-01-24 16:10:27.14633
186	60	Singing	D	f	\N	2026-01-24 16:10:27.14633
187	61	Better memory	A	f	\N	2026-01-24 16:10:27.14933
188	61	New friends	B	f	\N	2026-01-24 16:10:27.14933
189	61	Better writing skills	C	t	\N	2026-01-24 16:10:27.14933
190	61	More money	D	f	\N	2026-01-24 16:10:27.14933
191	62	Friends	A	f	\N	2026-01-24 16:10:27.152324
192	62	School	B	f	\N	2026-01-24 16:10:27.152324
193	62	Books	C	t	\N	2026-01-24 16:10:27.152324
194	62	Internet	D	f	\N	2026-01-24 16:10:27.152324
195	63	Movies	A	f	\N	2026-01-24 16:10:27.155325
196	63	Music	B	f	\N	2026-01-24 16:10:27.155325
197	63	Reading books	C	t	\N	2026-01-24 16:10:27.155325
198	63	Sports	D	f	\N	2026-01-24 16:10:27.155325
199	64	Daily	A	f	\N	2026-01-24 16:10:27.195826
200	64	Monthly	B	f	\N	2026-01-24 16:10:27.195826
201	64	Every weekend	C	t	\N	2026-01-24 16:10:27.195826
202	64	Rarely	D	f	\N	2026-01-24 16:10:27.195826
203	65	Magazines	A	f	\N	2026-01-24 16:10:27.199826
204	65	Newspapers	B	f	\N	2026-01-24 16:10:27.199826
205	65	Stories	C	t	\N	2026-01-24 16:10:27.199826
206	65	Comics	D	f	\N	2026-01-24 16:10:27.199826
207	66	Speaking	A	f	\N	2026-01-24 16:10:27.202826
208	66	Writing	B	t	\N	2026-01-24 16:10:27.202826
209	66	Running	C	f	\N	2026-01-24 16:10:27.202826
210	66	Cooking	D	f	\N	2026-01-24 16:10:27.202826
211	67	Talent	A	f	\N	2026-01-24 16:10:27.205991
212	67	Practice	B	f	\N	2026-01-24 16:10:27.205991
213	67	Love for books	C	t	\N	2026-01-24 16:10:27.205991
214	67	Luck	D	f	\N	2026-01-24 16:10:27.205991
215	68	Math	A	f	\N	2026-01-24 16:10:27.208992
216	68	Science	B	f	\N	2026-01-24 16:10:27.208992
217	68	Cultures	C	t	\N	2026-01-24 16:10:27.208992
218	68	Sports	D	f	\N	2026-01-24 16:10:27.208992
219	69	Job	A	f	\N	2026-01-24 16:10:27.211999
220	69	Hobby	B	t	\N	2026-01-24 16:10:27.211999
221	69	Punishment	C	f	\N	2026-01-24 16:10:27.211999
222	69	Exercise	D	f	\N	2026-01-24 16:10:27.211999
223	70	Library rules	A	f	\N	2026-01-24 16:10:27.233112
224	70	Emma’s love for reading	B	t	\N	2026-01-24 16:10:27.233112
225	70	Writing exams	C	f	\N	2026-01-24 16:10:27.233112
226	70	School life	D	f	\N	2026-01-24 16:10:27.233112
227	71	Emma stopped reading	A	f	\N	2026-01-24 16:10:27.236322
228	71	Emma became a writer	B	t	\N	2026-01-24 16:10:27.236322
229	71	Emma changed schools	C	f	\N	2026-01-24 16:10:27.236322
230	71	Emma traveled	D	f	\N	2026-01-24 16:10:27.236322
231	72	Emma the Athlete	A	f	\N	2026-01-24 16:10:27.239323
232	72	A Day at School	B	f	\N	2026-01-24 16:10:27.239323
233	72	Love for Books	C	t	\N	2026-01-24 16:10:27.239323
234	72	The Library Building	D	f	\N	2026-01-24 16:10:27.239323
235	73	To meet friends	A	f	\N	2026-01-25 19:51:15.251857
236	73	To borrow books	B	t	\N	2026-01-25 19:51:15.251857
237	73	To write stories	C	f	\N	2026-01-25 19:51:15.251857
238	73	To work there	D	f	\N	2026-01-25 19:51:15.251857
239	74	Sports skills	A	f	\N	2026-01-25 19:51:15.475658
240	74	New words	B	t	\N	2026-01-25 19:51:15.475658
241	74	Cooking	C	f	\N	2026-01-25 19:51:15.475658
242	74	Music	D	f	\N	2026-01-25 19:51:15.475658
243	75	Made her famous	A	f	\N	2026-01-25 19:51:15.475658
244	75	Made her rich	B	f	\N	2026-01-25 19:51:15.475658
245	75	Made her an excellent writer	C	t	\N	2026-01-25 19:51:15.475658
246	75	Made her tired	D	f	\N	2026-01-25 19:51:15.475658
247	76	Old stories	A	f	\N	2026-01-25 19:51:15.475658
248	76	New stories	B	t	\N	2026-01-25 19:51:15.475658
249	76	Only poems	C	f	\N	2026-01-25 19:51:15.475658
250	76	Only textbooks	D	f	\N	2026-01-25 19:51:15.475658
251	77	School	A	f	\N	2026-01-25 19:51:15.475658
252	77	Bookstore	B	f	\N	2026-01-25 19:51:15.475658
253	77	Library	C	t	\N	2026-01-25 19:51:15.475658
254	77	Museum	D	f	\N	2026-01-25 19:51:15.475658
255	78	Weekdays	A	f	\N	2026-01-25 19:51:15.492633
256	78	Every weekend	B	t	\N	2026-01-25 19:51:15.492633
257	78	At night only	C	f	\N	2026-01-25 19:51:15.492633
258	78	Once a year	D	f	\N	2026-01-25 19:51:15.492633
259	79	Traveling	A	f	\N	2026-01-25 19:51:15.49664
260	79	Reading	B	t	\N	2026-01-25 19:51:15.49664
261	79	Watching TV	C	f	\N	2026-01-25 19:51:15.49664
262	79	Talking	D	f	\N	2026-01-25 19:51:15.49664
263	80	Writing	A	f	\N	2026-01-25 19:51:15.499638
264	80	Reading	B	t	\N	2026-01-25 19:51:15.499638
265	80	Dancing	C	f	\N	2026-01-25 19:51:15.499638
266	80	Singing	D	f	\N	2026-01-25 19:51:15.499638
267	81	Better memory	A	f	\N	2026-01-25 19:51:15.502638
268	81	New friends	B	f	\N	2026-01-25 19:51:15.502638
269	81	Better writing skills	C	t	\N	2026-01-25 19:51:15.502638
270	81	More money	D	f	\N	2026-01-25 19:51:15.502638
271	82	Friends	A	f	\N	2026-01-25 19:51:15.505639
272	82	School	B	f	\N	2026-01-25 19:51:15.505639
273	82	Books	C	t	\N	2026-01-25 19:51:15.505639
274	82	Internet	D	f	\N	2026-01-25 19:51:15.505639
275	83	Movies	A	f	\N	2026-01-25 19:51:15.508826
276	83	Music	B	f	\N	2026-01-25 19:51:15.508826
277	83	Reading books	C	t	\N	2026-01-25 19:51:15.508826
278	83	Sports	D	f	\N	2026-01-25 19:51:15.508826
279	84	Daily	A	f	\N	2026-01-25 19:51:15.51284
280	84	Monthly	B	f	\N	2026-01-25 19:51:15.51284
281	84	Every weekend	C	t	\N	2026-01-25 19:51:15.51284
282	84	Rarely	D	f	\N	2026-01-25 19:51:15.51284
283	85	Magazines	A	f	\N	2026-01-25 19:51:15.515828
284	85	Newspapers	B	f	\N	2026-01-25 19:51:15.515828
285	85	Stories	C	t	\N	2026-01-25 19:51:15.515828
286	85	Comics	D	f	\N	2026-01-25 19:51:15.515828
287	86	Speaking	A	f	\N	2026-01-25 19:51:15.724304
288	86	Writing	B	t	\N	2026-01-25 19:51:15.724304
289	86	Running	C	f	\N	2026-01-25 19:51:15.724304
290	86	Cooking	D	f	\N	2026-01-25 19:51:15.724304
291	87	Talent	A	f	\N	2026-01-25 19:51:15.735367
292	87	Practice	B	f	\N	2026-01-25 19:51:15.735367
293	87	Love for books	C	t	\N	2026-01-25 19:51:15.735367
294	87	Luck	D	f	\N	2026-01-25 19:51:15.735367
295	88	Math	A	f	\N	2026-01-25 19:51:15.746008
296	88	Science	B	f	\N	2026-01-25 19:51:15.746008
297	88	Cultures	C	t	\N	2026-01-25 19:51:15.746008
298	88	Sports	D	f	\N	2026-01-25 19:51:15.746008
299	89	Job	A	f	\N	2026-01-25 19:51:15.757001
300	89	Hobby	B	t	\N	2026-01-25 19:51:15.757001
301	89	Punishment	C	f	\N	2026-01-25 19:51:15.757001
302	89	Exercise	D	f	\N	2026-01-25 19:51:15.757001
303	90	Library rules	A	f	\N	2026-01-25 19:51:15.757317
304	90	Emma’s love for reading	B	t	\N	2026-01-25 19:51:15.757317
305	90	Writing exams	C	f	\N	2026-01-25 19:51:15.757317
306	90	School life	D	f	\N	2026-01-25 19:51:15.757317
307	91	Emma stopped reading	A	f	\N	2026-01-25 19:51:15.8085
308	91	Emma became a writer	B	t	\N	2026-01-25 19:51:15.8085
309	91	Emma changed schools	C	f	\N	2026-01-25 19:51:15.8085
310	91	Emma traveled	D	f	\N	2026-01-25 19:51:15.8085
311	92	Emma the Athlete	A	f	\N	2026-01-25 19:51:15.811498
312	92	A Day at School	B	f	\N	2026-01-25 19:51:15.811498
313	92	Love for Books	C	t	\N	2026-01-25 19:51:15.811498
314	92	The Library Building	D	f	\N	2026-01-25 19:51:15.811498
315	93	plant cell	A	t	\N	2026-01-26 21:27:38.990573
316	93	animal cell	B	f	\N	2026-01-26 21:27:38.990573
317	93	human cell	C	f	\N	2026-01-26 21:27:38.990573
318	93	goat cell	D	f	\N	2026-01-26 21:27:38.990573
319	94	5	A	f	\N	2026-01-26 21:29:10.283592
320	94	7	B	t	\N	2026-01-26 21:29:10.283592
321	94	8	C	f	\N	2026-01-26 21:29:10.283592
322	94	4	D	f	\N	2026-01-26 21:29:10.283592
323	95	mjfdk	A	t	\N	2026-01-27 14:09:39.167221
324	95	hhj	B	f	\N	2026-01-27 14:09:39.167221
325	95	mnjkdf	C	f	\N	2026-01-27 14:09:39.167221
326	95	jkdjkf	D	f	\N	2026-01-27 14:09:39.167221
327	96	rt	A	t	\N	2026-01-27 14:10:07.233956
328	96	sdds	B	f	\N	2026-01-27 14:10:07.233956
329	96	fdfr	C	f	\N	2026-01-27 14:10:07.233956
330	96	ghg	D	f	\N	2026-01-27 14:10:07.233956
331	97	DD	A	t	\N	2026-01-28 07:39:39.776043
332	97	GG	B	f	\N	2026-01-28 07:39:39.776043
333	97	TT	C	f	\N	2026-01-28 07:39:39.776043
334	97	HH	D	f	\N	2026-01-28 07:39:39.776043
335	98	10.0	A	f	\N	2026-01-28 07:40:08.788877
336	98	11.0	B	f	\N	2026-01-28 07:40:08.788877
337	98	12.0	C	t	\N	2026-01-28 07:40:08.788877
338	98	13.0	D	f	\N	2026-01-28 07:40:08.788877
339	99	45.0	A	f	\N	2026-01-28 07:40:08.792871
340	99	54.0	B	t	\N	2026-01-28 07:40:08.792871
341	99	56.0	C	f	\N	2026-01-28 07:40:08.792871
342	99	64.0	D	f	\N	2026-01-28 07:40:08.792871
343	100	True	A	t	\N	2026-01-28 07:40:08.795871
344	100	False	B	f	\N	2026-01-28 07:40:08.795871
345	101	16.0	A	f	\N	2026-01-28 07:40:08.798079
346	101	32.0	B	f	\N	2026-01-28 07:40:08.798079
347	101	64.0	C	t	\N	2026-01-28 07:40:08.798079
348	101	128.0	D	f	\N	2026-01-28 07:40:08.798079
349	102	4.0	A	f	\N	2026-01-28 07:40:08.798079
350	102	5.0	B	t	\N	2026-01-28 07:40:08.798079
351	102	6.0	C	f	\N	2026-01-28 07:40:08.798079
352	102	8.0	D	f	\N	2026-01-28 07:40:08.798079
353	103	True	A	t	\N	2026-01-28 07:40:08.798079
354	103	False	B	f	\N	2026-01-28 07:40:08.798079
355	105	25.0	A	t	\N	2026-01-28 07:40:08.798079
356	105	12.0	B	f	\N	2026-01-28 07:40:08.798079
357	105	49.0	C	f	\N	2026-01-28 07:40:08.798079
358	105	7.0	D	f	\N	2026-01-28 07:40:08.798079
359	106	45.0	A	f	\N	2026-01-28 07:40:08.8148
360	106	55.0	B	t	\N	2026-01-28 07:40:08.8148
361	106	65.0	C	f	\N	2026-01-28 07:40:08.8148
362	106	75.0	D	f	\N	2026-01-28 07:40:08.8148
363	108	To meet friends	A	f	\N	2026-01-28 10:50:09.824062
364	108	To borrow books	B	t	\N	2026-01-28 10:50:09.824062
365	108	To write stories	C	f	\N	2026-01-28 10:50:09.824062
366	108	To work there	D	f	\N	2026-01-28 10:50:09.824062
367	109	Sports skills	A	f	\N	2026-01-28 10:50:09.880803
368	109	New words	B	t	\N	2026-01-28 10:50:09.880803
369	109	Cooking	C	f	\N	2026-01-28 10:50:09.880803
370	109	Music	D	f	\N	2026-01-28 10:50:09.880803
371	110	Made her famous	A	f	\N	2026-01-28 10:50:09.884804
372	110	Made her rich	B	f	\N	2026-01-28 10:50:09.884804
373	110	Made her an excellent writer	C	t	\N	2026-01-28 10:50:09.884804
374	110	Made her tired	D	f	\N	2026-01-28 10:50:09.884804
375	111	Old stories	A	f	\N	2026-01-28 10:50:09.888858
376	111	New stories	B	t	\N	2026-01-28 10:50:09.888858
377	111	Only poems	C	f	\N	2026-01-28 10:50:09.888858
378	111	Only textbooks	D	f	\N	2026-01-28 10:50:09.888858
379	112	School	A	f	\N	2026-01-28 10:50:09.891858
380	112	Bookstore	B	f	\N	2026-01-28 10:50:09.891858
381	112	Library	C	t	\N	2026-01-28 10:50:09.891858
382	112	Museum	D	f	\N	2026-01-28 10:50:09.891858
383	113	Weekdays	A	f	\N	2026-01-28 10:50:09.894858
384	113	Every weekend	B	t	\N	2026-01-28 10:50:09.894858
385	113	At night only	C	f	\N	2026-01-28 10:50:09.894858
386	113	Once a year	D	f	\N	2026-01-28 10:50:09.894858
387	114	Traveling	A	f	\N	2026-01-28 10:50:09.898858
388	114	Reading	B	t	\N	2026-01-28 10:50:09.898858
389	114	Watching TV	C	f	\N	2026-01-28 10:50:09.898858
390	114	Talking	D	f	\N	2026-01-28 10:50:09.898858
391	115	Writing	A	f	\N	2026-01-28 10:50:09.901858
392	115	Reading	B	t	\N	2026-01-28 10:50:09.901858
393	115	Dancing	C	f	\N	2026-01-28 10:50:09.901858
394	115	Singing	D	f	\N	2026-01-28 10:50:09.901858
395	116	Better memory	A	f	\N	2026-01-28 10:50:09.903032
396	116	New friends	B	f	\N	2026-01-28 10:50:09.903032
397	116	Better writing skills	C	t	\N	2026-01-28 10:50:09.903032
398	116	More money	D	f	\N	2026-01-28 10:50:09.903032
399	117	Friends	A	f	\N	2026-01-28 10:50:09.903032
400	117	School	B	f	\N	2026-01-28 10:50:09.903032
401	117	Books	C	t	\N	2026-01-28 10:50:09.903032
402	117	Internet	D	f	\N	2026-01-28 10:50:09.903032
403	118	Movies	A	f	\N	2026-01-28 10:50:09.903032
404	118	Music	B	f	\N	2026-01-28 10:50:09.903032
405	118	Reading books	C	t	\N	2026-01-28 10:50:09.903032
406	118	Sports	D	f	\N	2026-01-28 10:50:09.903032
407	119	Daily	A	f	\N	2026-01-28 10:50:10.036343
408	119	Monthly	B	f	\N	2026-01-28 10:50:10.036343
409	119	Every weekend	C	t	\N	2026-01-28 10:50:10.036343
410	119	Rarely	D	f	\N	2026-01-28 10:50:10.036343
411	120	Magazines	A	f	\N	2026-01-28 10:50:10.075989
412	120	Newspapers	B	f	\N	2026-01-28 10:50:10.075989
413	120	Stories	C	t	\N	2026-01-28 10:50:10.075989
414	120	Comics	D	f	\N	2026-01-28 10:50:10.075989
415	121	Speaking	A	f	\N	2026-01-28 10:50:10.078989
416	121	Writing	B	t	\N	2026-01-28 10:50:10.078989
417	121	Running	C	f	\N	2026-01-28 10:50:10.078989
418	121	Cooking	D	f	\N	2026-01-28 10:50:10.078989
419	122	Talent	A	f	\N	2026-01-28 10:50:10.081989
420	122	Practice	B	f	\N	2026-01-28 10:50:10.081989
421	122	Love for books	C	t	\N	2026-01-28 10:50:10.081989
422	122	Luck	D	f	\N	2026-01-28 10:50:10.081989
423	123	Math	A	f	\N	2026-01-28 10:50:10.103003
424	123	Science	B	f	\N	2026-01-28 10:50:10.103003
425	123	Cultures	C	t	\N	2026-01-28 10:50:10.103003
426	123	Sports	D	f	\N	2026-01-28 10:50:10.103003
427	124	Job	A	f	\N	2026-01-28 10:50:10.103003
428	124	Hobby	B	t	\N	2026-01-28 10:50:10.103003
429	124	Punishment	C	f	\N	2026-01-28 10:50:10.103003
430	124	Exercise	D	f	\N	2026-01-28 10:50:10.103003
431	125	Library rules	A	f	\N	2026-01-28 10:50:10.103003
432	125	Emma’s love for reading	B	t	\N	2026-01-28 10:50:10.103003
433	125	Writing exams	C	f	\N	2026-01-28 10:50:10.103003
434	125	School life	D	f	\N	2026-01-28 10:50:10.103003
435	126	Emma stopped reading	A	f	\N	2026-01-28 10:50:10.119589
436	126	Emma became a writer	B	t	\N	2026-01-28 10:50:10.119589
437	126	Emma changed schools	C	f	\N	2026-01-28 10:50:10.119589
438	126	Emma traveled	D	f	\N	2026-01-28 10:50:10.119589
439	127	Emma the Athlete	A	f	\N	2026-01-28 10:50:10.122597
440	127	A Day at School	B	f	\N	2026-01-28 10:50:10.122597
441	127	Love for Books	C	t	\N	2026-01-28 10:50:10.122597
442	127	The Library Building	D	f	\N	2026-01-28 10:50:10.122597
443	128	To meet friends	A	f	\N	2026-01-28 16:13:21.784345
444	128	To borrow books	B	t	\N	2026-01-28 16:13:21.784345
445	128	To write stories	C	f	\N	2026-01-28 16:13:21.784345
446	128	To work there	D	f	\N	2026-01-28 16:13:21.784345
447	129	Sports skills	A	f	\N	2026-01-28 16:13:21.886709
448	129	New words	B	t	\N	2026-01-28 16:13:21.886709
449	129	Cooking	C	f	\N	2026-01-28 16:13:21.886709
450	129	Music	D	f	\N	2026-01-28 16:13:21.886709
451	130	Made her famous	A	f	\N	2026-01-28 16:13:21.891699
452	130	Made her rich	B	f	\N	2026-01-28 16:13:21.891699
453	130	Made her an excellent writer	C	t	\N	2026-01-28 16:13:21.891699
454	130	Made her tired	D	f	\N	2026-01-28 16:13:21.891699
455	131	Old stories	A	f	\N	2026-01-28 16:13:21.897708
456	131	New stories	B	t	\N	2026-01-28 16:13:21.897708
457	131	Only poems	C	f	\N	2026-01-28 16:13:21.897708
458	131	Only textbooks	D	f	\N	2026-01-28 16:13:21.897708
459	132	School	A	f	\N	2026-01-28 16:13:21.898692
460	132	Bookstore	B	f	\N	2026-01-28 16:13:21.898692
461	132	Library	C	t	\N	2026-01-28 16:13:21.898692
462	132	Museum	D	f	\N	2026-01-28 16:13:21.898692
463	133	Weekdays	A	f	\N	2026-01-28 16:13:21.898692
464	133	Every weekend	B	t	\N	2026-01-28 16:13:21.898692
465	133	At night only	C	f	\N	2026-01-28 16:13:21.898692
466	133	Once a year	D	f	\N	2026-01-28 16:13:21.898692
467	134	Traveling	A	f	\N	2026-01-28 16:13:21.913718
468	134	Reading	B	t	\N	2026-01-28 16:13:21.913718
469	134	Watching TV	C	f	\N	2026-01-28 16:13:21.913718
470	134	Talking	D	f	\N	2026-01-28 16:13:21.913718
471	135	Writing	A	f	\N	2026-01-28 16:13:21.917502
472	135	Reading	B	t	\N	2026-01-28 16:13:21.917502
473	135	Dancing	C	f	\N	2026-01-28 16:13:21.917502
474	135	Singing	D	f	\N	2026-01-28 16:13:21.917502
475	136	Better memory	A	f	\N	2026-01-28 16:13:21.917502
476	136	New friends	B	f	\N	2026-01-28 16:13:21.917502
477	136	Better writing skills	C	t	\N	2026-01-28 16:13:21.917502
478	136	More money	D	f	\N	2026-01-28 16:13:21.917502
479	137	Friends	A	f	\N	2026-01-28 16:13:21.917502
480	137	School	B	f	\N	2026-01-28 16:13:21.917502
481	137	Books	C	t	\N	2026-01-28 16:13:21.917502
482	137	Internet	D	f	\N	2026-01-28 16:13:21.917502
483	138	Movies	A	f	\N	2026-01-28 16:13:21.93522
484	138	Music	B	f	\N	2026-01-28 16:13:21.93522
485	138	Reading books	C	t	\N	2026-01-28 16:13:21.93522
486	138	Sports	D	f	\N	2026-01-28 16:13:21.93522
487	139	Daily	A	f	\N	2026-01-28 16:13:21.94023
488	139	Monthly	B	f	\N	2026-01-28 16:13:21.94023
489	139	Every weekend	C	t	\N	2026-01-28 16:13:21.94023
490	139	Rarely	D	f	\N	2026-01-28 16:13:21.94023
491	140	Magazines	A	f	\N	2026-01-28 16:13:21.945229
492	140	Newspapers	B	f	\N	2026-01-28 16:13:21.945229
493	140	Stories	C	t	\N	2026-01-28 16:13:21.945229
494	140	Comics	D	f	\N	2026-01-28 16:13:21.945229
495	141	Speaking	A	f	\N	2026-01-28 16:13:22.007234
496	141	Writing	B	t	\N	2026-01-28 16:13:22.007234
497	141	Running	C	f	\N	2026-01-28 16:13:22.007234
498	141	Cooking	D	f	\N	2026-01-28 16:13:22.007234
499	142	Talent	A	f	\N	2026-01-28 16:13:22.012225
500	142	Practice	B	f	\N	2026-01-28 16:13:22.012225
501	142	Love for books	C	t	\N	2026-01-28 16:13:22.012225
502	142	Luck	D	f	\N	2026-01-28 16:13:22.012225
503	143	Math	A	f	\N	2026-01-28 16:13:22.015599
504	143	Science	B	f	\N	2026-01-28 16:13:22.015599
505	143	Cultures	C	t	\N	2026-01-28 16:13:22.015599
506	143	Sports	D	f	\N	2026-01-28 16:13:22.015599
507	144	Job	A	f	\N	2026-01-28 16:13:22.015599
508	144	Hobby	B	t	\N	2026-01-28 16:13:22.015599
509	144	Punishment	C	f	\N	2026-01-28 16:13:22.015599
510	144	Exercise	D	f	\N	2026-01-28 16:13:22.015599
511	145	Library rules	A	f	\N	2026-01-28 16:13:22.015599
512	145	Emma’s love for reading	B	t	\N	2026-01-28 16:13:22.015599
513	145	Writing exams	C	f	\N	2026-01-28 16:13:22.015599
514	145	School life	D	f	\N	2026-01-28 16:13:22.015599
515	146	Emma stopped reading	A	f	\N	2026-01-28 16:13:22.031234
516	146	Emma became a writer	B	t	\N	2026-01-28 16:13:22.031234
517	146	Emma changed schools	C	f	\N	2026-01-28 16:13:22.031234
518	146	Emma traveled	D	f	\N	2026-01-28 16:13:22.031234
519	147	Emma the Athlete	A	f	\N	2026-01-28 16:13:22.031234
520	147	A Day at School	B	f	\N	2026-01-28 16:13:22.031234
521	147	Love for Books	C	t	\N	2026-01-28 16:13:22.031234
522	147	The Library Building	D	f	\N	2026-01-28 16:13:22.031234
523	148	10.0	A	f	\N	2026-01-28 22:12:28.509021
524	148	11.0	B	f	\N	2026-01-28 22:12:28.509021
525	148	12.0	C	t	\N	2026-01-28 22:12:28.509021
526	148	13.0	D	f	\N	2026-01-28 22:12:28.509021
527	149	45.0	A	f	\N	2026-01-28 22:12:28.618472
528	149	54.0	B	t	\N	2026-01-28 22:12:28.618472
529	149	56.0	C	f	\N	2026-01-28 22:12:28.618472
530	149	64.0	D	f	\N	2026-01-28 22:12:28.618472
531	150	True	A	t	\N	2026-01-28 22:12:28.618472
532	150	False	B	f	\N	2026-01-28 22:12:28.618472
533	151	16.0	A	f	\N	2026-01-28 22:12:28.618472
534	151	32.0	B	f	\N	2026-01-28 22:12:28.618472
535	151	64.0	C	t	\N	2026-01-28 22:12:28.618472
536	151	128.0	D	f	\N	2026-01-28 22:12:28.618472
537	152	4.0	A	f	\N	2026-01-28 22:12:28.62949
538	152	5.0	B	t	\N	2026-01-28 22:12:28.62949
539	152	6.0	C	f	\N	2026-01-28 22:12:28.62949
540	152	8.0	D	f	\N	2026-01-28 22:12:28.62949
541	153	True	A	t	\N	2026-01-28 22:12:28.63368
542	153	False	B	f	\N	2026-01-28 22:12:28.63368
543	155	25.0	A	t	\N	2026-01-28 22:12:28.637691
544	155	12.0	B	f	\N	2026-01-28 22:12:28.637691
545	155	49.0	C	f	\N	2026-01-28 22:12:28.637691
546	155	7.0	D	f	\N	2026-01-28 22:12:28.637691
547	156	45.0	A	f	\N	2026-01-28 22:12:28.637691
548	156	55.0	B	t	\N	2026-01-28 22:12:28.637691
549	156	65.0	C	f	\N	2026-01-28 22:12:28.637691
550	156	75.0	D	f	\N	2026-01-28 22:12:28.637691
551	158	Tissue	A	f	\N	2026-02-04 12:48:51.24154
552	158	Organ	B	f	\N	2026-02-04 12:48:51.24154
553	158	Cell	C	t	\N	2026-02-04 12:48:51.24154
554	158	System	D	f	\N	2026-02-04 12:48:51.24154
555	159	Lungs	A	f	\N	2026-02-04 12:48:51.574412
556	159	Brain	B	f	\N	2026-02-04 12:48:51.574412
557	159	Heart	C	t	\N	2026-02-04 12:48:51.574412
558	159	Kidney	D	f	\N	2026-02-04 12:48:51.574412
559	160	Respiration	A	f	\N	2026-02-04 12:48:51.813792
560	160	Photosynthesis	B	t	\N	2026-02-04 12:48:51.813792
561	160	Digestion	C	f	\N	2026-02-04 12:48:51.813792
562	160	Transpiration	D	f	\N	2026-02-04 12:48:51.813792
563	161	Carbon dioxide	A	f	\N	2026-02-04 12:48:51.823066
564	161	Oxygen	B	t	\N	2026-02-04 12:48:51.823066
565	161	Nitrogen	C	f	\N	2026-02-04 12:48:51.823066
566	161	Hydrogen	D	f	\N	2026-02-04 12:48:51.823066
567	162	Leaf	A	f	\N	2026-02-04 12:48:51.839894
568	162	Root	B	f	\N	2026-02-04 12:48:51.839894
569	162	Stem	C	t	\N	2026-02-04 12:48:51.839894
570	162	Flower	D	f	\N	2026-02-04 12:48:51.839894
571	163	Heart	A	f	\N	2026-02-04 12:48:51.853641
572	163	Skin	B	t	\N	2026-02-04 12:48:51.853641
573	163	Liver	C	f	\N	2026-02-04 12:48:51.853641
574	163	Brain	D	f	\N	2026-02-04 12:48:51.853641
575	164	Red blood cells	A	f	\N	2026-02-04 12:48:51.861705
576	164	Platelets	B	f	\N	2026-02-04 12:48:51.861705
577	164	White blood cells	C	t	\N	2026-02-04 12:48:51.861705
578	164	Plasma	D	f	\N	2026-02-04 12:48:51.861705
579	165	Make food	A	f	\N	2026-02-04 12:48:51.878042
580	165	Support and absorb water	B	t	\N	2026-02-04 12:48:51.878042
581	165	Reproduction	C	f	\N	2026-02-04 12:48:51.878042
582	165	Transport food	D	f	\N	2026-02-04 12:48:51.878042
583	166	Stomach	A	f	\N	2026-02-04 12:48:51.886109
584	166	Heart	B	f	\N	2026-02-04 12:48:51.886109
585	166	Lungs	C	t	\N	2026-02-04 12:48:51.886109
586	166	Intestine	D	f	\N	2026-02-04 12:48:51.886109
587	167	Meat	A	f	\N	2026-02-04 12:48:51.894107
588	167	Plants	B	t	\N	2026-02-04 12:48:51.894107
589	167	Both plants and animals	C	f	\N	2026-02-04 12:48:51.894107
590	167	Insects	D	f	\N	2026-02-04 12:48:51.894107
591	168	Kidney	A	t	\N	2026-02-04 12:51:16.72721
592	168	Heart	B	f	\N	2026-02-04 12:51:16.72721
593	168	Lung	C	f	\N	2026-02-04 12:51:16.72721
594	168	Liver	D	f	\N	2026-02-04 12:51:16.72721
595	169	Heart	A	f	\N	2026-02-04 12:54:48.459123
596	169	Lung	B	f	\N	2026-02-04 12:54:48.459123
597	169	Liver	C	f	\N	2026-02-04 12:54:48.459123
598	169	kidney	D	f	\N	2026-02-04 12:54:48.459123
599	170	2015	A	t	\N	2026-02-04 20:08:06.895174
600	170	2016	B	f	\N	2026-02-04 20:08:06.895174
601	170	2017	C	f	\N	2026-02-04 20:08:06.895174
602	170	2020	D	f	\N	2026-02-04 20:08:06.895174
603	171	x	A	f	\N	2026-02-11 16:09:38.060215
604	171	2x	B	t	\N	2026-02-11 16:09:38.060215
605	171	x²	C	f	\N	2026-02-11 16:09:38.060215
606	171	2	D	f	\N	2026-02-11 16:09:38.060215
607	172	x²	A	f	\N	2026-02-11 16:09:38.548885
608	172	x² + C	B	f	\N	2026-02-11 16:09:38.548885
609	172	x²/2 + C	C	t	\N	2026-02-11 16:09:38.548885
610	172	2x + C	D	f	\N	2026-02-11 16:09:38.548885
611	173	x = 2	A	f	\N	2026-02-11 16:09:38.56415
612	173	x = −2	B	f	\N	2026-02-11 16:09:38.56415
613	173	x = ±2	C	t	\N	2026-02-11 16:09:38.56415
614	173	x = 4	D	f	\N	2026-02-11 16:09:38.56415
615	174	x + 2 = 0	A	f	\N	2026-02-11 16:09:38.57922
616	174	x² + 3x + 2 = 0	B	t	\N	2026-02-11 16:09:38.57922
617	174	2x − 1 = 0	C	f	\N	2026-02-11 16:09:38.57922
618	174	x³ + 1 = 0	D	f	\N	2026-02-11 16:09:38.57922
619	175	1/6	A	f	\N	2026-02-11 16:09:38.584998
620	175	1/4	B	f	\N	2026-02-11 16:09:38.584998
621	175	3/4	C	t	\N	2026-02-11 16:09:38.584998
622	175	1/2	D	f	\N	2026-02-11 16:09:38.584998
623	176	5	A	t	\N	2026-02-11 16:09:38.603221
624	176	x	B	f	\N	2026-02-11 16:09:38.603221
625	176	5x	C	f	\N	2026-02-11 16:09:38.603221
626	176	0	D	f	\N	2026-02-11 16:09:38.603221
627	177	x³ + C	A	t	\N	2026-02-11 16:09:38.61127
628	177	3x³ + C	B	f	\N	2026-02-11 16:09:38.61127
629	177	x³ + 3C	C	f	\N	2026-02-11 16:09:38.61127
630	177	x² + C	D	f	\N	2026-02-11 16:09:38.61127
631	178	x = −2, −3	A	t	\N	2026-02-11 16:09:38.61931
632	178	x = 2, 3	B	f	\N	2026-02-11 16:09:38.61931
633	178	x = −1, −6	C	f	\N	2026-02-11 16:09:38.61931
634	178	x = 1, 6	D	f	\N	2026-02-11 16:09:38.61931
635	179	0.3	A	f	\N	2026-02-11 16:09:38.61931
636	179	0.5	B	f	\N	2026-02-11 16:09:38.61931
637	179	0.6	C	t	\N	2026-02-11 16:09:38.61931
638	179	0.8	D	f	\N	2026-02-11 16:09:38.61931
639	180	Integration	A	f	\N	2026-02-11 16:09:38.630573
640	180	Fraction	B	f	\N	2026-02-11 16:09:38.630573
641	180	Differentiation	C	t	\N	2026-02-11 16:09:38.630573
642	180	Quadratic	D	f	\N	2026-02-11 16:09:38.630573
\.


--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.questions (id, exam_id, question_text, question_type, marks, "order", instructions, image, latex_support, created_at, updated_at) FROM stdin;
1	4	hggfgfcfgcf	mcq	1	1	answer all	\N	t	2026-01-15 04:35:06.434645	2026-01-15 04:35:06.434645
2	4	uuyytgygty	mcq	1	2		\N	t	2026-01-15 04:35:48.666537	2026-01-15 04:35:48.666537
3	5	hyuuy	mcq	1	1		\N	t	2026-01-15 05:20:58.728255	2026-01-15 05:20:58.728255
4	4	ghgygfgfhgy hgtytrdrtfy	mcq	1	3	answer all	20260115_100352_booking_status.png	t	2026-01-15 10:03:52.173265	2026-01-15 10:03:52.173265
5	4	the image below	mcq	1	4		20260115_100843_Simple_diagram_of_plant_cell_en.svg.png	t	2026-01-15 10:08:43.10156	2026-01-15 10:08:43.10156
6	6	FGDJJFJKFDJKJKFDGJJFDG	true_false	1	1		\N	t	2026-01-15 13:00:43.595733	2026-01-15 13:00:43.595733
7	6	JKIUIUHJREUHUITRIHUTR	mcq	1	2		\N	t	2026-01-15 13:01:17.492562	2026-01-15 13:01:17.492562
8	2	$X^2$ +4X=50	theory	1	1		\N	t	2026-01-15 15:53:38.722782	2026-01-15 15:53:38.722782
9	2	TGHGHFFGGFGF	mcq	1	2		20260118_055932_IMG-20250507-WA0010.jpg	t	2026-01-18 05:59:32.128937	2026-01-18 05:59:32.128937
10	7	fgdgffggf	mcq	1	1		\N	t	2026-01-20 11:16:29.009563	2026-01-20 11:16:29.009563
32	11	Solve: 9 × 6	mcq	5	2	\N	\N	t	2026-01-21 09:10:48.128292	2026-01-21 09:10:48.128292
33	11	Is 15 a multiple of 3?	true_false	3	3	\N	\N	t	2026-01-21 09:10:48.165288	2026-01-21 09:10:48.165288
34	11	What is the square of 8?	mcq	5	4	\N	\N	t	2026-01-21 09:10:48.165288	2026-01-21 09:10:48.165288
35	11	Solve: 20 ÷ 4	mcq	5	5	\N	\N	t	2026-01-21 09:10:48.165288	2026-01-21 09:10:48.165288
36	11	π is approximately equal to 3.14	true_false	3	6	\N	\N	t	2026-01-21 09:10:48.165288	2026-01-21 09:10:48.165288
37	11	Find the value of x if x + 10 = 25	theory	6	7	\N	\N	t	2026-01-21 09:10:48.165288	2026-01-21 09:10:48.165288
38	11	What is 3² + 4²?	mcq	5	8	\N	\N	t	2026-01-21 09:10:48.181614	2026-01-21 09:10:48.181614
39	11	Solve: 100 − 45	mcq	5	9	\N	\N	t	2026-01-21 09:10:48.183612	2026-01-21 09:10:48.183612
40	11	What is the LCM of 4 and 6?	theory	6	10	\N	\N	t	2026-01-21 09:10:48.186612	2026-01-21 09:10:48.186612
31	11	What is 5 + 7?	mcq	5	1	None	\N	t	2026-01-21 09:10:48.125292	2026-01-21 09:11:45.625376
41	11	solve $x^2 +y^2$	mcq	1	11		\N	t	2026-01-21 09:13:56.13187	2026-01-21 09:13:56.13187
42	11	What is 5 + 7?	mcq	5	12	\N	\N	t	2026-01-21 09:30:40.462563	2026-01-21 09:30:40.462563
43	11	Solve: 9 × 6	mcq	5	13	\N	\N	t	2026-01-21 09:30:40.465237	2026-01-21 09:30:40.465237
44	11	Is 15 a multiple of 3?	true_false	3	14	\N	\N	t	2026-01-21 09:30:40.469383	2026-01-21 09:30:40.469383
45	11	What is the square of 8?	mcq	5	15	\N	\N	t	2026-01-21 09:30:40.472381	2026-01-21 09:30:40.472381
46	11	Solve: 20 ÷ 4	mcq	5	16	\N	\N	t	2026-01-21 09:30:40.474381	2026-01-21 09:30:40.474381
47	11	π is approximately equal to 3.14	true_false	3	17	\N	\N	t	2026-01-21 09:30:40.477382	2026-01-21 09:30:40.477382
48	11	Find the value of x if x + 10 = 25	theory	6	18	\N	\N	t	2026-01-21 09:30:40.498513	2026-01-21 09:30:40.498513
49	11	What is 3² + 4²?	mcq	5	19	\N	\N	t	2026-01-21 09:30:40.514797	2026-01-21 09:30:40.514797
50	11	Solve: 100 − 45	mcq	5	20	\N	\N	t	2026-01-21 09:30:40.515797	2026-01-21 09:30:40.515797
51	11	What is the LCM of 4 and 6?	theory	6	21	\N	\N	t	2026-01-21 09:30:40.519787	2026-01-21 09:30:40.519787
52	11	solve $x^2 +y^2$	mcq	1	22		\N	t	2026-01-21 09:45:54.478722	2026-01-21 09:45:54.478722
53	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhy did Emma visit the library every weekend?	mcq	5	1	\N	\N	t	2026-01-24 16:10:26.773509	2026-01-24 16:10:26.773509
54	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did reading help Emma learn?	mcq	5	2	\N	\N	t	2026-01-24 16:10:27.042344	2026-01-24 16:10:27.042344
55	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nHow did reading affect Emma over time?	mcq	5	3	\N	\N	t	2026-01-24 16:10:27.109072	2026-01-24 16:10:27.109072
56	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat kind of stories did Emma borrow?	mcq	5	4	\N	\N	t	2026-01-24 16:10:27.127251	2026-01-24 16:10:27.127251
57	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat place is mentioned in the passage?	mcq	5	5	\N	\N	t	2026-01-24 16:10:27.127251	2026-01-24 16:10:27.127251
58	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhen did Emma usually read?	mcq	5	6	\N	\N	t	2026-01-24 16:10:27.127251	2026-01-24 16:10:27.127251
59	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat helped Emma understand different cultures?	mcq	5	7	\N	\N	t	2026-01-24 16:10:27.127251	2026-01-24 16:10:27.127251
60	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat was Emma's main hobby?	mcq	5	8	\N	\N	t	2026-01-24 16:10:27.142311	2026-01-24 16:10:27.142311
61	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat benefit did Emma get from reading?	mcq	5	9	\N	\N	t	2026-01-24 16:10:27.14533	2026-01-24 16:10:27.14533
62	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhere did Emma get new words from?	mcq	5	10	\N	\N	t	2026-01-24 16:10:27.14833	2026-01-24 16:10:27.14833
63	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did Emma love?	mcq	5	11	\N	\N	t	2026-01-24 16:10:27.15133	2026-01-24 16:10:27.15133
64	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nHow often did Emma go to the library?	mcq	5	12	\N	\N	t	2026-01-24 16:10:27.15433	2026-01-24 16:10:27.15433
65	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did Emma borrow from the library?	mcq	5	13	\N	\N	t	2026-01-24 16:10:27.15833	2026-01-24 16:10:27.15833
66	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat skill improved because of reading?	mcq	5	14	\N	\N	t	2026-01-24 16:10:27.198833	2026-01-24 16:10:27.198833
67	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhy was Emma an excellent writer?	mcq	5	15	\N	\N	t	2026-01-24 16:10:27.201832	2026-01-24 16:10:27.201832
68	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did reading help Emma understand?	mcq	5	16	\N	\N	t	2026-01-24 16:10:27.204832	2026-01-24 16:10:27.204832
69	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat kind of activity is reading for Emma?	mcq	5	17	\N	\N	t	2026-01-24 16:10:27.207999	2026-01-24 16:10:27.207999
70	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat does the passage mainly talk about?	mcq	5	18	\N	\N	t	2026-01-24 16:10:27.210999	2026-01-24 16:10:27.210999
71	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat happened over time?	mcq	5	19	\N	\N	t	2026-01-24 16:10:27.232114	2026-01-24 16:10:27.232114
72	9	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat is the best title for the passage?	mcq	5	20	\N	\N	t	2026-01-24 16:10:27.236322	2026-01-24 16:10:27.236322
73	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhy did Emma visit the library every weekend?	mcq	5	1	\N	\N	t	2026-01-25 19:51:15.190926	2026-01-25 19:51:15.190926
74	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did reading help Emma learn?	mcq	5	2	\N	\N	t	2026-01-25 19:51:15.245859	2026-01-25 19:51:15.245859
75	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nHow did reading affect Emma over time?	mcq	5	3	\N	\N	t	2026-01-25 19:51:15.475658	2026-01-25 19:51:15.475658
76	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat kind of stories did Emma borrow?	mcq	5	4	\N	\N	t	2026-01-25 19:51:15.475658	2026-01-25 19:51:15.475658
77	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat place is mentioned in the passage?	mcq	5	5	\N	\N	t	2026-01-25 19:51:15.475658	2026-01-25 19:51:15.475658
78	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhen did Emma usually read?	mcq	5	6	\N	\N	t	2026-01-25 19:51:15.475658	2026-01-25 19:51:15.475658
79	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat helped Emma understand different cultures?	mcq	5	7	\N	\N	t	2026-01-25 19:51:15.490619	2026-01-25 19:51:15.490619
80	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat was Emma's main hobby?	mcq	5	8	\N	\N	t	2026-01-25 19:51:15.495639	2026-01-25 19:51:15.495639
81	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat benefit did Emma get from reading?	mcq	5	9	\N	\N	t	2026-01-25 19:51:15.498639	2026-01-25 19:51:15.498639
82	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhere did Emma get new words from?	mcq	5	10	\N	\N	t	2026-01-25 19:51:15.501638	2026-01-25 19:51:15.501638
83	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did Emma love?	mcq	5	11	\N	\N	t	2026-01-25 19:51:15.504638	2026-01-25 19:51:15.504638
84	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nHow often did Emma go to the library?	mcq	5	12	\N	\N	t	2026-01-25 19:51:15.507816	2026-01-25 19:51:15.507816
85	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did Emma borrow from the library?	mcq	5	13	\N	\N	t	2026-01-25 19:51:15.511828	2026-01-25 19:51:15.511828
86	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat skill improved because of reading?	mcq	5	14	\N	\N	t	2026-01-25 19:51:15.514825	2026-01-25 19:51:15.514825
87	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhy was Emma an excellent writer?	mcq	5	15	\N	\N	t	2026-01-25 19:51:15.707489	2026-01-25 19:51:15.707489
88	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did reading help Emma understand?	mcq	5	16	\N	\N	t	2026-01-25 19:51:15.732348	2026-01-25 19:51:15.732348
89	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat kind of activity is reading for Emma?	mcq	5	17	\N	\N	t	2026-01-25 19:51:15.743016	2026-01-25 19:51:15.743016
90	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat does the passage mainly talk about?	mcq	5	18	\N	\N	t	2026-01-25 19:51:15.753006	2026-01-25 19:51:15.753006
91	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat happened over time?	mcq	5	19	\N	\N	t	2026-01-25 19:51:15.757317	2026-01-25 19:51:15.757317
92	12	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat is the best title for the passage?	mcq	5	20	\N	\N	t	2026-01-25 19:51:15.806538	2026-01-25 19:51:15.806538
93	14	the image below is known as	mcq	1	1		1769459258_Simple_diagram_of_plant_cell_en.svg.png	t	2026-01-26 21:27:38.663845	2026-01-26 21:27:38.663845
94	14	$\\sum_{i=1}^{n} x^2$	mcq	1	2		\N	t	2026-01-26 21:29:10.281593	2026-01-26 21:29:10.281593
95	10	jruhyfrduhufdhjudfhjdf	mcq	1	1		\N	t	2026-01-27 14:09:39.122086	2026-01-27 14:09:39.122086
96	10	ndfhjhjfjhjdfnmfdjk	mcq	1	2		\N	t	2026-01-27 14:10:07.233956	2026-01-27 14:10:07.233956
97	13	THE GRAPH BELOW	mcq	1	1		1769582379_IMG-20250507-WA0010.jpg	t	2026-01-28 07:39:39.736506	2026-01-28 07:39:39.736506
98	13	What is 5 + 7?	mcq	5	2	\N	\N	t	2026-01-28 07:40:08.749248	2026-01-28 07:40:08.749248
99	13	Solve: 9 × 6	mcq	5	3	\N	\N	t	2026-01-28 07:40:08.749821	2026-01-28 07:40:08.749821
100	13	Is 15 a multiple of 3?	true_false	3	4	\N	\N	t	2026-01-28 07:40:08.791877	2026-01-28 07:40:08.791877
101	13	What is the square of 8?	mcq	5	5	\N	\N	t	2026-01-28 07:40:08.794877	2026-01-28 07:40:08.794877
102	13	Solve: 20 ÷ 4	mcq	5	6	\N	\N	t	2026-01-28 07:40:08.798079	2026-01-28 07:40:08.798079
103	13	π is approximately equal to 3.14	true_false	3	7	\N	\N	t	2026-01-28 07:40:08.798079	2026-01-28 07:40:08.798079
104	13	Find the value of x if x + 10 = 25	theory	6	8	\N	\N	t	2026-01-28 07:40:08.798079	2026-01-28 07:40:08.798079
105	13	What is 3² + 4²?	mcq	5	9	\N	\N	t	2026-01-28 07:40:08.798079	2026-01-28 07:40:08.798079
106	13	Solve: 100 − 45	mcq	5	10	\N	\N	t	2026-01-28 07:40:08.798079	2026-01-28 07:40:08.798079
107	13	What is the LCM of 4 and 6?	theory	6	11	\N	\N	t	2026-01-28 07:40:08.813712	2026-01-28 07:40:08.813712
108	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhy did Emma visit the library every weekend?	mcq	5	1	\N	\N	t	2026-01-28 10:50:09.769894	2026-01-28 10:50:09.769894
109	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did reading help Emma learn?	mcq	5	2	\N	\N	t	2026-01-28 10:50:09.821062	2026-01-28 10:50:09.821062
110	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nHow did reading affect Emma over time?	mcq	5	3	\N	\N	t	2026-01-28 10:50:09.879803	2026-01-28 10:50:09.879803
111	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat kind of stories did Emma borrow?	mcq	5	4	\N	\N	t	2026-01-28 10:50:09.883806	2026-01-28 10:50:09.883806
112	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat place is mentioned in the passage?	mcq	5	5	\N	\N	t	2026-01-28 10:50:09.887858	2026-01-28 10:50:09.887858
113	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhen did Emma usually read?	mcq	5	6	\N	\N	t	2026-01-28 10:50:09.890858	2026-01-28 10:50:09.890858
114	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat helped Emma understand different cultures?	mcq	5	7	\N	\N	t	2026-01-28 10:50:09.893859	2026-01-28 10:50:09.893859
115	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat was Emma's main hobby?	mcq	5	8	\N	\N	t	2026-01-28 10:50:09.897852	2026-01-28 10:50:09.897852
116	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat benefit did Emma get from reading?	mcq	5	9	\N	\N	t	2026-01-28 10:50:09.900858	2026-01-28 10:50:09.900858
117	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhere did Emma get new words from?	mcq	5	10	\N	\N	t	2026-01-28 10:50:09.903032	2026-01-28 10:50:09.903032
118	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did Emma love?	mcq	5	11	\N	\N	t	2026-01-28 10:50:09.903032	2026-01-28 10:50:09.903032
119	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nHow often did Emma go to the library?	mcq	5	12	\N	\N	t	2026-01-28 10:50:09.903032	2026-01-28 10:50:09.903032
120	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did Emma borrow from the library?	mcq	5	13	\N	\N	t	2026-01-28 10:50:09.903032	2026-01-28 10:50:09.903032
121	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat skill improved because of reading?	mcq	5	14	\N	\N	t	2026-01-28 10:50:10.074988	2026-01-28 10:50:10.074988
122	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhy was Emma an excellent writer?	mcq	5	15	\N	\N	t	2026-01-28 10:50:10.077988	2026-01-28 10:50:10.077988
123	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did reading help Emma understand?	mcq	5	16	\N	\N	t	2026-01-28 10:50:10.080988	2026-01-28 10:50:10.080988
124	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat kind of activity is reading for Emma?	mcq	5	17	\N	\N	t	2026-01-28 10:50:10.103003	2026-01-28 10:50:10.103003
125	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat does the passage mainly talk about?	mcq	5	18	\N	\N	t	2026-01-28 10:50:10.103003	2026-01-28 10:50:10.103003
126	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat happened over time?	mcq	5	19	\N	\N	t	2026-01-28 10:50:10.103003	2026-01-28 10:50:10.103003
127	15	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat is the best title for the passage?	mcq	5	20	\N	\N	t	2026-01-28 10:50:10.118631	2026-01-28 10:50:10.118631
128	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhy did Emma visit the library every weekend?	mcq	5	1	\N	\N	t	2026-01-28 16:13:21.699039	2026-01-28 16:13:21.699039
129	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did reading help Emma learn?	mcq	5	2	\N	\N	t	2026-01-28 16:13:21.784345	2026-01-28 16:13:21.784345
130	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nHow did reading affect Emma over time?	mcq	5	3	\N	\N	t	2026-01-28 16:13:21.884708	2026-01-28 16:13:21.884708
131	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat kind of stories did Emma borrow?	mcq	5	4	\N	\N	t	2026-01-28 16:13:21.890708	2026-01-28 16:13:21.890708
132	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat place is mentioned in the passage?	mcq	5	5	\N	\N	t	2026-01-28 16:13:21.895709	2026-01-28 16:13:21.895709
133	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhen did Emma usually read?	mcq	5	6	\N	\N	t	2026-01-28 16:13:21.898692	2026-01-28 16:13:21.898692
134	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat helped Emma understand different cultures?	mcq	5	7	\N	\N	t	2026-01-28 16:13:21.898692	2026-01-28 16:13:21.898692
135	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat was Emma's main hobby?	mcq	5	8	\N	\N	t	2026-01-28 16:13:21.898692	2026-01-28 16:13:21.898692
136	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat benefit did Emma get from reading?	mcq	5	9	\N	\N	t	2026-01-28 16:13:21.917502	2026-01-28 16:13:21.917502
137	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhere did Emma get new words from?	mcq	5	10	\N	\N	t	2026-01-28 16:13:21.917502	2026-01-28 16:13:21.917502
138	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did Emma love?	mcq	5	11	\N	\N	t	2026-01-28 16:13:21.917502	2026-01-28 16:13:21.917502
139	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nHow often did Emma go to the library?	mcq	5	12	\N	\N	t	2026-01-28 16:13:21.933231	2026-01-28 16:13:21.933231
140	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did Emma borrow from the library?	mcq	5	13	\N	\N	t	2026-01-28 16:13:21.938218	2026-01-28 16:13:21.938218
141	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat skill improved because of reading?	mcq	5	14	\N	\N	t	2026-01-28 16:13:21.943229	2026-01-28 16:13:21.943229
142	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhy was Emma an excellent writer?	mcq	5	15	\N	\N	t	2026-01-28 16:13:21.948229	2026-01-28 16:13:21.948229
143	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat did reading help Emma understand?	mcq	5	16	\N	\N	t	2026-01-28 16:13:22.011234	2026-01-28 16:13:22.011234
144	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat kind of activity is reading for Emma?	mcq	5	17	\N	\N	t	2026-01-28 16:13:22.015599	2026-01-28 16:13:22.015599
145	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat does the passage mainly talk about?	mcq	5	18	\N	\N	t	2026-01-28 16:13:22.015599	2026-01-28 16:13:22.015599
146	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat happened over time?	mcq	5	19	\N	\N	t	2026-01-28 16:13:22.015599	2026-01-28 16:13:22.015599
147	16	Passage:\nEmma loved reading books. Every weekend, she visited the local library to borrow new stories. Reading helped her learn new words and understand different cultures. Over time, her love for books made her an excellent writer.\n\nWhat is the best title for the passage?	mcq	5	20	\N	\N	t	2026-01-28 16:13:22.031234	2026-01-28 16:13:22.031234
148	17	What is 5 + 7?	mcq	5	1	\N	\N	t	2026-01-28 22:12:28.439165	2026-01-28 22:12:28.439165
149	17	Solve: 9 × 6	mcq	5	2	\N	\N	t	2026-01-28 22:12:28.479566	2026-01-28 22:12:28.479566
150	17	Is 15 a multiple of 3?	true_false	3	3	\N	\N	t	2026-01-28 22:12:28.618472	2026-01-28 22:12:28.618472
151	17	What is the square of 8?	mcq	5	4	\N	\N	t	2026-01-28 22:12:28.618472	2026-01-28 22:12:28.618472
152	17	Solve: 20 ÷ 4	mcq	5	5	\N	\N	t	2026-01-28 22:12:28.618472	2026-01-28 22:12:28.618472
153	17	π is approximately equal to 3.14	true_false	3	6	\N	\N	t	2026-01-28 22:12:28.62949	2026-01-28 22:12:28.62949
154	17	Find the value of x if x + 10 = 25	theory	6	7	\N	\N	t	2026-01-28 22:12:28.63368	2026-01-28 22:12:28.63368
155	17	What is 3² + 4²?	mcq	5	8	\N	\N	t	2026-01-28 22:12:28.637691	2026-01-28 22:12:28.637691
156	17	Solve: 100 − 45	mcq	5	9	\N	\N	t	2026-01-28 22:12:28.637691	2026-01-28 22:12:28.637691
157	17	What is the LCM of 4 and 6?	theory	6	10	\N	\N	t	2026-01-28 22:12:28.637691	2026-01-28 22:12:28.637691
158	18	What is the basic unit of life?	mcq	5	1	\N	\N	t	2026-02-04 12:48:50.965582	2026-02-04 12:48:50.965582
159	18	Which organ is responsible for pumping blood?	mcq	5	2	\N	\N	t	2026-02-04 12:48:51.24154	2026-02-04 12:48:51.24154
160	18	What process do plants use to make food?	mcq	5	3	\N	\N	t	2026-02-04 12:48:51.5655	2026-02-04 12:48:51.5655
161	18	Which gas is essential for respiration?	mcq	5	4	\N	\N	t	2026-02-04 12:48:51.805825	2026-02-04 12:48:51.805825
162	18	Which part of the plant conducts water?	mcq	5	5	\N	\N	t	2026-02-04 12:48:51.823066	2026-02-04 12:48:51.823066
163	18	What is the largest organ in the human body?	mcq	5	6	\N	\N	t	2026-02-04 12:48:51.83763	2026-02-04 12:48:51.83763
164	18	Which blood cells help fight infection?	mcq	5	7	\N	\N	t	2026-02-04 12:48:51.84406	2026-02-04 12:48:51.84406
165	18	What is the function of roots?	mcq	5	8	\N	\N	t	2026-02-04 12:48:51.861705	2026-02-04 12:48:51.861705
166	18	Which organ helps in breathing?	mcq	5	9	\N	\N	t	2026-02-04 12:48:51.874485	2026-02-04 12:48:51.874485
167	18	What do herbivores eat?	mcq	5	10	\N	\N	t	2026-02-04 12:48:51.886109	2026-02-04 12:48:51.886109
168	18	THE IMAGE BELOW SHOWS	mcq	1	11		\N	t	2026-02-04 12:51:16.72721	2026-02-04 12:51:16.72721
169	18	the image below is	mcq	1	12		1770232007_animal-cell-label-with-answer-key.png	t	2026-02-04 12:54:48.459123	2026-02-04 20:06:47.402695
170	18	The bar below shows	mcq	1	13		1770232086_bar-chart-example.png	t	2026-02-04 20:08:06.588807	2026-02-04 20:08:06.588807
171	19	What is the derivative of x²?	mcq	5	1	\N	\N	t	2026-02-11 16:09:37.731548	2026-02-11 16:09:37.731548
172	19	Find ∫ x dx	mcq	5	2	\N	\N	t	2026-02-11 16:09:38.050677	2026-02-11 16:09:38.050677
173	19	What is the solution of x² − 4 = 0?	mcq	5	3	\N	\N	t	2026-02-11 16:09:38.546629	2026-02-11 16:09:38.546629
174	19	Which of the following is a quadratic equation?	mcq	5	4	\N	\N	t	2026-02-11 16:09:38.554959	2026-02-11 16:09:38.554959
175	19	Simplify: 1/2 + 1/4	mcq	5	5	\N	\N	t	2026-02-11 16:09:38.56415	2026-02-11 16:09:38.56415
176	19	What is the derivative of 5x?	mcq	5	6	\N	\N	t	2026-02-11 16:09:38.584998	2026-02-11 16:09:38.584998
177	19	Find ∫ 3x² dx	mcq	5	7	\N	\N	t	2026-02-11 16:09:38.597694	2026-02-11 16:09:38.597694
178	19	Solve: x² + 5x + 6 = 0	mcq	5	8	\N	\N	t	2026-02-11 16:09:38.603221	2026-02-11 16:09:38.603221
179	19	Convert 3/5 into decimal.	mcq	5	9	\N	\N	t	2026-02-11 16:09:38.614773	2026-02-11 16:09:38.614773
180	19	Which term is used for finding rate of change?	mcq	5	10	\N	\N	t	2026-02-11 16:09:38.61931	2026-02-11 16:09:38.61931
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, description, created_at) FROM stdin;
1	Admin	Admin Role	2026-01-12 12:39:11.615575
2	Teacher	Teacher Role	2026-01-12 12:39:11.867054
3	Student	Student Role	2026-01-12 12:39:11.867054
\.


--
-- Data for Name: student_answers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_answers (id, exam_session_id, question_id, student_id, selected_option_id, theory_answer, is_correct, marks_obtained, time_spent_seconds, marked_for_review, visited_count, created_at, updated_at) FROM stdin;
1	2	1	7	1	\N	t	1	0	f	0	2026-01-15 08:20:23.264019	2026-01-15 08:20:23.264019
2	2	2	7	6	\N	t	1	0	f	0	2026-01-15 08:20:49.372579	2026-01-15 08:20:49.372579
3	3	1	8	1	\N	t	1	0	f	0	2026-01-15 10:13:17.648083	2026-01-15 10:13:17.648083
4	3	2	8	6	\N	t	1	0	f	0	2026-01-15 10:13:25.883868	2026-01-15 10:13:25.883868
5	3	4	8	13	\N	t	1	0	f	0	2026-01-15 10:13:29.957315	2026-01-15 10:13:29.957315
6	4	3	8	9	\N	t	1	0	f	0	2026-01-15 13:03:53.241462	2026-01-15 13:03:53.241462
7	10	31	8	91	\N	f	0	0	f	0	2026-01-21 11:49:18.424179	2026-01-21 11:49:18.424179
8	10	32	8	95	\N	f	0	0	f	0	2026-01-21 11:49:36.249407	2026-01-21 11:49:36.249407
9	10	33	8	99	\N	t	3	0	f	0	2026-01-21 11:49:39.127887	2026-01-21 11:49:39.127887
10	10	34	8	101	\N	f	0	0	f	0	2026-01-21 11:49:40.758582	2026-01-21 11:49:40.758582
11	10	49	8	143	\N	t	5	0	f	0	2026-01-21 11:50:44.301603	2026-01-21 11:50:44.301603
12	10	50	8	147	\N	f	0	0	f	0	2026-01-21 11:51:19.82306	2026-01-21 11:51:19.82306
13	10	51	8	\N	hgghyytyyut	\N	0	0	f	0	2026-01-21 11:51:29.716554	2026-01-21 11:51:29.716554
14	10	52	8	151	\N	t	1	0	f	0	2026-01-21 11:51:29.857025	2026-01-21 11:51:29.857025
15	10	39	8	116	\N	t	5	0	f	0	2026-01-21 11:51:40.478981	2026-01-21 11:51:40.478981
16	10	44	8	131	\N	t	3	0	f	0	2026-01-21 11:51:59.203117	2026-01-21 11:51:59.203117
17	10	45	8	135	\N	t	5	0	f	0	2026-01-21 11:52:24.56808	2026-01-21 11:52:24.56808
18	10	46	8	138	\N	t	5	0	f	0	2026-01-21 11:52:34.371689	2026-01-21 11:52:34.371689
19	10	47	8	141	\N	t	3	0	f	0	2026-01-21 11:52:41.552159	2026-01-21 11:52:41.552159
25	13	32	7	96	\N	t	5	0	f	0	2026-01-21 17:06:39.252727	2026-01-21 17:06:39.252727
26	13	33	7	99	\N	t	3	0	f	0	2026-01-21 17:06:39.267761	2026-01-21 17:06:39.267761
27	13	34	7	103	\N	t	5	0	f	0	2026-01-21 17:06:39.270782	2026-01-21 17:06:39.270782
28	13	35	7	106	\N	t	5	0	f	0	2026-01-21 17:06:39.270782	2026-01-21 17:06:39.270782
29	13	36	7	109	\N	t	3	0	f	0	2026-01-21 17:06:39.278806	2026-01-21 17:06:39.278806
30	13	37	7	\N	15	\N	0	0	f	0	2026-01-21 17:06:39.287271	2026-01-21 17:06:39.287271
31	13	38	7	111	\N	t	5	0	f	0	2026-01-21 17:06:39.287271	2026-01-21 17:06:39.287271
32	13	39	7	115	\N	f	0	0	f	0	2026-01-21 17:06:39.295284	2026-01-21 17:06:39.295284
33	13	31	7	92	\N	f	0	0	f	0	2026-01-21 17:06:39.300962	2026-01-21 17:06:39.300962
34	13	41	7	119	\N	t	1	0	f	0	2026-01-21 17:06:39.300962	2026-01-21 17:06:39.300962
35	13	42	7	124	\N	f	0	0	f	0	2026-01-21 17:06:39.310983	2026-01-21 17:06:39.310983
36	13	43	7	128	\N	t	5	0	f	0	2026-01-21 17:06:39.318069	2026-01-21 17:06:39.318069
37	13	44	7	131	\N	t	3	0	f	0	2026-01-21 17:06:39.319523	2026-01-21 17:06:39.319523
38	13	45	7	134	\N	f	0	0	f	0	2026-01-21 17:06:39.319523	2026-01-21 17:06:39.319523
39	13	46	7	138	\N	t	5	0	f	0	2026-01-21 17:06:39.319523	2026-01-21 17:06:39.319523
40	25	32	29	95	\N	f	0	0	f	0	2026-01-24 06:49:31.964024	2026-01-24 06:49:31.964024
41	25	33	29	100	\N	f	0	0	f	0	2026-01-24 06:49:32.044428	2026-01-24 06:49:32.044428
42	25	34	29	101	\N	f	0	0	f	0	2026-01-24 06:49:32.098344	2026-01-24 06:49:32.098344
43	25	35	29	106	\N	t	5	0	f	0	2026-01-24 06:49:32.106309	2026-01-24 06:49:32.106309
44	25	36	29	109	\N	t	3	0	f	0	2026-01-24 06:49:32.206443	2026-01-24 06:49:32.206443
45	25	37	29	\N	15	\N	0	0	f	0	2026-01-24 06:49:32.206443	2026-01-24 06:49:32.206443
46	25	38	29	111	\N	t	5	0	f	0	2026-01-24 06:49:32.211962	2026-01-24 06:49:32.211962
47	25	39	29	115	\N	f	0	0	f	0	2026-01-24 06:49:32.211962	2026-01-24 06:49:32.211962
48	25	31	29	91	\N	f	0	0	f	0	2026-01-24 06:49:32.219982	2026-01-24 06:49:32.219982
49	25	41	29	119	\N	t	1	0	f	0	2026-01-24 06:49:32.223188	2026-01-24 06:49:32.223188
50	25	42	29	126	\N	f	0	0	f	0	2026-01-24 06:49:32.228248	2026-01-24 06:49:32.228248
51	25	43	29	127	\N	f	0	0	f	0	2026-01-24 06:49:32.228248	2026-01-24 06:49:32.228248
52	25	44	29	132	\N	f	0	0	f	0	2026-01-24 06:49:32.228248	2026-01-24 06:49:32.228248
53	25	45	29	133	\N	f	0	0	f	0	2026-01-24 06:49:32.236269	2026-01-24 06:49:32.236269
54	25	46	29	138	\N	t	5	0	f	0	2026-01-24 06:49:32.236269	2026-01-24 06:49:32.236269
55	25	47	29	141	\N	t	3	0	f	0	2026-01-24 06:49:32.244269	2026-01-24 06:49:32.244269
56	25	49	29	143	\N	t	5	0	f	0	2026-01-24 06:49:32.244269	2026-01-24 06:49:32.244269
57	25	50	29	147	\N	f	0	0	f	0	2026-01-24 06:49:32.244269	2026-01-24 06:49:32.244269
58	25	52	29	153	\N	f	0	0	f	0	2026-01-24 06:49:32.444282	2026-01-24 06:49:32.444282
59	26	32	30	96	\N	t	5	0	f	0	2026-01-24 07:09:47.165284	2026-01-24 07:09:47.165284
60	26	33	30	99	\N	t	3	0	f	0	2026-01-24 07:09:47.173292	2026-01-24 07:09:47.173292
61	26	34	30	103	\N	t	5	0	f	0	2026-01-24 07:09:47.181553	2026-01-24 07:09:47.181553
62	26	35	30	106	\N	t	5	0	f	0	2026-01-24 07:09:47.181553	2026-01-24 07:09:47.181553
63	26	36	30	109	\N	t	3	0	f	0	2026-01-24 07:09:47.194554	2026-01-24 07:09:47.194554
64	26	38	30	111	\N	t	5	0	f	0	2026-01-24 07:09:47.200218	2026-01-24 07:09:47.200218
65	26	39	30	115	\N	f	0	0	f	0	2026-01-24 07:09:47.204161	2026-01-24 07:09:47.204161
66	26	31	30	93	\N	t	5	0	f	0	2026-01-24 07:09:47.206182	2026-01-24 07:09:47.206182
67	26	41	30	119	\N	t	1	0	f	0	2026-01-24 07:09:47.214209	2026-01-24 07:09:47.214209
68	26	42	30	126	\N	f	0	0	f	0	2026-01-24 07:09:47.214209	2026-01-24 07:09:47.214209
69	26	43	30	128	\N	t	5	0	f	0	2026-01-24 07:09:47.225814	2026-01-24 07:09:47.225814
70	26	44	30	131	\N	t	3	0	f	0	2026-01-24 07:09:47.225814	2026-01-24 07:09:47.225814
71	26	45	30	135	\N	t	5	0	f	0	2026-01-24 07:09:47.225814	2026-01-24 07:09:47.225814
72	26	46	30	138	\N	t	5	0	f	0	2026-01-24 07:09:47.238337	2026-01-24 07:09:47.238337
73	26	47	30	141	\N	t	3	0	f	0	2026-01-24 07:09:47.242136	2026-01-24 07:09:47.242136
74	26	49	30	143	\N	t	5	0	f	0	2026-01-24 07:09:47.242136	2026-01-24 07:09:47.242136
75	26	50	30	147	\N	f	0	0	f	0	2026-01-24 07:09:47.254159	2026-01-24 07:09:47.254159
76	26	52	30	151	\N	t	1	0	f	0	2026-01-24 07:09:47.257287	2026-01-24 07:09:47.257287
77	29	53	29	157	\N	f	0	0	f	0	2026-01-24 16:41:03.177313	2026-01-24 16:41:03.177313
78	29	54	29	160	\N	t	5	0	f	0	2026-01-24 16:41:03.218589	2026-01-24 16:41:03.218589
79	29	55	29	165	\N	t	5	0	f	0	2026-01-24 16:41:03.22259	2026-01-24 16:41:03.22259
80	29	56	29	167	\N	f	0	0	f	0	2026-01-24 16:41:03.226582	2026-01-24 16:41:03.226582
81	29	57	29	173	\N	t	5	0	f	0	2026-01-24 16:41:03.23059	2026-01-24 16:41:03.23059
82	29	58	29	176	\N	t	5	0	f	0	2026-01-24 16:41:03.234589	2026-01-24 16:41:03.234589
83	29	59	29	180	\N	t	5	0	f	0	2026-01-24 16:41:03.253305	2026-01-24 16:41:03.253305
84	29	60	29	183	\N	f	0	0	f	0	2026-01-24 16:41:03.26202	2026-01-24 16:41:03.26202
85	29	61	29	189	\N	t	5	0	f	0	2026-01-24 16:41:03.26502	2026-01-24 16:41:03.26502
86	29	62	29	193	\N	t	5	0	f	0	2026-01-24 16:41:03.268021	2026-01-24 16:41:03.268021
87	29	63	29	197	\N	t	5	0	f	0	2026-01-24 16:41:03.272019	2026-01-24 16:41:03.272019
88	29	64	29	199	\N	f	0	0	f	0	2026-01-24 16:41:03.275019	2026-01-24 16:41:03.275019
89	29	65	29	205	\N	t	5	0	f	0	2026-01-24 16:41:03.279054	2026-01-24 16:41:03.279054
90	29	66	29	208	\N	t	5	0	f	0	2026-01-24 16:41:03.282055	2026-01-24 16:41:03.282055
91	29	67	29	213	\N	t	5	0	f	0	2026-01-24 16:41:03.286054	2026-01-24 16:41:03.286054
92	29	68	29	216	\N	f	0	0	f	0	2026-01-24 16:41:03.289054	2026-01-24 16:41:03.289054
93	29	69	29	220	\N	t	5	0	f	0	2026-01-24 16:41:03.292237	2026-01-24 16:41:03.292237
94	29	70	29	224	\N	t	5	0	f	0	2026-01-24 16:41:03.292237	2026-01-24 16:41:03.292237
95	29	71	29	228	\N	t	5	0	f	0	2026-01-24 16:41:03.292237	2026-01-24 16:41:03.292237
96	29	72	29	233	\N	t	5	0	f	0	2026-01-24 16:41:03.292237	2026-01-24 16:41:03.292237
97	63	53	32	155	\N	f	0	0	f	0	2026-01-28 05:39:43.942669	2026-01-28 05:39:44.961588
98	63	54	32	159	\N	f	0	0	f	0	2026-01-28 05:39:44.388009	2026-01-28 05:39:44.961588
99	63	55	32	163	\N	f	0	0	f	0	2026-01-28 05:39:44.398853	2026-01-28 05:39:44.961588
100	65	32	34	96	\N	t	5	0	f	0	2026-01-28 07:43:23.172433	2026-01-28 07:43:23.278052
101	65	33	34	99	\N	t	3	0	f	0	2026-01-28 07:43:23.17843	2026-01-28 07:43:23.278052
102	65	34	34	103	\N	t	5	0	f	0	2026-01-28 07:43:23.184434	2026-01-28 07:43:23.278052
103	65	36	34	109	\N	t	3	0	f	0	2026-01-28 07:43:23.188427	2026-01-28 07:43:23.278052
104	65	38	34	111	\N	t	5	0	f	0	2026-01-28 07:43:23.19243	2026-01-28 07:43:23.278052
105	65	39	34	116	\N	t	5	0	f	0	2026-01-28 07:43:23.196832	2026-01-28 07:43:23.278052
106	65	31	34	92	\N	f	0	0	f	0	2026-01-28 07:43:23.201831	2026-01-28 07:43:23.278052
107	65	41	34	119	\N	t	1	0	f	0	2026-01-28 07:43:23.20483	2026-01-28 07:43:23.278052
108	65	42	34	126	\N	f	0	0	f	0	2026-01-28 07:43:23.208826	2026-01-28 07:43:23.278052
109	65	43	34	127	\N	f	0	0	f	0	2026-01-28 07:43:23.214598	2026-01-28 07:43:23.278052
110	65	44	34	131	\N	t	3	0	f	0	2026-01-28 07:43:23.21759	2026-01-28 07:43:23.278052
111	65	45	34	135	\N	t	5	0	f	0	2026-01-28 07:43:23.221593	2026-01-28 07:43:23.278052
112	65	46	34	138	\N	t	5	0	f	0	2026-01-28 07:43:23.22659	2026-01-28 07:43:23.278052
113	65	47	34	141	\N	t	3	0	f	0	2026-01-28 07:43:23.228693	2026-01-28 07:43:23.278052
114	65	49	34	143	\N	t	5	0	f	0	2026-01-28 07:43:23.228693	2026-01-28 07:43:23.278052
115	65	50	34	148	\N	t	5	0	f	0	2026-01-28 07:43:23.228693	2026-01-28 07:43:23.278052
116	65	52	34	151	\N	t	1	0	f	0	2026-01-28 07:43:23.228693	2026-01-28 07:43:23.278052
117	68	95	34	323	\N	t	1	0	f	0	2026-01-28 08:30:21.572064	2026-01-28 08:30:21.607629
118	68	96	34	327	\N	t	1	0	f	0	2026-01-28 08:30:21.577067	2026-01-28 08:30:21.607629
119	69	73	34	237	\N	f	0	0	f	0	2026-01-28 11:11:23.248121	2026-01-28 11:11:23.40042
120	69	74	34	240	\N	t	5	0	f	0	2026-01-28 11:11:23.296169	2026-01-28 11:11:23.40042
121	69	75	34	245	\N	t	5	0	f	0	2026-01-28 11:11:23.296169	2026-01-28 11:11:23.40042
122	69	76	34	248	\N	t	5	0	f	0	2026-01-28 11:11:23.312936	2026-01-28 11:11:23.40042
123	69	77	34	253	\N	t	5	0	f	0	2026-01-28 11:11:23.316934	2026-01-28 11:11:23.40042
124	69	78	34	256	\N	t	5	0	f	0	2026-01-28 11:11:23.319959	2026-01-28 11:11:23.40042
125	69	79	34	260	\N	t	5	0	f	0	2026-01-28 11:11:23.323042	2026-01-28 11:11:23.40042
126	69	80	34	263	\N	f	0	0	f	0	2026-01-28 11:11:23.326047	2026-01-28 11:11:23.40042
127	69	81	34	269	\N	t	5	0	f	0	2026-01-28 11:11:23.329047	2026-01-28 11:11:23.40042
128	69	82	34	273	\N	t	5	0	f	0	2026-01-28 11:11:23.334054	2026-01-28 11:11:23.40042
129	70	108	33	365	\N	f	0	0	f	0	2026-01-28 16:16:34.108118	2026-01-28 16:16:34.236104
130	70	109	33	368	\N	t	5	0	f	0	2026-01-28 16:16:34.11678	2026-01-28 16:16:34.236104
131	70	110	33	373	\N	t	5	0	f	0	2026-01-28 16:16:34.11678	2026-01-28 16:16:34.236104
132	70	111	33	376	\N	t	5	0	f	0	2026-01-28 16:16:34.11678	2026-01-28 16:16:34.236104
133	70	112	33	381	\N	t	5	0	f	0	2026-01-28 16:16:34.133286	2026-01-28 16:16:34.236104
134	70	113	33	384	\N	t	5	0	f	0	2026-01-28 16:16:34.133286	2026-01-28 16:16:34.236104
135	70	114	33	388	\N	t	5	0	f	0	2026-01-28 16:16:34.133286	2026-01-28 16:16:34.236104
136	70	115	33	391	\N	f	0	0	f	0	2026-01-28 16:16:34.147799	2026-01-28 16:16:34.236104
137	70	116	33	397	\N	t	5	0	f	0	2026-01-28 16:16:34.152826	2026-01-28 16:16:34.236104
138	70	117	33	401	\N	t	5	0	f	0	2026-01-28 16:16:34.15682	2026-01-28 16:16:34.236104
139	70	118	33	405	\N	t	5	0	f	0	2026-01-28 16:16:34.160813	2026-01-28 16:16:34.236104
140	70	119	33	409	\N	t	5	0	f	0	2026-01-28 16:16:34.165851	2026-01-28 16:16:34.236104
141	70	120	33	413	\N	t	5	0	f	0	2026-01-28 16:16:34.170199	2026-01-28 16:16:34.236104
142	70	121	33	416	\N	t	5	0	f	0	2026-01-28 16:16:34.174191	2026-01-28 16:16:34.236104
143	71	148	34	525	\N	t	5	0	f	0	2026-01-28 22:14:05.317495	2026-01-28 22:14:05.390434
144	71	149	34	527	\N	f	0	0	f	0	2026-01-28 22:14:05.33875	2026-01-28 22:14:05.390434
145	71	150	34	531	\N	t	3	0	f	0	2026-01-28 22:14:05.33875	2026-01-28 22:14:05.390434
146	71	151	34	535	\N	t	5	0	f	0	2026-01-28 22:14:05.33875	2026-01-28 22:14:05.390434
147	71	152	34	538	\N	t	5	0	f	0	2026-01-28 22:14:05.349882	2026-01-28 22:14:05.390434
148	71	153	34	541	\N	t	3	0	f	0	2026-01-28 22:14:05.354898	2026-01-28 22:14:05.390434
149	71	155	34	543	\N	t	5	0	f	0	2026-01-28 22:14:05.354898	2026-01-28 22:14:05.390434
150	71	156	34	548	\N	t	5	0	f	0	2026-01-28 22:14:05.354898	2026-01-28 22:14:05.390434
151	72	108	34	365	\N	f	0	0	f	0	2026-01-30 13:23:47.665438	2026-01-30 13:23:47.819395
152	72	109	34	368	\N	t	5	0	f	0	2026-01-30 13:23:47.720613	2026-01-30 13:23:47.819395
153	72	110	34	373	\N	t	5	0	f	0	2026-01-30 13:23:47.720613	2026-01-30 13:23:47.819395
154	72	111	34	376	\N	t	5	0	f	0	2026-01-30 13:23:47.720613	2026-01-30 13:23:47.819395
155	72	112	34	381	\N	t	5	0	f	0	2026-01-30 13:23:47.740439	2026-01-30 13:23:47.819395
156	72	113	34	384	\N	t	5	0	f	0	2026-01-30 13:23:47.744436	2026-01-30 13:23:47.819395
157	72	114	34	388	\N	t	5	0	f	0	2026-01-30 13:23:47.746524	2026-01-30 13:23:47.819395
158	72	115	34	391	\N	f	0	0	f	0	2026-01-30 13:23:47.746524	2026-01-30 13:23:47.819395
159	72	116	34	397	\N	t	5	0	f	0	2026-01-30 13:23:47.754942	2026-01-30 13:23:47.819395
160	72	117	34	401	\N	t	5	0	f	0	2026-01-30 13:23:47.757793	2026-01-30 13:23:47.819395
161	72	118	34	405	\N	t	5	0	f	0	2026-01-30 13:23:47.760792	2026-01-30 13:23:47.819395
162	72	119	34	409	\N	t	5	0	f	0	2026-01-30 13:23:47.77727	2026-01-30 13:23:47.819395
163	72	120	34	413	\N	t	5	0	f	0	2026-01-30 13:23:47.780268	2026-01-30 13:23:47.819395
164	72	121	34	416	\N	t	5	0	f	0	2026-01-30 13:23:47.783268	2026-01-30 13:23:47.819395
165	72	122	34	420	\N	f	0	0	f	0	2026-01-30 13:23:47.786268	2026-01-30 13:23:47.819395
166	72	123	34	424	\N	f	0	0	f	0	2026-01-30 13:23:47.787149	2026-01-30 13:23:47.819395
167	72	124	34	428	\N	t	5	0	f	0	2026-01-30 13:23:47.787149	2026-01-30 13:23:47.819395
168	72	125	34	432	\N	t	5	0	f	0	2026-01-30 13:23:47.787149	2026-01-30 13:23:47.819395
169	72	126	34	436	\N	t	5	0	f	0	2026-01-30 13:23:47.787149	2026-01-30 13:23:47.819395
170	75	128	34	443	\N	f	0	0	f	0	2026-01-30 14:38:16.099051	2026-01-30 14:38:16.178617
171	75	129	34	448	\N	t	5	0	f	0	2026-01-30 14:38:16.107058	2026-01-30 14:38:16.178617
172	75	130	34	453	\N	t	5	0	f	0	2026-01-30 14:38:16.11506	2026-01-30 14:38:16.178617
173	75	131	34	456	\N	t	5	0	f	0	2026-01-30 14:38:16.11506	2026-01-30 14:38:16.178617
174	75	132	34	460	\N	f	0	0	f	0	2026-01-30 14:38:16.123061	2026-01-30 14:38:16.178617
175	75	136	34	477	\N	t	5	0	f	0	2026-01-30 14:38:16.13106	2026-01-30 14:38:16.178617
176	76	95	36	323	\N	t	1	0	f	0	2026-02-02 11:03:59.930634	2026-02-02 11:04:00.29275
177	76	96	36	327	\N	t	1	0	f	0	2026-02-02 11:03:59.975148	2026-02-02 11:04:00.29275
178	77	128	36	445	\N	f	0	0	f	0	2026-02-02 11:22:14.078882	2026-02-02 11:22:14.231362
179	77	129	36	448	\N	t	5	0	f	0	2026-02-02 11:22:14.08588	2026-02-02 11:22:14.231362
180	77	130	36	453	\N	t	5	0	f	0	2026-02-02 11:22:14.093277	2026-02-02 11:22:14.231362
181	77	131	36	455	\N	f	0	0	f	0	2026-02-02 11:22:14.093277	2026-02-02 11:22:14.231362
182	77	132	36	461	\N	t	5	0	f	0	2026-02-02 11:22:14.093277	2026-02-02 11:22:14.231362
183	77	133	36	464	\N	t	5	0	f	0	2026-02-02 11:22:14.10864	2026-02-02 11:22:14.231362
184	77	134	36	468	\N	t	5	0	f	0	2026-02-02 11:22:14.113639	2026-02-02 11:22:14.231362
185	77	135	36	471	\N	f	0	0	f	0	2026-02-02 11:22:14.116639	2026-02-02 11:22:14.231362
186	77	136	36	477	\N	t	5	0	f	0	2026-02-02 11:22:14.120634	2026-02-02 11:22:14.231362
187	77	137	36	481	\N	t	5	0	f	0	2026-02-02 11:22:14.121919	2026-02-02 11:22:14.231362
188	77	138	36	485	\N	t	5	0	f	0	2026-02-02 11:22:14.121919	2026-02-02 11:22:14.231362
189	77	139	36	489	\N	t	5	0	f	0	2026-02-02 11:22:14.121919	2026-02-02 11:22:14.231362
190	77	140	36	493	\N	t	5	0	f	0	2026-02-02 11:22:14.121919	2026-02-02 11:22:14.231362
191	77	141	36	496	\N	t	5	0	f	0	2026-02-02 11:22:14.137542	2026-02-02 11:22:14.231362
192	77	142	36	501	\N	t	5	0	f	0	2026-02-02 11:22:14.137542	2026-02-02 11:22:14.231362
193	77	143	36	505	\N	t	5	0	f	0	2026-02-02 11:22:14.137542	2026-02-02 11:22:14.231362
194	77	144	36	508	\N	t	5	0	f	0	2026-02-02 11:22:14.153172	2026-02-02 11:22:14.231362
195	77	145	36	512	\N	t	5	0	f	0	2026-02-02 11:22:14.157015	2026-02-02 11:22:14.231362
196	77	146	36	516	\N	t	5	0	f	0	2026-02-02 11:22:14.157015	2026-02-02 11:22:14.231362
197	77	147	36	521	\N	t	5	0	f	0	2026-02-02 11:22:14.157015	2026-02-02 11:22:14.231362
198	78	148	36	523	\N	f	0	0	f	0	2026-02-02 12:41:46.242737	2026-02-02 12:41:46.351995
199	78	149	36	527	\N	f	0	0	f	0	2026-02-02 12:41:46.280561	2026-02-02 12:41:46.351995
200	78	150	36	531	\N	t	3	0	f	0	2026-02-02 12:41:46.284561	2026-02-02 12:41:46.351995
201	78	151	36	535	\N	t	5	0	f	0	2026-02-02 12:41:46.288557	2026-02-02 12:41:46.351995
202	78	152	36	538	\N	t	5	0	f	0	2026-02-02 12:41:46.294173	2026-02-02 12:41:46.351995
203	78	153	36	541	\N	t	3	0	f	0	2026-02-02 12:41:46.298165	2026-02-02 12:41:46.351995
204	79	108	36	363	\N	f	0	0	f	0	2026-02-02 21:44:10.187916	2026-02-02 21:44:10.296175
205	79	109	36	368	\N	t	5	0	f	0	2026-02-02 21:44:10.204012	2026-02-02 21:44:10.296175
206	79	110	36	373	\N	t	5	0	f	0	2026-02-02 21:44:10.204012	2026-02-02 21:44:10.296175
207	79	111	36	376	\N	t	5	0	f	0	2026-02-02 21:44:10.220639	2026-02-02 21:44:10.296175
208	79	112	36	381	\N	t	5	0	f	0	2026-02-02 21:44:10.222456	2026-02-02 21:44:10.296175
209	79	113	36	384	\N	t	5	0	f	0	2026-02-02 21:44:10.222456	2026-02-02 21:44:10.296175
210	79	114	36	388	\N	t	5	0	f	0	2026-02-02 21:44:10.234187	2026-02-02 21:44:10.296175
211	79	115	36	392	\N	t	5	0	f	0	2026-02-02 21:44:10.234187	2026-02-02 21:44:10.296175
212	79	116	36	397	\N	t	5	0	f	0	2026-02-02 21:44:10.242195	2026-02-02 21:44:10.296175
213	79	117	36	401	\N	t	5	0	f	0	2026-02-02 21:44:10.242195	2026-02-02 21:44:10.296175
214	79	118	36	405	\N	t	5	0	f	0	2026-02-02 21:44:10.250189	2026-02-02 21:44:10.296175
215	80	95	33	323	\N	t	1	0	f	0	2026-02-03 11:46:36.787296	2026-02-03 11:46:36.880344
216	80	96	33	328	\N	f	0	0	f	0	2026-02-03 11:46:36.797293	2026-02-03 11:46:36.880344
217	88	158	33	553	\N	t	5	0	f	0	2026-02-05 11:50:21.314205	2026-02-05 11:50:22.067871
218	88	159	33	557	\N	t	5	0	f	0	2026-02-05 11:50:21.780719	2026-02-05 11:50:22.067871
219	88	160	33	560	\N	t	5	0	f	0	2026-02-05 11:50:21.898631	2026-02-05 11:50:22.067871
220	88	161	33	563	\N	f	0	0	f	0	2026-02-05 11:50:21.898631	2026-02-05 11:50:22.067871
221	88	162	33	568	\N	f	0	0	f	0	2026-02-05 11:50:21.914872	2026-02-05 11:50:22.067871
222	88	163	33	573	\N	f	0	0	f	0	2026-02-05 11:50:21.920288	2026-02-05 11:50:22.067871
223	88	164	33	577	\N	t	5	0	f	0	2026-02-05 11:50:21.968414	2026-02-05 11:50:22.067871
224	88	165	33	580	\N	t	5	0	f	0	2026-02-05 11:50:21.980345	2026-02-05 11:50:22.067871
225	88	169	33	595	\N	f	0	0	f	0	2026-02-05 11:50:21.980345	2026-02-05 11:50:22.067871
226	88	170	33	599	\N	t	1	0	f	0	2026-02-05 11:50:21.989867	2026-02-05 11:50:22.067871
227	92	158	34	554	\N	f	0	0	f	0	2026-02-06 10:54:02.55092	2026-02-06 10:54:03.009353
228	92	159	34	557	\N	t	5	0	f	0	2026-02-06 10:54:02.684556	2026-02-06 10:54:03.009353
229	92	160	34	560	\N	t	5	0	f	0	2026-02-06 10:54:02.684556	2026-02-06 10:54:03.009353
230	92	161	34	564	\N	t	5	0	f	0	2026-02-06 10:54:02.699591	2026-02-06 10:54:03.009353
231	92	162	34	569	\N	t	5	0	f	0	2026-02-06 10:54:02.699591	2026-02-06 10:54:03.009353
232	92	163	34	573	\N	f	0	0	f	0	2026-02-06 10:54:02.699591	2026-02-06 10:54:03.009353
233	92	164	34	577	\N	t	5	0	f	0	2026-02-06 10:54:02.714615	2026-02-06 10:54:03.009353
234	92	165	34	580	\N	t	5	0	f	0	2026-02-06 10:54:02.719594	2026-02-06 10:54:03.009353
235	94	128	39	444	\N	t	5	0	f	0	2026-02-06 11:13:43.624675	2026-02-06 11:13:43.658831
236	94	129	39	448	\N	t	5	0	f	0	2026-02-06 11:13:43.626347	2026-02-06 11:13:43.658831
237	94	130	39	453	\N	t	5	0	f	0	2026-02-06 11:13:43.626347	2026-02-06 11:13:43.658831
238	95	158	41	553	\N	t	5	0	f	0	2026-02-06 15:57:39.886812	2026-02-06 15:57:40.096758
239	95	159	41	557	\N	t	5	0	f	0	2026-02-06 15:57:40.002371	2026-02-06 15:57:40.096758
240	95	160	41	560	\N	t	5	0	f	0	2026-02-06 15:57:40.002371	2026-02-06 15:57:40.096758
241	95	161	41	564	\N	t	5	0	f	0	2026-02-06 15:57:40.015398	2026-02-06 15:57:40.096758
242	95	162	41	569	\N	t	5	0	f	0	2026-02-06 15:57:40.018865	2026-02-06 15:57:40.096758
243	95	163	41	572	\N	t	5	0	f	0	2026-02-06 15:57:40.018865	2026-02-06 15:57:40.096758
244	95	164	41	576	\N	f	0	0	f	0	2026-02-06 15:57:40.031393	2026-02-06 15:57:40.096758
245	95	166	41	585	\N	t	5	0	f	0	2026-02-06 15:57:40.038136	2026-02-06 15:57:40.096758
246	95	167	41	590	\N	f	0	0	f	0	2026-02-06 15:57:40.038136	2026-02-06 15:57:40.096758
247	95	168	41	591	\N	t	1	0	f	0	2026-02-06 15:57:40.047164	2026-02-06 15:57:40.096758
248	97	158	42	553	\N	t	5	0	f	0	2026-02-06 21:35:03.828465	2026-02-06 21:35:04.018979
249	97	159	42	557	\N	t	5	0	f	0	2026-02-06 21:35:03.911208	2026-02-06 21:35:04.018979
250	97	160	42	560	\N	t	5	0	f	0	2026-02-06 21:35:03.919557	2026-02-06 21:35:04.018979
251	97	161	42	564	\N	t	5	0	f	0	2026-02-06 21:35:03.92756	2026-02-06 21:35:04.018979
252	97	162	42	569	\N	t	5	0	f	0	2026-02-06 21:35:03.93571	2026-02-06 21:35:04.018979
253	97	163	42	573	\N	f	0	0	f	0	2026-02-06 21:35:03.946192	2026-02-06 21:35:04.018979
254	97	164	42	577	\N	t	5	0	f	0	2026-02-06 21:35:03.946192	2026-02-06 21:35:04.018979
255	97	165	42	580	\N	t	5	0	f	0	2026-02-06 21:35:03.960953	2026-02-06 21:35:04.018979
256	97	166	42	585	\N	t	5	0	f	0	2026-02-06 21:35:03.964252	2026-02-06 21:35:04.018979
257	97	167	42	587	\N	f	0	0	f	0	2026-02-06 21:35:03.977589	2026-02-06 21:35:04.018979
258	97	168	42	591	\N	t	1	0	f	0	2026-02-06 21:35:03.981607	2026-02-06 21:35:04.018979
259	97	169	42	595	\N	f	0	0	f	0	2026-02-06 21:35:03.99214	2026-02-06 21:35:04.018979
260	98	128	42	445	\N	f	0	0	f	0	2026-02-06 21:40:37.999635	2026-02-06 21:40:38.065254
261	98	129	42	448	\N	t	5	0	f	0	2026-02-06 21:40:37.999635	2026-02-06 21:40:38.065254
262	98	130	42	453	\N	t	5	0	f	0	2026-02-06 21:40:38.007645	2026-02-06 21:40:38.065254
263	98	132	42	461	\N	t	5	0	f	0	2026-02-06 21:40:38.007645	2026-02-06 21:40:38.065254
264	98	133	42	464	\N	t	5	0	f	0	2026-02-06 21:40:38.015715	2026-02-06 21:40:38.065254
265	98	134	42	468	\N	t	5	0	f	0	2026-02-06 21:40:38.015715	2026-02-06 21:40:38.065254
266	98	135	42	471	\N	f	0	0	f	0	2026-02-06 21:40:38.015715	2026-02-06 21:40:38.065254
267	98	136	42	477	\N	t	5	0	f	0	2026-02-06 21:40:38.027188	2026-02-06 21:40:38.065254
268	98	137	42	481	\N	t	5	0	f	0	2026-02-06 21:40:38.029266	2026-02-06 21:40:38.065254
269	98	138	42	485	\N	t	5	0	f	0	2026-02-06 21:40:38.029266	2026-02-06 21:40:38.065254
270	98	140	42	492	\N	f	0	0	f	0	2026-02-06 21:40:38.036289	2026-02-06 21:40:38.065254
271	98	141	42	495	\N	f	0	0	f	0	2026-02-06 21:40:38.036289	2026-02-06 21:40:38.065254
272	98	142	42	500	\N	f	0	0	f	0	2026-02-06 21:40:38.044001	2026-02-06 21:40:38.065254
273	98	143	42	504	\N	f	0	0	f	0	2026-02-06 21:40:38.044883	2026-02-06 21:40:38.065254
274	98	144	42	508	\N	t	5	0	f	0	2026-02-06 21:40:38.044883	2026-02-06 21:40:38.065254
275	99	158	40	553	\N	t	5	0	f	0	2026-02-09 11:55:29.454165	2026-02-09 11:55:29.761694
276	99	159	40	557	\N	t	5	0	f	0	2026-02-09 11:55:29.570808	2026-02-09 11:55:29.761694
277	99	160	40	560	\N	t	5	0	f	0	2026-02-09 11:55:29.570808	2026-02-09 11:55:29.761694
278	99	161	40	564	\N	t	5	0	f	0	2026-02-09 11:55:29.570808	2026-02-09 11:55:29.761694
279	99	162	40	569	\N	t	5	0	f	0	2026-02-09 11:55:29.587594	2026-02-09 11:55:29.761694
280	99	163	40	572	\N	t	5	0	f	0	2026-02-09 11:55:29.587594	2026-02-09 11:55:29.761694
281	99	164	40	577	\N	t	5	0	f	0	2026-02-09 11:55:29.587594	2026-02-09 11:55:29.761694
282	99	165	40	580	\N	t	5	0	f	0	2026-02-09 11:55:29.587594	2026-02-09 11:55:29.761694
283	99	166	40	585	\N	t	5	0	f	0	2026-02-09 11:55:29.654161	2026-02-09 11:55:29.761694
284	100	171	36	603	\N	f	0	0	f	0	2026-02-11 16:15:18.364604	2026-02-11 16:15:18.619842
285	100	172	36	609	\N	t	5	0	f	0	2026-02-11 16:15:18.560624	2026-02-11 16:15:18.619842
286	100	173	36	611	\N	f	0	0	f	0	2026-02-11 16:15:18.560624	2026-02-11 16:15:18.619842
287	100	174	36	617	\N	f	0	0	f	0	2026-02-11 16:15:18.569636	2026-02-11 16:15:18.619842
288	100	175	36	619	\N	f	0	0	f	0	2026-02-11 16:15:18.569636	2026-02-11 16:15:18.619842
289	100	179	36	636	\N	f	0	0	f	0	2026-02-11 16:15:18.578108	2026-02-11 16:15:18.619842
\.


--
-- Data for Name: student_classes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_classes (id, student_id, class_id, enrollment_date, is_active) FROM stdin;
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (id, user_id, admission_number, roll_number, class_id, contact_number, address, date_of_birth, guardian_name, guardian_contact, is_active, created_at, updated_at) FROM stdin;
11	26	STU008	\N	\N		\N	\N	\N	\N	f	2026-01-19 10:08:53.552689	2026-01-19 10:09:24.126296
13	28	MIS/2021/3456	\N	9	\N	\N	\N	\N	\N	f	2026-01-23 18:24:45.386822	2026-01-23 18:25:44.808722
12	27	mis/2020/12345	\N	\N	\N	\N	\N	\N	\N	f	2026-01-21 10:43:54.26036	2026-01-23 18:25:53.200198
5	18	STU002	\N	4		\N	\N	\N	\N	f	2026-01-19 10:02:53.970967	2026-01-23 18:26:01.442809
17	32	MIS/2022/2545	\N	9	\N	\N	\N	\N	\N	f	2026-01-27 14:13:02.697082	2026-01-28 07:31:20.323176
16	31	MIS/2022/2333	\N	9	\N	\N	\N	\N	\N	f	2026-01-25 19:59:38.397577	2026-01-28 07:31:27.415754
6	21	STU003	\N	\N		\N	\N	\N	\N	f	2026-01-19 10:05:52.405493	2026-01-28 07:31:31.208067
3	8	S003	\N	4	\N	\N	\N	\N	\N	f	2026-01-15 10:10:49.748045	2026-01-28 07:31:34.908414
4	9	MIS/2022/2345	\N	5	\N	\N	\N	\N	\N	f	2026-01-16 20:27:00.897686	2026-01-28 07:31:39.169823
2	7	S005	\N	4	\N	\N	\N	\N	\N	f	2026-01-15 04:44:20.63895	2026-01-28 07:31:41.656171
14	29	mis/2020/7654	\N	9	\N	\N	\N	\N	\N	f	2026-01-23 18:26:51.643687	2026-01-28 07:31:44.653951
15	30	MIS/2021/3336	\N	9	\N	\N	\N	\N	\N	f	2026-01-24 07:05:55.314558	2026-01-28 07:31:49.361207
10	25	STU007	\N	\N		\N	\N	\N	\N	f	2026-01-19 10:08:53.419582	2026-01-28 07:31:52.146335
7	22	STU004	\N	\N		\N	\N	\N	\N	f	2026-01-19 10:05:52.579624	2026-01-28 07:31:54.746053
1	2	S001	\N	1	\N	\N	\N	\N	\N	f	2026-01-13 12:29:14.230851	2026-01-28 07:32:00.284894
18	33	MIS/2025/2345	\N	13	\N	\N	\N	\N	\N	t	2026-01-28 07:35:11.65819	2026-01-28 07:35:11.65819
19	34	MIS/2025/2335	\N	13	\N	\N	\N	\N	\N	t	2026-01-28 07:36:50.699763	2026-01-28 07:36:50.699763
20	36	MIS/2025/2245	\N	13	\N	\N	\N	\N	\N	t	2026-01-31 10:02:07.107445	2026-01-31 10:02:07.107445
22	39	ADM102	\N	\N		\N	\N	\N	\N	t	2026-01-31 10:13:46.785772	2026-01-31 10:13:46.785772
23	40	ADM103	\N	\N		\N	\N	\N	\N	t	2026-01-31 10:13:46.929814	2026-01-31 10:13:46.929814
24	41	ADM104	\N	\N		\N	\N	\N	\N	t	2026-01-31 10:13:47.073445	2026-01-31 10:13:47.073445
21	38	ADM101	\N	13		\N	\N	\N	\N	t	2026-01-31 10:13:46.650877	2026-01-31 10:14:27.368449
25	42	ADM105	\N	13		\N	\N	\N	\N	t	2026-01-31 10:13:47.230099	2026-01-31 10:14:50.708655
26	43	MIS/2021/3156	\N	13	\N	\N	\N	\N	\N	t	2026-02-03 10:52:40.580108	2026-02-03 10:52:40.580108
\.


--
-- Data for Name: teachers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teachers (id, user_id, teacher_id, subject, qualification, specialization, contact_number, address, joining_date, is_active, created_at, updated_at) FROM stdin;
5	16	TCH002	English		\N		\N	\N	f	2026-01-19 09:42:23.576271	2026-01-28 16:09:03.462908
4	15	TCH001	Mathematics		\N		\N	\N	f	2026-01-19 09:42:23.302135	2026-01-28 16:09:08.238175
3	10	TS006	agri	\N	\N	\N	\N	\N	f	2026-01-16 20:52:33.71291	2026-01-28 16:09:13.506869
6	35	TCH009	computer	\N	\N	\N	\N	\N	t	2026-01-28 16:11:04.061276	2026-01-28 16:11:04.061276
1	4	TS001	computer	None	None	\N	\N	\N	t	2026-01-14 10:17:38.330948	2026-01-29 12:33:16.41435
2	5	T002	computer	None	None	\N	\N	\N	t	2026-01-14 12:59:40.047231	2026-01-29 12:55:38.05751
7	37	TCH0011	chemistry	\N	\N	\N	\N	\N	t	2026-01-31 10:04:00.751947	2026-01-31 10:04:00.751947
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, password_hash, first_name, last_name, gender, profile_picture, is_active, is_deleted, role_id, created_at, updated_at) FROM stdin;
12	teacher1	teacher@examhub.com	$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	John	Smith	\N	\N	t	f	2	2026-01-18 03:43:32.954022	2026-01-20 08:19:22.867997
11	testuser	test@example.com	$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	Test	User	Female	\N	t	f	3	2026-01-18 03:18:14.79266	2026-01-20 08:17:05.467775
7	ST001	saflex272@gmail.com	scrypt:32768:8:1$xGFv73DmhfvjUqeW$d61472af5afd2332bc4a5707ea97ceb425ecc846280b2f7e23489ef8413892d715aaf3a81775262b4ca1716842542dc4c675214d32bae2d36c63f4ddec45c8b6	saheed	Ahmed	Female	\N	f	f	3	2026-01-15 04:44:20.63895	2026-01-28 07:31:41.659003
2	saflex24	saflex2@gmail.com	scrypt:32768:8:1$UWohUORjU0EOhRW8$a7cdc7945d9c7ff9d128d332e9fbe0e15b035898926dc8f4412462f225742e8b1ca555e8726a8b2b5be913662eb744de089496e85f4fa9b7efe2546a2095b546	saheed	nasir	Male	\N	f	f	3	2026-01-13 12:29:13.612319	2026-01-28 07:32:00.280586
16	mary.johnson	mary@school.com	scrypt:32768:8:1$lR7Dn0fjECRL6faL$fa701961cb0f34be2b2f2bf50f74cd5df45cd37da4a1df80b2363d382b5aa3de70dbc20ed3c5ed3339258b1fbb0a4a87893e8f8f33a94dff52dd11c6a6ac323d	Mary	Johnson	Female	\N	f	f	2	2026-01-19 09:42:23.576271	2026-01-28 16:09:03.394311
15	john.smith	john@school.com	scrypt:32768:8:1$6KbCYzOWAdhf62vW$14460110a145fa7659da551d5c441bf16ed9c95f50f1e3ad435f7a4af4b6cf1746d5551a439a2dcdf01222d404bfc33ad5b6e45ed90d03e6135ae202a788ad9e	John	Smith	Male	\N	f	f	2	2026-01-19 09:42:22.400722	2026-01-28 16:09:08.234199
10	fancis1	saflex247@gmail.com	scrypt:32768:8:1$9NtisXh30z9otbmV$c2542180033ec8edbc9b0a0da480d4d46f5fcd5ea42e2339e3ee6774f3c4a65e4897ca2a0db3de07548087677cfdcd35fc180da65132a3516468b199dcaeb92b	Francis	Jar	Male	\N	f	f	2	2026-01-16 20:52:33.71291	2026-01-28 16:09:13.505976
4	T001	saflex22@gmail.com	scrypt:32768:8:1$IP7SP81VXDcmUmuO$af70853289e7bdc16254cd9b2f86ee59ea41de623b7d9efa71789d6f65c8ccb09ef308292e7e77d49de2cdfebc4fbd3e2537b05afe47e9348910d65b31f6ba88	saheed	Ahmed	Female	\N	t	f	2	2026-01-14 10:17:38.081271	2026-01-29 12:33:14.923054
1	admin	admin@eexam.com	scrypt:32768:8:1$ur1ss9fymQjDY9RJ$e4c7ed9e40bf8e512dd29ee3c465d49e66929cb29094b4ba345b0601f0e1d703123dfea7f0d76a58023afea55504099980a7c86ec3ea4c1878f1426148f13207	SAHEED	OYEDEJI	Male	admin_1_20260203_114035_IMG_20250606_085149_006.jpg	t	f	1	2026-01-12 12:39:12.206789	2026-02-03 10:40:35.185221
5	TS002	saflex252@gmail.com	scrypt:32768:8:1$eUwN9jvSzqugq4F4$6ac95fc13ee098006fa60231b84e83f5319023c3ada439edd6adb9717a1a3e42b85389daaf35d933d5b1b0564f0d1551b8b33200adbf65d2b10eded88706f2b0	ahmem	nasir	Male	\N	t	f	2	2026-01-14 12:59:40.04423	2026-02-09 12:01:17.7343
26	jane.smith3	jane93@school.com	scrypt:32768:8:1$hfA2bENgmK4CuSe7$900e2e0e8e70ecfc29bd00ecf1c96a407a6dc2f9dafeb5ca26581b5f16efcd8959904210abfb5c8b181bfd2354b04dc639a76472ad5c00357610a4f462d49863	Jane	Smith	Male	\N	f	f	3	2026-01-19 10:08:53.552689	2026-01-20 08:17:05.467775
13	student1	student@examhub.com	$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	Alice	Johnson	Female	\N	t	f	3	2026-01-18 03:43:33.069451	2026-01-20 08:19:22.97664
14	student2	student2@examhub.com	$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	Bob	Williams	Male	\N	t	f	3	2026-01-18 03:43:33.089099	2026-01-20 08:19:22.97664
28	TS004	saflex2732@gmail.com	scrypt:32768:8:1$BYk8HHF2k6257RdI$ea474b321112654241f498e47237d4329a5cac59c269ab5fb840539184509f8d619668f4fd9095eafc0c4fd5ec7978ea6b128b1605309a1f5a8485a8057efa59	FATIMA	mohammed	Female	\N	f	f	3	2026-01-23 18:24:42.548303	2026-01-23 18:25:44.802972
27	admi	saflex227@gmail.com	scrypt:32768:8:1$4akKx9eGXoLn27nk$d0544aa3a0e502225f2e82379268396daad7639c0299a5b721500fd99a3a6dab93268398dd97be23760d1aeb132a54d83a468c75f0afb1c883d65b8ec43806f2	Abukakar	Aliyu	Male	\N	f	f	3	2026-01-21 10:43:53.778963	2026-01-23 18:25:53.198886
18	jane.smith	jane@school.com	scrypt:32768:8:1$GnSQ7jhzTeniF3hq$318579eab38efd9405f8efac99dfa1121fddcdd7e66af46cd67419dcebe2a4dd60673c0f5713ebd92a662859b119db4912b73ff2c33e3fe4afb347f73b267ffe	Jane	Smith	Male	\N	f	f	3	2026-01-19 10:02:53.831187	2026-01-23 18:26:01.439585
32	ST008	saflex2423@gmail.com	scrypt:32768:8:1$nCxpggZr0nsIbosd$359b4e606502a890d92714cfa16590444f791b383f1be07b8fe310be9cb8b3d02a156e887caac5d9930cb861f9bb59c235d7b5a02e4947f2da29879b08ed6978	Saheed	Oyedeji	Female	\N	f	f	3	2026-01-27 14:13:02.60861	2026-01-28 07:31:20.28805
31	ST009	saflex249@gmail.com	scrypt:32768:8:1$on0zKzuhmTHiGjBS$b7ed271e445fe3e0c4d237fbd144958ac0a4ad3c6a21b877650e2ab55b214eb1464627eac404e2992c97464a5f313ff0a6c60b4e930dca4da735bea57594dbe0	oreh	gana	Male	\N	f	f	3	2026-01-25 19:59:38.389061	2026-01-28 07:31:27.4208
21	john.doe	john2@school.com	scrypt:32768:8:1$NM2KXrqczbiwqssZ$19c1ae066549db831c00371472775e16d50ea9600c50aac1d82b2a33af0bda822e37ecf86d172cda789dafc5e760b688a317a12c8f507b17b573471ca4cfabfe	John	Doe	Female	\N	f	f	3	2026-01-19 10:05:52.405493	2026-01-28 07:31:31.205031
8	ST003	saflex2524@gmail.com	scrypt:32768:8:1$71BCnwLcwirRLjTP$e02f90592893f0e77aad8df98753140c86635f8462d2b4485b42c07ad2429fc9475a527d01e6483290a6e8870fb2d3fe5714a059f1bdab83f3cae062d43cf469	fatima	mohammed	Male	\N	f	f	3	2026-01-15 10:10:49.748045	2026-01-28 07:31:34.910801
9	saleem1	TEST@EXAM	scrypt:32768:8:1$5gbCbjz8ZRNyT6FW$9ed6625697fbf0a1bbd7ed96f3f63e6aa617d67447d742361633fbf246903714f7b83b8ba745ba8f6d2ff0b68ef2336f059da3c058a8a1425699eb341f6d456b	SALEEM	SAHEED	Female	\N	f	f	3	2026-01-16 20:27:00.697551	2026-01-28 07:31:39.164031
29	ST005	saflex77@gmail.com	scrypt:32768:8:1$ntYZ1WT9Lum7G7bM$7976d4384daa8b5200022c1495f34fd2e8f5de75d7f2a5f6a931c368c44fee50f41f5b86129bc83701169888de2ece5b4460d9d7b1eb2ae04e2573c8a4a324b3	Jane	Ahmed	Male	\N	f	f	3	2026-01-23 18:26:51.643687	2026-01-28 07:31:44.649991
30	ST006	saflex54@gmail.com	scrypt:32768:8:1$76AdRmukrBiwWP8P$9f11afa2dfdd6d2f1448ffb1eeff43527ef7aa2608e8683ef58ee0e4547929c9dd37c5efb690dbd8018c30538e806f3f705950319d87c222440f9b2a109f5d1f	amina	nasir	Female	\N	f	f	3	2026-01-24 07:05:55.286094	2026-01-28 07:31:49.354162
25	john.doe4	john80@school.com	scrypt:32768:8:1$D7luU1JyeAqVuLcO$3d8afb57ea434e37ba8a280ad51537b53f4b4fbdfaa35dec763c66d95c135b83d35f051aec0a42b4d51dbc560ca703da060026ce8fa1996cd299de1c135ec2d0	John	Doe	Female	\N	f	f	3	2026-01-19 10:08:53.419582	2026-01-28 07:31:52.149009
22	jane.smith1	jane3@school.com	scrypt:32768:8:1$nrIcwG0BMl34SqRQ$23c94f377aea1f7caed45e03230435b455fae735e75220f9a8e3b5fb344fd942d8c2b26c9806ae02fb09615a627f7bd7fa1c25cc1f06db277691b470347e5ef6	Jane	Smith	Male	\N	f	f	3	2026-01-19 10:05:52.57949	2026-01-28 07:31:54.741767
33	ST002	saflex6@gmail.com	scrypt:32768:8:1$uVNmCKQ3hukl50aX$8debab6e7e92236a43e8003171fac5f5216307397ccbb517a8a0119aa8d98db49cc703851f4b2e824da53f4e8fe4f9ce02610f6b5549ba3519536ca546848da2	saheed	nasir	Male	\N	t	f	3	2026-01-28 07:35:11.624	2026-01-28 07:35:11.624
35	TS009	saflex863@gmail.com	scrypt:32768:8:1$M52TRrZXBWJd3w4N$520e6ec5c6e2529792df900ccadab917d40a7780ee000c3fa16ea635dd4ba4705edece78e3fc5315a9bb20e50428cda8df7e01792a7bd1cf2f57297c1224546f	Abubakar	MOHAMMED	Male	\N	t	f	2	2026-01-28 16:11:03.712067	2026-01-28 16:11:03.712067
34	ST011	saflex86@gmail.com	scrypt:32768:8:1$k4ts5lnT4YuVW6Cg$ddc98369b95c44fba953c14e8fcf9e59af20826409921b5a6c3c398d26519633de08e0556ef8cceccf2fd430abc2b2df33e47836926b50a681c6a461e9225845	FATIMA	MOHAMMED	Female	\N	t	f	3	2026-01-28 07:36:50.697762	2026-01-29 12:53:38.528265
36	ST004	\N	scrypt:32768:8:1$NMVCkq8ILB8SUD9p$cc045eba715ebb346c9a90bae59dbed2e41e73e4128296df998e5810f563f08bfde86d5493ec3d01882d5c4f3083d6fba7347f7fa5b6c2106425e04c7cc849f6	Amina	AHMED	Female	\N	t	f	3	2026-01-31 10:02:07.000904	2026-01-31 10:02:56.493271
37	T006	\N	scrypt:32768:8:1$sc13h7L1byBGFqVD$23f30f6e6249720744d7f7c78be507b24a560ea42b1c402e243853465ceb5a0d7031372872e208037b8dd763c2bf19a565ea3d29d1bcf6c769422cab5c2d48c3	PAUL	AMOSE	Male	\N	t	f	2	2026-01-31 10:04:00.743922	2026-01-31 10:04:00.743922
42	zainabbello	\N	scrypt:32768:8:1$werwfBuUCpU4ugRs$65c1087faf30514d5d406ad0946fa04a07eca9cb3cd0c6ab2b50fea1f4d8823f17548a102baeff0239863836e3ee6d49292db4504a0b629581d9a299a25a6fe7	Zainab	Bello	Female	\N	t	f	3	2026-01-31 10:13:47.216077	2026-02-06 21:31:19.568061
43	ST007	\N	scrypt:32768:8:1$cBRuVinkvmkooKzb$6e8e8e63134077ceca64da18ae227ee8121bad8c81868eb2dfd360b2ae6386ebc92b780b956a88284641b9d2ffeb702e87162872579582044ffa7ca98398910b	Aisha	Yusuf	Female	\N	t	f	3	2026-02-03 10:52:40.515497	2026-02-03 10:52:40.515497
39	ibrasadiq	ibrasadiq@example.com	scrypt:32768:8:1$SVmCuNVJ7kA0NtTL$a2336e0e3cf785016a893a968dbb5efabe9949b9abba534a8aacc0eecbb86f9b8b169f43dc09f2373711657b0fb5b3d63dfa30e5f841faadc64698950ea1b341	Ibrahim	Sadiq	Male	\N	t	f	3	2026-01-31 10:13:46.785772	2026-02-06 11:06:38.262003
41	samokoro	samokoro@example.com	scrypt:32768:8:1$2T7YGJpWCALuDhA8$80da33d05b59c3ad8020a59a713c4c045adce9286aa689846fb30697d90947a51080bf7c9e1eafaddc6ce1cf1db76080e8b8fe6a42b57450a8fb8aa25abf25d4	Samuel	Okoro	Male	\N	t	f	3	2026-01-31 10:13:47.073445	2026-02-06 15:54:03.228653
38	aishamusa	aishamusa@example.com	scrypt:32768:8:1$ngqn2R4KFXWBUbO3$dc7f8d9123cecfb303889ecfe3adbeb984ed6a8657408402ac8f5ea2e84dad86e56dd4e8317a6884c6a34873ff8fcdcdf6ed2ae6e764c0c3b1034c20f35dcb5c	Aisha	Musa	Female	\N	t	f	3	2026-01-31 10:13:46.650877	2026-02-06 16:14:35.840348
40	fatimaabdul	fatimaabdul@example.com	scrypt:32768:8:1$3hJthfvTt34qs7f8$f600086482c40282660b901141337c0dcf82b9cbcf7c4191b53fb13db5abcbf2ddafa6f7a841adb88bab7f9d075f5419c2736e8d60cc295079c7aba20ff2e9cb	Fatima	Abdul	Female	\N	t	f	3	2026-01-31 10:13:46.921827	2026-02-09 11:51:45.822524
\.


--
-- Name: classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.classes_id_seq', 13, true);


--
-- Name: exam_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exam_results_id_seq', 38, true);


--
-- Name: exam_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exam_sessions_id_seq', 100, true);


--
-- Name: exams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exams_id_seq', 19, true);


--
-- Name: proctoring_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.proctoring_logs_id_seq', 206, true);


--
-- Name: question_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.question_options_id_seq', 642, true);


--
-- Name: questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.questions_id_seq', 180, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 3, true);


--
-- Name: student_answers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_answers_id_seq', 289, true);


--
-- Name: student_classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_classes_id_seq', 1, false);


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.students_id_seq', 26, true);


--
-- Name: teachers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.teachers_id_seq', 7, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 43, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: class_teacher class_teacher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_teacher
    ADD CONSTRAINT class_teacher_pkey PRIMARY KEY (class_id, teacher_id);


--
-- Name: classes classes_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_code_key UNIQUE (code);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: exam_results exam_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_results
    ADD CONSTRAINT exam_results_pkey PRIMARY KEY (id);


--
-- Name: exam_sessions exam_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_sessions
    ADD CONSTRAINT exam_sessions_pkey PRIMARY KEY (id);


--
-- Name: exam_sessions exam_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_sessions
    ADD CONSTRAINT exam_sessions_session_token_key UNIQUE (session_token);


--
-- Name: exams exams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT exams_pkey PRIMARY KEY (id);


--
-- Name: proctoring_logs proctoring_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proctoring_logs
    ADD CONSTRAINT proctoring_logs_pkey PRIMARY KEY (id);


--
-- Name: question_options question_options_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_options
    ADD CONSTRAINT question_options_pkey PRIMARY KEY (id);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: student_answers student_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_answers
    ADD CONSTRAINT student_answers_pkey PRIMARY KEY (id);


--
-- Name: student_classes student_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_classes
    ADD CONSTRAINT student_classes_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: students students_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_user_id_key UNIQUE (user_id);


--
-- Name: teachers teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_pkey PRIMARY KEY (id);


--
-- Name: teachers teachers_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_user_id_key UNIQUE (user_id);


--
-- Name: student_classes unique_student_class; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_classes
    ADD CONSTRAINT unique_student_class UNIQUE (student_id, class_id);


--
-- Name: exam_sessions uq_exam_sessions_session_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_sessions
    ADD CONSTRAINT uq_exam_sessions_session_code UNIQUE (session_code);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_proctoring_logs_exam_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proctoring_logs_exam_id ON public.proctoring_logs USING btree (exam_id);


--
-- Name: idx_proctoring_logs_severity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proctoring_logs_severity ON public.proctoring_logs USING btree (severity);


--
-- Name: idx_proctoring_logs_student_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proctoring_logs_student_id ON public.proctoring_logs USING btree (student_id);


--
-- Name: idx_proctoring_logs_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proctoring_logs_timestamp ON public.proctoring_logs USING btree ("timestamp");


--
-- Name: idx_proctoring_logs_violation_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proctoring_logs_violation_type ON public.proctoring_logs USING btree (violation_type);


--
-- Name: ix_classes_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_classes_name ON public.classes USING btree (name);


--
-- Name: ix_exams_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_exams_code ON public.exams USING btree (code);


--
-- Name: ix_students_admission_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_students_admission_number ON public.students USING btree (admission_number);


--
-- Name: ix_teachers_teacher_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_teachers_teacher_id ON public.teachers USING btree (teacher_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: classes update_classes_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_classes_updated_at BEFORE UPDATE ON public.classes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: exams update_exams_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_exams_updated_at BEFORE UPDATE ON public.exams FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: student_answers update_student_answers_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_student_answers_updated_at BEFORE UPDATE ON public.student_answers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: class_teacher class_teacher_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_teacher
    ADD CONSTRAINT class_teacher_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id);


--
-- Name: class_teacher class_teacher_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_teacher
    ADD CONSTRAINT class_teacher_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.teachers(id);


--
-- Name: exam_results exam_results_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_results
    ADD CONSTRAINT exam_results_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.exams(id);


--
-- Name: exam_results exam_results_exam_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_results
    ADD CONSTRAINT exam_results_exam_session_id_fkey FOREIGN KEY (exam_session_id) REFERENCES public.exam_sessions(id);


--
-- Name: exam_results exam_results_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_results
    ADD CONSTRAINT exam_results_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(id);


--
-- Name: exam_sessions exam_sessions_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_sessions
    ADD CONSTRAINT exam_sessions_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.exams(id);


--
-- Name: exam_sessions exam_sessions_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_sessions
    ADD CONSTRAINT exam_sessions_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(id);


--
-- Name: exams exams_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT exams_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id);


--
-- Name: exams exams_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT exams_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: proctoring_logs proctoring_logs_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proctoring_logs
    ADD CONSTRAINT proctoring_logs_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.exams(id);


--
-- Name: proctoring_logs proctoring_logs_exam_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proctoring_logs
    ADD CONSTRAINT proctoring_logs_exam_session_id_fkey FOREIGN KEY (exam_session_id) REFERENCES public.exam_sessions(id);


--
-- Name: proctoring_logs proctoring_logs_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proctoring_logs
    ADD CONSTRAINT proctoring_logs_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(id);


--
-- Name: question_options question_options_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_options
    ADD CONSTRAINT question_options_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id);


--
-- Name: questions questions_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.exams(id);


--
-- Name: student_answers student_answers_exam_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_answers
    ADD CONSTRAINT student_answers_exam_session_id_fkey FOREIGN KEY (exam_session_id) REFERENCES public.exam_sessions(id);


--
-- Name: student_answers student_answers_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_answers
    ADD CONSTRAINT student_answers_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id);


--
-- Name: student_answers student_answers_selected_option_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_answers
    ADD CONSTRAINT student_answers_selected_option_id_fkey FOREIGN KEY (selected_option_id) REFERENCES public.question_options(id);


--
-- Name: student_answers student_answers_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_answers
    ADD CONSTRAINT student_answers_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(id);


--
-- Name: student_classes student_classes_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_classes
    ADD CONSTRAINT student_classes_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id);


--
-- Name: student_classes student_classes_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_classes
    ADD CONSTRAINT student_classes_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: students students_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id);


--
-- Name: students students_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: teachers teachers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- PostgreSQL database dump complete
--

